vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP", "dc_panikknap")

local cooldown = 0

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    if IsControlJustPressed(0,57) then
      TriggerEvent("dc-animation:startWithItem", "carkeys")
      if cooldown == 0 then
        cooldown = Config.AntiSpamCooldown
        local coords = GetEntityCoords(GetPlayerPed(-1), 0)
        TriggerServerEvent("dc_panikknap", coords)
      end
    end
  end
end)

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(1000)
    if cooldown > 0 then 
      cooldown = cooldown - 1
    end
  end
end)

RegisterNetEvent("dc_panikknap:showBlip")
AddEventHandler("dc_panikknap:showBlip", function(coords)
	local ped = GetPlayerPed(-1)
  local blip = AddBlipForCoord(coords.x+0.001, coords.y+0.001, coords.z+0.001)
  SetBlipSprite(blip, 304)
  SetBlipColour(blip, 1)
  SetBlipAlpha(blip, 250)
  SetBlipAsShortRange(blip, true)
  BeginTextCommandSetBlipName("STRING")
  AddTextComponentString("Panikknap")
  SetBlipScale(blip, 0.8)
  EndTextCommandSetBlipName(blip)

  Citizen.SetTimeout(Config.BlipDeleteCooldown, function()
    RemoveBlip(blip)
  end)
end)