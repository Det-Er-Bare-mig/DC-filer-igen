Config = {}

Config.AntiSpamCooldown = 30
Config.RequiredPermission = "police.service"
Config.BlipDeleteCooldown = 300000