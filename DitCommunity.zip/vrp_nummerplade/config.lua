config = {}

config = {
    radius = 1.5,
    plateStartMed = "P", -- Hvad spillers nummerplader starter med, således at man ikke kan tage andre spillers nummerplader. (F.eks P på Origin, Dunko, Diaox og ByensRP)
    tid = 8500, -- tid det tager at tage/putte en nummerplade
    scenario = "CODE_HUMAN_MEDIC_TEND_TO_DEAD",
    lyd = true, -- om der skal være en lyd
    items = {
        skruetrekker = {
            idname = "skruetrekker",
            titel = "Skruetrækker",
            desc = "Skruetrækker til at skrue skruer af.",
            vegt = 1.0,
            brug = "> Brug"
        },
        plader = {
            idname = "plate",
            titel = "Nummerplade",
            vegt = 0.5
        }
    },
    notifys = {
        bilikketetpa = "Der er ikke en bil tæt på.",
        forlangtvek = "For langt væk fra nummerpladen.",
        tomnummerplade = "Denne nummerplade er tom.",
        spillernummerplade = "Du kan ikke tage en anden spillers nummerplade.",
        annulleret = "Du annulleret denne aktion.",
        ikketom = "Der er allerede en nummerplade på denne bil."
    },
    progressbars = {
        af = "Skruer nummerplade af...",
        pa = "Skruer nummerplade på..."
    }
}