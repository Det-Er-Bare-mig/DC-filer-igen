function notify(a,b)
        TriggerEvent("pNotify:SendNotification",{text=config.notifys[a],type=b,timeout=3000,layout="centerLeft",queue="global",animation={open="gta_effects_fade_in",close="gta_effects_fade_out"}})
end;

function closestVeh()
        local c=GetEntityCoords(PlayerPedId())
        local d=GetOffsetFromEntityInWorldCoords(PlayerPedId(),0.0,config.radius,0.0)
        local e=CastRayPointToPoint(c.x,c.y,c.z,d.x,d.y,d.z,10,PlayerPedId(),0)
        local f,f,f,f,g=GetRaycastResult(e)
        return g 
end;

RegisterNetEvent("vrp_nummerplade_tagAf")
AddEventHandler("vrp_nummerplade_tagAf",function(h)
        local i=closestVeh()
        if i and i~=0 then 
                local j=GetWorldPositionOfEntityBone(i,GetEntityBoneIndexByName(i,"taillight_l"))
                local k=GetEntityCoords(PlayerPedId(),1)
                if GetDistanceBetweenCoords(j,k,1)<config.radius then 
                        local l=GetVehicleNumberPlateText(i)l=tostring(l)
                        local m=true;
                        if l and l~="        " then 
                                if l:sub(1,1)==config.plateStartMed then 
                                        if l:gsub(" ","")==config.plateStartMed..tostring(h)then 
                                                m=true 
                                        else 
                                                m=false 
                                        end 
                                end;
                                if m then 
                                        TaskStartScenarioInPlace(PlayerPedId(),config.scenario,0,true)
                                        exports['progressBars']:startUI(config.tid,config.progressbars.af)
                                        local n=GetPedInVehicleSeat(i,-1)
                                        if n~=0 and not IsPedAPlayer(n)then 
                                                TaskLeaveVehicle(n,i,256)
                                                SetPedCombatAttributes(n,46,true)
                                                SetPedFleeAttributes(n,0,0)
                                                SetPedAsEnemy(n,true)
                                                SetPedMaxHealth(n,200)
                                                SetPedAlertness(n,3)
                                                SetPedCombatRange(n,0)
                                                SetPedCombatMovement(n,3)
                                                TaskCombatPed(n,PlayerPedId(),0,16)
                                                SetPedRelationshipGroupHash(n,GetHashKey("HATES_PLAYER"))
                                        end;
                                        Wait(config.tid/5)
                                        if config.lyd then 
                                                SendNUIMessage({action="play"})
                                        end;
                                        Wait(config.tid-config.tid/5)
                                        local o=closestVeh()
                                        if IsPedUsingScenario(PlayerPedId(),config.scenario)and o==i then 
                                                ClearPedTasks(PlayerPedId())
                                                TriggerServerEvent("vrp_nummerplade_tagPlate",tostring(l))
                                                TriggerServerEvent("vrp_nummerplade_syncS",i,"-")
                                        else 
                                                notify("annulleret","error")
                                        end 
                                else 
                                        notify("spillernummerplade","error")
                                end 
                        else 
                                notify("tomnummerplade","error")
                        end 
                else 
                        notify("forlangtvek","error")
                end 
        else 
                notify("bilikketetpa","error")
        end 
end)

RegisterNetEvent("vrp_nummerplade_syncC")
AddEventHandler("vrp_nummerplade_syncC",function(p,q)
        SetVehicleNumberPlateText(p,tostring(q))
end)

RegisterNetEvent("vrp_nummerplade_tagPa")
AddEventHandler("vrp_nummerplade_tagPa",function(q,r)
        local q=tostring(q)
        local i=closestVeh()
        if i and i~=0 then 
                local l=GetVehicleNumberPlateText(i)
                if l=="        "then 
                        local j=GetWorldPositionOfEntityBone(i,GetEntityBoneIndexByName(i,"taillight_l"))
                        local k=GetEntityCoords(PlayerPedId(),1)
                        if GetDistanceBetweenCoords(j,k,1)<config.radius then 
                                TaskStartScenarioInPlace(PlayerPedId(),config.scenario,0,true)
                                exports['progressBars']:startUI(config.tid,config.progressbars.pa)
                                Wait(config.tid/5)
                                if config.lyd then 
                                        SendNUIMessage({action="play"})
                                end;
                                Wait(config.tid-config.tid/5)
                                ClearPedTasks(PlayerPedId())
                                TriggerServerEvent("vrp_nummerplade_syncS",i,q)
                        else 
                                notify("forlangtvek","error")
                                TriggerServerEvent("vrp_nummerplade_refund",r)
                        end 
                else 
                        notify("ikketom","error")
                        TriggerServerEvent("vrp_nummerplade_refund",r)
                end 
        else 
                notify("bilikketetpa","error")
                TriggerServerEvent("vrp_nummerplade_refund",r)
        end 
end)()