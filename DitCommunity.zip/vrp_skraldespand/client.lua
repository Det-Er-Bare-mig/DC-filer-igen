local gunoaie = {
    "prop_bin_01a",
    "prop_bin_03a",
    "prop_bin_05a",
    'prop_dumpster_01a',
    'prop_dumpster_02a',
    'prop_dumpster_02b',
    'prop_dumpster_4a',
    'prop_dumpster_4b'
}
local gunoaie2 = {}

Citizen.CreateThread(function()
    Citizen.Wait(100)

    while true do
        local sleepThread = 1000
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        for i = 1, #gunoaie do
            local x = GetClosestObjectOfType(playerCoords, 2.0, GetHashKey(gunoaie[i]), false, false, false)
            local entity = nil
            if DoesEntityExist(x) then
                entity = x
                gunoi    = GetEntityCoords(entity)

        if DoesEntityExist(entity) <= 1.5 then
            sleepThread = 5

            DrawText3D(gunoi.x, gunoi.y, gunoi.z + 1.5, '[~b~E~s~] for at gennemsøge skraldespanden!~s~')  

            if IsControlJustReleased(0, 38) then
                if not gunoaie2[entity] then
                    gunoaie2[entity] = true
                    exports['progressBars']:startUI(10000, "Gennemsøger skraldespanden...")
                    OpenTrashCan()
                else
                TriggerEvent("pNotify:SendNotification",{text = "Du har allerede åbent denne skraldespand!",type = "info",timeout = (2000),layout = "bottomRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                        end
                    end
                end
            end
        end
        Citizen.Wait(sleepThread)
    end
end)

function OpenTrashCan()
    TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, true)

    Citizen.Wait(10000)

    TriggerServerEvent("vrp:primeste")

    ClearPedTasks(PlayerPedId())
end

function notify(text)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(false, false)
end
function DrawText3D(x,y,z, text)
	local onScreen,_x,_y=World3dToScreen2d(x,y,z)
	local px,py,pz=table.unpack(GetGameplayCamCoords())

	SetTextScale(0.35, 0.35)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 20,20,20,0)
end

