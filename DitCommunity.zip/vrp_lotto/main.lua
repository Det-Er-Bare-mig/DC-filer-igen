vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","vrp_lotto")

local CheckActive = false

RegisterNetEvent('scratch:scratch')
AddEventHandler('scratch:scratch', function()
    Citizen.CreateThread(function()
        if CheckActive == true then
            Citizen.Wait(250)
            TriggerEvent("pNotify:SendNotification", {text = "<center>Du kan kun tjekke en Lotto kupon adgangen", type = "error", timeout = 1400, layout = "bottomCenter"})
        else
        Check()
        Citizen.Wait(2000)
        randomChance = math.random(1, 100)
        if randomChance > 0 and randomChance < 8 then
            TriggerEvent("pNotify:SendNotification", {text = "<center>Du vandt <b style='color: #34eb3a'>" .. Config.Amount1 .. " DKK</b>", type = "success", timeout = 1400, layout = "bottomCenter"})
            TriggerServerEvent('scratch:amount1')
        elseif randomChance > 8 and randomChance < 16 then
            TriggerEvent("pNotify:SendNotification", {text = "<center>Du vandt <b style='color: #34eb3a'>" .. Config.Amount2 .. " DKK</b>", type = "success", timeout = 1400, layout = "bottomCenter"})
            TriggerServerEvent('scratch:amount2')
        elseif randomChance > 16 and randomChance < 22 then
            TriggerEvent("pNotify:SendNotification", {text = "<center>Du vandt <b style='color: #34eb3a'>" .. Config.Amount3 .. " DKK</b>", type = "success", timeout = 1400, layout = "bottomCenter"})
            TriggerServerEvent('scratch:amount3')
        elseif randomChance > 26 and randomChance < 27 then
            TriggerEvent("pNotify:SendNotification", {text = "<center>Du vandt JACKPOT!! på <b style='color: #34eb3a'>" .. Config.Amount5 .. " DKK</b>", type = "success", timeout = 1400, layout = "bottomCenter"})
            TriggerServerEvent('scratch:amount5')
        elseif randomChance > 27 and randomChance < 100 then
            TriggerEvent("pNotify:SendNotification", {text = "<center>Desværre<b style='color: #eb4034'> du tabte på din lotto kupon.</b>", type = "error", timeout = 1400, layout = "bottomCenter"})
        end
        end
    end)
end)

function Check()
    local ped = PlayerPedId()
    CheckActive = true
    exports['progressBars']:startUI(4000, "Tjekker Lottokupon...")
  --  TriggerEvent("pNotify:SendNotification", {text = "<center>Tjekker din Lotto kupon<p>Vent et øjeblik...", type = "info", timeout = 1500, layout = "bottomCenter"})
    TriggerEvent("dc-animation:startWithItem", "notesblok")
    Citizen.Wait(4000)
    TriggerEvent("dc-animation:stopAnim", "notesblok")
    TriggerServerEvent("scratch:takelotto")
    ClearPedTasks(ped)
    CheckActive = false
end