Config = {}

Config.Amount1 = 5000
Config.Amount2 = 10000
Config.Amount3 = 15000
Config.Amount5 = 200000