Config = {}
Config.Locale = 'da'
Config.distance = 15