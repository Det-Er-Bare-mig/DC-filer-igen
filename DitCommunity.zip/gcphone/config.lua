FixePhone = {
  -- Poste de police
}

ShowNumberNotification = true -- Show Number or Contact Name when you receive new SMS