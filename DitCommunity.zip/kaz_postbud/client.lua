--[[
─────────────────────────────────────────────────────────────────────────────────────────────────────────
─██████──████████─██████████████─██████████████████─██████████████─██████████████─██████──────────██████─
─██░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
─██░░██──██░░████─██░░██████░░██─████████████░░░░██─██░░██████░░██─██░░██████░░██─██░░░░░░░░░░██──██░░██─
─██░░██──██░░██───██░░██──██░░██─────────████░░████─██░░██──██░░██─██░░██──██░░██─██░░██████░░██──██░░██─
─██░░██████░░██───██░░██████░░██───────████░░████───██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░░░░░░░░░██───██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░██████░░██───██░░██████░░██───████░░████───────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░██──██░░██───██░░██──██░░██─████░░████─────────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██████░░██─
─██░░██──██░░████─██░░██──██░░██─██░░░░████████████─██░░██████░░██─██░░██████░░██─██░░██──██░░░░░░░░░░██─
─██░░██──██░░░░██─██░░██──██░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██████████░░██─
─██████──████████─██████──██████─██████████████████─██████████████─██████████████─██████──────────██████─
─────────────────────────────────────────────────────────────────────────────────────────────────────────
]]--

--- HUSK AT LAVE GÅ PÅ JOB HOS BILFORHANDLER

postbudHasJob = false
postbudOnMission = false
postbudHarPost = 0
postbudJobStarted = false
postbudDoorsOpen = false
postbudKasse = false
postbudCooldownstatus = false
postbudDeliveryNumber = 0

-- TJEK JOB
Citizen.CreateThread(function()
    while true do
		TriggerServerEvent('kaz_postbud:checkjob')
		Citizen.Wait(60000)
	end
end)

RegisterNetEvent("kaz_postbud:jobreply")
AddEventHandler("kaz_postbud:jobreply", function(postbudRank) 
postbudHasJob = postbudRank
end)


-- FUNKTIONER
Citizen.CreateThread(function()
    while true do
		Citizen.Wait(1)
		if postbudHasJob == true then 
			if postbudJobStarted == true then 
				if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.postvogncords.x,cfg.postvogncords.y,cfg.postvogncords.z, true ) < 50 then
					DrawMarker(1, cfg.postvogncords.x,cfg.postvogncords.y,cfg.postvogncords.z-1.0,0,0,0,0,0,0,1.001,1.0001,0.5001,102,204,0,200,0,0,0,true) 
					if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.postvogncords.x,cfg.postvogncords.y,cfg.postvogncords.z, true ) < 1 then
						DrawText3Ds(cfg.postvogncords.x,cfg.postvogncords.y,cfg.postvogncords.z+0.4, "~w~[~b~E~w~] Hent Postvogn", 3.0, 7)
						if IsControlJustPressed(1, 38) then
							local veh = GetClosestVehicle(cfg.postvognplacering.x+0.0001,cfg.postvognplacering.y+0.0001,cfg.postvognplacering.z+0.0001, 5+0.0001, 0, 70)
							if veh == 0 then 
								bilmodellen = cfg.postvogntype
								RequestModel(GetHashKey(bilmodellen));
									while not HasModelLoaded(GetHashKey(bilmodellen)) do
										RequestModel(GetHashKey(bilmodellen));
										Wait(50)
									end
								local vehicle = CreateVehicle(GetHashKey(bilmodellen), cfg.postvognplacering.x,cfg.postvognplacering.y,cfg.postvognplacering.z,cfg.postvognplacering.h, true, false)
								SetVehicleOnGroundProperly(vehicle)
								SetEntityInvincible(vehicle,false)
								SetEntityAsMissionEntity(vehicle, true, true) 
								SetModelAsNoLongerNeeded(bilmodellen)
								Citizen.Wait(500)
							else
								TriggerEvent("pNotify:SendNotification",{text = "Der holder allerede en bil på lokationen",type = "success",timeout = (8000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
								Citizen.Wait(500)
							end
						end
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.pakkehent.x,cfg.pakkehent.y,cfg.pakkehent.z, true ) < 50 then
					DrawMarker(1, cfg.pakkehent.x,cfg.pakkehent.y,cfg.pakkehent.z-1.0,0,0,0,0,0,0,1.001,1.0001,0.5001,102,204,0,200,0,0,0,true)
					if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.pakkehent.x,cfg.pakkehent.y,cfg.pakkehent.z, true ) < 1 then
						DrawText3Ds(cfg.pakkehent.x,cfg.pakkehent.y,cfg.pakkehent.z+0.4, "~w~[~b~E~w~] Tag pakke", 3.0, 7)
						if IsControlJustPressed(1, 38) then
							if postbudKasse == false then 
								loadAnimDict("anim@heists@box_carry@")
								postbudKasse = true
								local prop = "hei_prop_heist_box"
								local plyCoords = GetOffsetFromEntityInWorldCoords(GetPlayerPed(PlayerId()), 0.0, 0.0, -4.0)
								local propspawned = CreateObject(GetHashKey(prop), plyCoords.x, plyCoords.y, plyCoords.z, 1, 1, 1)
								Citizen.Wait(100)
								local netid = ObjToNet(propspawned)
								prop_net = netid
								AttachEntityToEntity(propspawned, GetPlayerPed(-1), GetPedBoneIndex(GetPlayerPed(-1), 60309), 0.025, 0.08, 0.255, -145.0, 290.0, 0.0, true, true, false, true, 1, true)
								TaskPlayAnim(GetPlayerPed(-1), "anim@heists@box_carry@", "idle", 8.0, 1.0, -1, 50, 0, 0, 0, 0)
								Citizen.Wait(500)
							else
								TriggerEvent("pNotify:SendNotification",{text = "Du har allerede en pakke",type = "success",timeout = (8000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
								Citizen.Wait(500)
							end
						end
					end
				end
				if not IsPedInAnyVehicle(GetPlayerPed(-1), false) then
					local pos = GetEntityCoords(GetPlayerPed(-1))
					local veh = GetClosestVehicle(pos.x+0.0001,pos.y+0.0001,pos.z+0.0001, 5+0.0001, 0, 70)
					if GetDisplayNameFromVehicleModel(GetEntityModel(veh)) == cfg.postvogntype then 
						loc = GetOffsetFromEntityInWorldCoords(veh, 0.0, -3.8, 0.0)
						DrawMarker(1, loc.x,loc.y,loc.z-0.8,0,0,0,0,0,0,1.001,1.0001,0.5001,102,204,0,200,0,0,0,true) 
						if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), loc.x,loc.y,loc.z, true ) < 1 then
							if postbudDoorsOpen == false then 
								DrawText3Ds(loc.x,loc.y,loc.z+0.4, "~w~[~b~E~w~] Åben Dørene", 3.0, 7)
							else 
								if postbudKasse == true then 
									DrawText3Ds(loc.x,loc.y,loc.z+0.4, "~w~[~b~E~w~] Læg kasse", 3.0, 7)
								elseif postbudKasse == false and postbudHarPost > 0 then 
									DrawText3Ds(loc.x,loc.y,loc.z+0.4, "~w~[~b~E~w~] Luk dørene / ~w~[~b~C~w~] Tag kasse", 3.0, 7)
								else
									DrawText3Ds(loc.x,loc.y,loc.z+0.4, "~w~[~b~E~w~] Luk dørene", 3.0, 7)
								end
							end
							if IsControlJustPressed(1, 38) then
								if postbudDoorsOpen == false then 
									postbudDoorsOpen = true
									SetVehicleDoorOpen(veh, 3, false, true)
									Citizen.Wait(500)
									SetVehicleDoorOpen(veh, 2, false, true)
									Citizen.Wait(500)
								else
									if postbudKasse == true then 
										ped = GetPlayerPed(-1)
										ClearPedTasks(ped)
										DetachEntity(NetToObj(prop_net), 1, 1)
										DeleteEntity(NetToObj(prop_net))
										DeleteObject(NetToObj(prop_net))
										ClearFacialIdleAnimOverride(ped) 
										postbudKasse = false
										postbudHarPost = postbudHarPost+1
										TriggerEvent("pNotify:SendNotification",{text = "Du har nu "..postbudHarPost.." pakker i bilen.",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
										Citizen.Wait(500)
									else
										postbudDoorsOpen = false
										SetVehicleDoorShut(veh, 2, false, true)
										Citizen.Wait(500)
										SetVehicleDoorShut(veh, 3, false, true)
										Citizen.Wait(500)
									end
								end
							end
							if IsControlJustPressed(1, 79) then
								if postbudDoorsOpen == true then 
									if postbudKasse == false then
										if postbudHarPost > 0 then
											loadAnimDict("anim@heists@box_carry@")
											postbudKasse = true
											local prop = "hei_prop_heist_box"
											local plyCoords = GetOffsetFromEntityInWorldCoords(GetPlayerPed(PlayerId()), 0.0, 0.0, -4.0)
											local propspawned = CreateObject(GetHashKey(prop), plyCoords.x, plyCoords.y, plyCoords.z, 1, 1, 1)
											Citizen.Wait(100)
											local netid = ObjToNet(propspawned)
											prop_net = netid
											AttachEntityToEntity(propspawned, GetPlayerPed(-1), GetPedBoneIndex(GetPlayerPed(-1), 60309), 0.025, 0.08, 0.255, -145.0, 290.0, 0.0, true, true, false, true, 1, true)
											postbudHarPost = postbudHarPost-1
											TriggerEvent("pNotify:SendNotification",{text = "Du har nu "..postbudHarPost.." pakker i bilen.",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
											TaskPlayAnim(GetPlayerPed(-1), "anim@heists@box_carry@", "idle", 8.0, 1.0, -1, 50, 0, 0, 0, 0)
											Citizen.Wait(500)
										end
									end
								end
							end
						end
					end
				end
				if postbudOnMission == true then 
					for i = postbudDeliveryNumber,postbudDeliveryNumber do
						SetNewWaypoint(cfg.postbudlocations[i].x+0.0001,cfg.postbudlocations[i].y+0.0001)
						if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.postbudlocations[i].x,cfg.postbudlocations[i].y,cfg.postbudlocations[i].z, true ) < 50 then
							DrawMarker(1, cfg.postbudlocations[i].x,cfg.postbudlocations[i].y,cfg.postbudlocations[i].z-1.0,0,0,0,0,0,0,1.001,1.0001,0.5001,102,204,0,200,0,0,0,true) 
							if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), cfg.postbudlocations[i].x,cfg.postbudlocations[i].y,cfg.postbudlocations[i].z, true ) < 1 then
								DrawText3Ds(cfg.postbudlocations[i].x,cfg.postbudlocations[i].y,cfg.postbudlocations[i].z+0.4, "~w~[~b~E~w~] Ring på klokken", 3.0, 7)
								if IsControlJustPressed(1, 38) then
									if postbudKasse == true then 
										FreezeEntityPosition(PlayerPedId(),true)
										postbudKasse = false
										TriggerEvent("pNotify:SendNotification",{text = "Ringer på klokken...",type = "success",timeout = (4500),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},sounds = {sources = {"doorbell.ogg"},volume = 0.5,conditions = {"docVisible"}}, killer = true}) -- MED LYD
										--TriggerEvent("pNotify:SendNotification",{text = "Ringer på klokken...",type = "success",timeout = (4500),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}}) -- UDEN LYD
										Citizen.Wait(5000)
										TriggerEvent("pNotify:SendNotification",{text = "Kunden var hjemme",type = "success",timeout = (4500),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}}) -- UDEN LYD
										ped = GetPlayerPed(-1)
										ClearPedTasks(ped)
										DetachEntity(NetToObj(prop_net), 1, 1)
										DeleteEntity(NetToObj(prop_net))
										DeleteObject(NetToObj(prop_net))
										ClearFacialIdleAnimOverride(ped) 
										FreezeEntityPosition(PlayerPedId(),false)
										Citizen.Wait(5000)
										TriggerServerEvent('kaz_postbud:getpaid')
										postbudOnMission = false
										Citizen.Wait(500)
									else
										TriggerEvent("pNotify:SendNotification",{text = "Du har ingen pakke på dig",type = "success",timeout = (4500),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
										Citizen.Wait(500)
									end
								end
							end
						end
					end
				end		
			end
		end
	end
end)


-- TEXTER PÅ SKÆRM
Citizen.CreateThread(function()
    while true do
	Citizen.Wait(1)
		if postbudCooldownstatus == false then 
			if postbudHasJob == true then
				if postbudJobStarted == false then
					ply_drawTxt("/post for at starte job",4,1,0.5,0.88,0.25,255,255,255,255)	
				else
					ply_drawTxt("/poststop for at stoppe",4,1,0.5,0.88,0.25,255,255,255,255)
					if postbudOnMission == true then 
						ply_drawTxt("Kør til GPSén og aflever en pakke",4,1,0.5,0.85,0.4,255,255,255,255)
					else
						if postbudHarPost > 0 and GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(GetPlayerPed(-1)))) == cfg.postvogntype then
							ply_drawTxt("Lever pakker (/post)",4,1,0.5,0.85,0.4,255,255,255,255)
						else
							if GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(GetPlayerPed(-1)))) == cfg.postvogntype then
								ply_drawTxt("Hent pakker (/post)",4,1,0.5,0.85,0.4,255,255,255,255)
							else
								ply_drawTxt("Hent Firmabil (/post)",4,1,0.5,0.85,0.4,255,255,255,255)
							end
						end
					end
					if postbudKasse == true then 
						ply_drawTxt("/smidkasse for at smide kassen",4,1,0.5,0.90,0.25,255,255,255,255)
					end
				end
			end
		end
	end
end)

-- SLASHCOMMANDS
RegisterCommand("poststop", function()
	if postbudKasse == true then
		postbudKasse = false
		ped = GetPlayerPed(-1)
		ClearPedTasks(ped)
		DetachEntity(NetToObj(prop_net), 1, 1)
		DeleteEntity(NetToObj(prop_net))
		DeleteObject(NetToObj(prop_net))
		ClearFacialIdleAnimOverride(ped) 
	end
postbudHasJob = false
postbudOnMission = false
postbudJobStarted = false
postbudOnMission = false
postbudDeliveryNumber = 0
postbudCooldown()
end)

RegisterCommand("smidkasse", function()
postbudKasse = false
	if prop_net ~= nil then 
		ped = GetPlayerPed(-1)
		ClearPedTasks(ped)
		DetachEntity(NetToObj(prop_net), 1, 1)
		DeleteEntity(NetToObj(prop_net))
		DeleteObject(NetToObj(prop_net))
		ClearFacialIdleAnimOverride(ped)
	end
end)

RegisterCommand("post", function()
	if postbudCooldownstatus == false then 
		if postbudJobStarted == false then 
			postbudJobStarted = true
		else
			if postbudHarPost > 0 and GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(GetPlayerPed(-1)))) == cfg.postvogntype then
				if postbudOnMission == false then 
					postbudDeliveryNumber = math.random(1, cfg.postbudantal)
					postbudOnMission = true 
					TriggerEvent("pNotify:SendNotification",{text = "GPS sat til leveringspunkt",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
				else
					TriggerEvent("pNotify:SendNotification",{text = "Du har allerede modtaget en gps, færdiggør den for at få en ny!",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
				end
			elseif postbudHarPost == 0 and GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(GetPlayerPed(-1)))) == cfg.postvogntype then
				SetNewWaypoint(cfg.pakkehent.x+0.0001,cfg.pakkehent.y+0.0001)
				TriggerEvent("pNotify:SendNotification",{text = "GPS sat til pakkeafhentning",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
			elseif postbudHarPost == 0 and GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(GetPlayerPed(-1)))) ~= cfg.postvogntype then 
				SetNewWaypoint(cfg.postvogncords.x+0.0001,cfg.postvogncords.y+0.0001)
				TriggerEvent("pNotify:SendNotification",{text = "GPS Sat til firmabil",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
			end
		end
	else
		TriggerEvent("pNotify:SendNotification",{text = "Cooldown! (10 min)",type = "success",timeout = (5000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
	end
end, false)

-- KALDTE FUNKTIONER
function postbudCooldown()
	postbudCooldownstatus = true
	Citizen.Wait(600000)
	postbudCooldownstatus = false
end
			
function loadAnimDict( dict )
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 5 )
    end
end			
			
function ply_drawTxt(text,font,centre,x,y,scale,r,g,b,a)
	SetTextFont(font)
	SetTextProportional(0)
	SetTextScale(scale, scale)
	SetTextColour(r, g, b, a)
	SetTextDropShadow(0, 0, 0, 0,255)
	SetTextEdge(1, 0, 0, 0, 255)
	SetTextDropShadow()
	SetTextOutline()
	SetTextCentre(centre)
	SetTextEntry("STRING")
	AddTextComponentString(text)
	DrawText(x , y)
end	

function DrawText3Ds(x,y,z, text)
  local onScreen,_x,_y=World3dToScreen2d(x,y,z)
  local px,py,pz=table.unpack(GetGameplayCamCoords())
  SetTextScale(0.35, 0.35)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextColour(255, 255, 255, 215)
  SetTextEntry("STRING")
  SetTextCentre(1)
  AddTextComponentString(text)
  DrawText(_x,_y)
  local factor = (string.len(text)) / 370
  DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
					

-- TEST AF TAG PAKKE FUNKTION
-- FIX LEVERINGSSYSTEM
