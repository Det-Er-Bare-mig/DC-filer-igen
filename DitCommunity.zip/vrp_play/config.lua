config = {}

config = {
    prop = "frag_plank_c",
    anims = {
        setop = "WORLD_HUMAN_HAMMERING",
        fjern = "WORLD_HUMAN_WELDING"
    },
    progressbars = {
        setop = "Sætter planke op...",
        fjern = "Fjerner planke..."
    },
    tid = { -- i millisekunder
        setop = 4500,
        fjern = 8000
    },
    notifys = {
        altersatop = "Alt plankeværet er allerede sat op.",
        annuller = "Du annullerede din interkation.",
        setop = "Du satte en planke op.",
        fjern = "Du fjernede en planke."
    },
    radius = 1.5, -- hvor tæt man skal være for at tilføje/fjerne planker
    items = {
        planke = {
            idname = "planke",
            titel = "Planke",
            beskrivelse = "Kan bruges til at barrikere sig selv.",
            brug = "> Sæt Op",
            vegt = 3.5
        },
        vinkelsliber = {
            idname = "vinkelsliber",
            titel = "Vinkelsliber",
            beskrivelse = "Kan bruges til at fjerne barrikationer.",
            brug = "> Fjern barrikationer",
            vegt = 4.0
        }
    },
    pos = {
        {231.08839416504,214.89552307129,106.06076049805}, -- National Banken
        {259.45086669922,203.607421875,106.28309631348}, -- National Banken
        {-631.67065429688,-237.5206451416,38.070613861084} -- Juvelbutikken
    },
    propPos = {
        [1] = { -- National Banken
            {231.79451049805,215.26258850098,105.730097961, 25.0},
            {231.79451049805,215.26258850098,106.230097961, 25.0},
            {231.79451049805,215.26258850098,106.730097961, 25.0}
        },
        [2] = { -- National Banken
            {259.26300048828,203.45393371582,105.68022003174, 70.0},
            {259.26300048828,203.45393371582,106.18022003174, 70.0},
            {259.26300048828,203.45393371582,106.68022003174, 70.0}
        },
        [3] = { -- Juvelbutikken
            {-631.67065429688,-237.5206451416,37.67474899292, 35.0},
            {-631.67065429688,-237.5206451416,38.17474899292, 35.0},
            {-631.67065429688,-237.5206451416,38.67474899292, 35.0},
            {-631.67065429688,-237.5206451416,39.17474899292, 35.0}
        }
    }
}