local a=GetHashKey(config.prop)
local b={}

function notify(c,d)
    TriggerEvent("pNotify:SendNotification",{text=config.notifys[c],type=d,timeout=3000,layout="centerLeft",queue="global",animation={open="gta_effects_fade_in",close="gta_effects_fade_out"}})
end;

RegisterNetEvent("vrp_play:syncC")
AddEventHandler("vrp_play:syncC",function(e)
    b=e 
end)

RegisterNetEvent("vrp_play:fjern")
AddEventHandler("vrp_play:fjern",function()
    local f=PlayerPedId()
    local g=GetEntityCoords(f,true)
    for h,i in pairs(config.pos) do 
        if GetDistanceBetweenCoords(g.x,g.y,g.z,i[1],i[2],i[3],true)<config.radius then
            if b[h] then 
                local j=#b[h]
                if j>0 then 
                    TaskStartScenarioInPlace(f,config.anims.fjern,0,true)
                    exports['progressBars']:startUI(config.tid.fjern,config.progressbars.fjern)
                    local k=0;
                    local l=false;
                    while not l do 
                        Citizen.Wait(500)
                        if IsPedActiveInScenario(f) then 
                            k=k+500;if k>config.tid.fjern-1 then
                                l=true;
                                break 
                            end 
                        else 
                            ClearPedTasks(f)
                            exports['progressBars']:hideUI()
                            notify("annuller","error")
                            break 
                        end 
                    end;
                    if l then 
                        TriggerServerEvent("vrp_play:syncRemove",b[h][j],h,j)
                        ClearPedTasks(f)
                        notify("fjern","success")
                    end 
                end 
            end 
        end 
    end 
end)
RegisterNetEvent("vrp_play:removeSyncC")
AddEventHandler("vrp_play:removeSyncC",function(m,h,j)
    local n=NetworkGetEntityFromNetworkId(m[1])
    NetworkRequestControlOfEntity(n)
    SetEntityAsMissionEntity(n,true,true)
    DeleteObject(n)
    DeleteEntity(n)
    SetEntityAsNoLongerNeeded(n)b[h][j]=nil;
    TriggerServerEvent("vrp_play:syncS",b)
end)

RegisterNetEvent("vrp_play:start")
AddEventHandler("vrp_play:start",function()
    local f=PlayerPedId()
    local g=GetEntityCoords(f,true)
    for h,i in pairs(config.pos) do 
        if GetDistanceBetweenCoords(g.x,g.y,g.z,i[1],i[2],i[3],true)<config.radius then 
            RequestModel(a)
            while not HasModelLoaded(a) do 
                Citizen.Wait(100)
            end;
            local o;
            if not b[h] then 
                o=1;
                b[h]={}
            else 
                for p=1,#b[h] do 
                    if not b[h][p] then 
                        o=p 
                    end 
                end;
                if not b[h][o] then 
                    o=#b[h]+1 
                end 
            end;
            local q=tonumber(o)>#config.propPos[h]
            if not q then 
                local r=b[h]
                obj=CreateObject(a,config.propPos[h][o][1],config.propPos[h][o][2],config.propPos[h][o][3],true,false,true)
                local s=ObjToNet(obj)
                b[h][o]={s,GetPlayerServerId(PlayerId())}
                SetEntityHeading(obj,config.propPos[h][o][4])
                SetEntityVisible(obj,false)
                SetEntityInvincible(obj,true)
                TriggerServerEvent("vrp_play:syncS",b)
                exports['progressBars']:startUI(config.tid.setop,config.progressbars.setop)
                TaskStartScenarioInPlace(f,config.anims.setop,0,true)
                local k=0;
                local l=false;
                while not l do 
                    Citizen.Wait(500)
                    if IsPedActiveInScenario(f) then 
                        k=k+500;
                        if k>config.tid.setop-1 then 
                            l=true;
                            break 
                        end 
                    else 
                        ClearPedTasks(f)
                        DeleteObject(obj)b[h][o]=nil;
                        exports['progressBars']:hideUI()
                        notify("annuller","error")
                        TriggerServerEvent("vrp_play:givPlanke")
                        break 
                    end 
                end;
                ClearPedTasks(f)
                SetEntityVisible(obj,true)
                notify("setop","success")
            else 
                notify("altersatop","error")
                TriggerServerEvent("vrp_play:givPlanke")
            end 
        end 
    end 
end)