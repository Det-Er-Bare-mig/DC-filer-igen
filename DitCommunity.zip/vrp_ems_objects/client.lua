-- Events --

RegisterNetEvent('artic_medbag')
AddEventHandler('artic_medbag', function()
	ExecuteCommand("medbag")
end)

RegisterNetEvent('artic_medbox1')
AddEventHandler('artic_medbox1', function()
	ExecuteCommand("medbox")
end)

