local openv = false
local openk = false
local opens = false
local delay = 200

--[[ ////////////////////////////////////////// ]]

RegisterNetEvent('vrp_kort:showvcard')
AddEventHandler('vrp_kort:showvcard', function(identity)
    openv = true
    SendNUIMessage({
      type = "cardvdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      tlfnummer = identity.phone,
    })
end)

RegisterNetEvent('vrp_kort:showkcard')
AddEventHandler('vrp_kort:showkcard', function(identity)
    openk = true
    SendNUIMessage({
      type = "cardkdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      tlfnummer = identity.phone,
      cprnummer = identity.registration,
      alder = identity.age,
    })
end)

RegisterNetEvent('vrp_kort:showscard')
AddEventHandler('vrp_kort:showscard', function(identity)
    opens = true
    SendNUIMessage({
      type = "cardsdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      cprnummer = identity.registration,
      alder = identity.age,
      home = identity.hjem,
      city = "Los Santos",
      postalcode = "684001 Los Santos",
    })
end)

--[[ ////////////////////////////////////////// ]]
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
        if IsControlJustReleased(1, 194) and openv or IsControlJustReleased(1, 194) and openk or IsControlJustReleased(1, 194) and opens then
            openv = false
            openk = false
            opens = false
            TriggerServerEvent("reset:local")
			SendNUIMessage({
                status = false,
			})
		end
	end
end)
--[[ ////////////////////////////////////////// ]]

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while openv do
            delay = 0
            Citizen.Wait(delay)
            drawTxt('Tryk ~b~[BACKSPACE]~s~ for at lukke VISITKORT', 4, 1, 0.50, 0.37, 0.6, 255, 255, 255, 255)
        end
        delay = 200
    end
end) 

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while openk do
            delay = 0
            Citizen.Wait(delay)
            drawTxt('Tryk ~b~[BACKSPACE]~s~ for at lukke KØREKORT', 4, 1, 0.51, 0.37, 0.6, 255, 255, 255, 255)
        end
        delay = 200
    end
end) 

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while opens do
            delay = 0
            Citizen.Wait(delay)
            drawTxt('Tryk ~b~[BACKSPACE]~s~ for at lukke SUNDHEDSKORT', 4, 1, 0.50, 0.37, 0.6, 255, 255, 255, 255)
        end
        delay = 200
    end
end) 

function drawTxt(text, font, centre, x, y, scale, r, g, b, a)
	SetTextFont(font)
	SetTextProportional(0)
	SetTextScale(scale, scale)
	SetTextColour(r, g, b, a)
	SetTextDropShadow(0, 0, 0, 0, 255)
	SetTextEdge(1, 0, 0, 0, 255)
	SetTextDropShadow()
	SetTextOutline()
	SetTextCentre(centre)
	SetTextEntry("STRING")
	AddTextComponentString(text)
	DrawText(x, y)
end

--[[ ////////////////////////////////////////// ]]

RegisterNetEvent("pil:visitkortse")
AddEventHandler("pil:visitkortse", function()
    TriggerServerEvent("pil:visitkort")
end)

RegisterNetEvent("pil:visitkortvis")
AddEventHandler("pil:visitkortvis", function()
    TriggerServerEvent("pil:visitkort")
end)

RegisterNetEvent("pil:kørekortse")
AddEventHandler("pil:kørekortse", function()
    TriggerServerEvent("pil:kørekort")
end)

RegisterNetEvent("pil:kørekortvis")
AddEventHandler("pil:kørekortvis", function()
    TriggerServerEvent("pil:kørekort")
end)

RegisterNetEvent("pil:sundhedskortse")
AddEventHandler("pil:sundhedskortse", function()
    TriggerServerEvent("pil:sundhedskort")
end)

RegisterNetEvent("pil:sundhedskortvis")
AddEventHandler("pil:sundhedskortvis", function()
    TriggerServerEvent("pil:sundhedskort")
end)

--[[ ////////////////////////////////////////// ]]

-- WHEN YOU RESTART THEN THE NUI NOT FREEZ
AddEventHandler("onResourceStop",function(a)if a==GetCurrentResourceName()then SetNuiFocus(false,false) end end)