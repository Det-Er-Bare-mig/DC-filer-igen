local perms = true
-------------------------------------------------
--                    Menu                     --
-------------------------------------------------

Citizen.CreateThread(function()
    while true do
		Citizen.Wait(1)
				local ped = GetPlayerPed()
				local pos = GetEntityCoords(PlayerPedId())
						for k,v in pairs(Config.Coords) do
                            if GetDistanceBetweenCoords(pos.x, pos.y, pos.z, v.x, v.y, v.z, true) < 3 then
                            DrawMarker(27, v.x, v.y, v.z-1.0, 0, 0, 0, 0, 0, 0, 1.001, 1.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                       --     0, 0, 0, 0, 0, 0, 3.001, 3.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50
                            if GetDistanceBetweenCoords(pos.x, pos.y, pos.z, v.x, v.y, v.z, true) <= 1 then
                            DrawText3Ds(v.x, v.y, v.z, "~b~[E]~w~ For at tilgå våbenbutikken")
                            if IsControlJustReleased(1, 51) then
                                TriggerEvent("shopmarked:OpenShopMenu1")
                            end
                        end
			end
		end
	end
end)

-------------------------------------------------
--                    MENU                     --
-------------------------------------------------

RegisterNetEvent("weaponshop:open")
AddEventHandler("weaponshop:open", function(open)
    if perms then
        TriggerEvent("shopmarked:OpenShopMenu1")
    end
  end
)

-------------------------------------------------
--                     UI                      --
-------------------------------------------------

RegisterNetEvent("shopmarked:OpenShopMenu1")
AddEventHandler("shopmarked:OpenShopMenu1", function ()
    SetNuiFocus(true, true)
    Citizen.Wait(100)
    SendNUIMessage({
        type = "openShopMenu1",
        weapon1 = Config.Weapon1,    
        weapon2 = Config.Weapon2,
        weapon3 = Config.Weapon3,
    })
end)

RegisterNetEvent("shopmarked:OpenShopMenu2")
AddEventHandler("shopmarked:OpenShopMenu2", function ()
    SetNuiFocus(true, true)
    Citizen.Wait(100)
    SendNUIMessage({
        type = "openShopMenu2",
        weapon4      = Config.Weapon4,    
        weapon5      = Config.Weapon5,
        weapon6      = Config.Weapon6,
    })
end)

RegisterNetEvent("shopmarked:OpenShopMenu3")
AddEventHandler("shopmarked:OpenShopMenu3", function ()
    SetNuiFocus(true, true)
    Citizen.Wait(100)
    SendNUIMessage({
        type = "openShopMenu3",
        weapon7      = Config.Weapon7,    
        weapon8      = Config.Weapon8,
        weapon9      = Config.Weapon9,
    })
end)


RegisterNUICallback("CloseMenu", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
end)

RegisterNUICallback("ChooseMenu1", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerEvent("shopmarked:OpenShopMenu1")
end)

RegisterNUICallback("ChooseMenu2", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerEvent("shopmarked:OpenShopMenu2")
end)

RegisterNUICallback("ChooseMenu3", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerEvent("shopmarked:OpenShopMenu3")
end)

RegisterNUICallback("ChooseWeapon1", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon1")
end)

RegisterNUICallback("ChooseWeapon2", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon2")
end)

RegisterNUICallback("ChooseWeapon3", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon3")
end)

RegisterNUICallback("ChooseWeapon4", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon4")
end)

RegisterNUICallback("ChooseWeapon5", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon5")
end)

RegisterNUICallback("ChooseWeapon6", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon6")
end)

RegisterNUICallback("ChooseWeapon7", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon7")
end)

RegisterNUICallback("ChooseWeapon8", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon8")
end)

RegisterNUICallback("ChooseWeapon9", function (data, callback)
    SetNuiFocus(false, false)
    callback("ok")
    TriggerServerEvent("betal:weapon9")
end)

-------------------------------------------------
--                     3D                      --
-------------------------------------------------

function DrawText3Ds(x,y,z, text)
local onScreen,_x,_y=World3dToScreen2d(x,y,z)
local px,py,pz=table.unpack(GetGameplayCamCoords())
	SetTextScale(0.35, 0.35)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text)) / 370
	DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
