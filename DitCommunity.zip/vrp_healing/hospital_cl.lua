local treatment = false
local timer = false

EMS1 = 0

local blips = {
    {name="Lægetjek", id=489, x= 312.35873413086, y= -592.7866821289, z= 42.284019470215, color= 1},
}


function ply_drawTxt(text,font,centre,x,y,scale,r,g,b,a)
    SetTextFont(font)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextCentre(centre)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x,y)
end

Citizen.CreateThread(function()
    for _, item in pairs(blips) do
        item.blip = AddBlipForCoord(item.x, item.y, item.z)
        SetBlipSprite(item.blip, item.id)
        SetBlipColour(item.blip, item.color)
        SetBlipAsShortRange(item.blip, true)
        SetBlipScale(item.blip, 0.8)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(item.name)
        EndTextCommandSetBlipName(item.blip)
    end
end)

function DrawText3Ds(x,y,z, text)
	local onScreen,_x,_y=World3dToScreen2d(x,y,z)
	local px,py,pz=table.unpack(GetGameplayCamCoords())

	SetTextScale(0.35, 0.35)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end

RegisterNetEvent('kaz:sendems')
AddEventHandler('kaz:sendems', function(ems)
EMS1 = ems
end)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for _, item in pairs(blips) do

            if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x, item.y, item.z, true) <= 20 then
                DrawMarker(27, item.x, item.y, item.z, 0, 0, 0, 0, 0, 0, 1.001, 1.0001, 1.5001, 0, 155, 255, 50, 0, 0, 0, 50)
                --DrawMarker(27, item.x, item.y, item.z, 0, 0, 0, 0, 0, 0, 1.001, 1.0001, 1.5001, 0, 155, 255, 50, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x,item.y,item.z, true) <= 2 then

                    if DelayOnThis then

                        DelayFalse()
                        TriggerEvent("pNotify:SendNotification",{text = "Delay besked.",type = "info",timeout = (15000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})

                    else
                        DrawText3Ds(item.x, item.y, item.z, "Tryk ~b~[E]~w~ for at blive tilset af en læge.")
                        if (IsControlJustPressed(0,38)) and (GetEntityHealth(GetPlayerPed(-1)) < 200) and not (GetEntityHealth(GetPlayerPed(-1)) == 105) and (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x, item.y, item.z, true) <= 2) then
                            if not DelayOnThis then
                                local ped = GetPlayerPed(-1)
                                local veh = GetVehiclePedIsUsing(ped)
                                if DoesEntityExist(veh) then
                                    if not DelayVehMsg then
                                        TriggerEvent("pNotify:SendNotification", {text = "🛑 Lægen kan ikke tilse dig når du sidder i et køretøj!", type = "error", timeout = 2000, layout = "bottomCenter"})
                                        DelayVehMsg = true
                                        Citizen.Wait(2000)
                                        DelayVehMsg = false
                                end
                                else
                                if EMS1 >= 3 then
                                TriggerEvent("pNotify:SendNotification",{text = "<h3>⛔️ Der er allerede læger i byen, kontakt dem via din telefon</h3><br><h5>Hvis der ingen læger er i byen, så tryk INSERT og prøv igen!</h5>",type = "success",timeout = (7500),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                                else
                                    treatment = true
                                    TriggerEvent("dc-animation:startWithItem", "notesblok")
                                    FreezeEntityPosition((GetPlayerPed(-1)), true) -- Freeze Entity
                                    exports['progressBars']:startUI(15000, "Lægen er ved at tilse dig...")
                                end
                            end
                            else
                                TriggerEvent("pNotify:SendNotification",{text = "Delay besked.",type = "info",timeout = (15000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                                DelayTrue()
                            end
                        end

                    end
                end
                if (IsControlJustPressed(0,38)) and (GetEntityHealth(GetPlayerPed(-1)) == 200) and (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x, item.y, item.z, true) <= 2) then
                    TriggerEvent("pNotify:SendNotification",{text = "✅ Du er helt rask.",type = "info",timeout = (4000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                end
                if treatment then
                    Citizen.Wait(15000)
                    timer = true
                end
                if treatment == true and timer == true and (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x, item.y, item.z, true) <= 2) then
                    TriggerServerEvent('hospital:price')
                    SetEntityHealth(GetPlayerPed(-1), 200)
                    TriggerEvent("pNotify:SendNotification",{text = "✅ Du er så god som ny!",type = "info",timeout = (4000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                    treatment = false
                    timer = false
                    FreezeEntityPosition((GetPlayerPed(-1)), false) -- Freeze Entity
                    TriggerEvent("dc-animation:stopAnim", "notesblok")
                end
                if treatment == true and timer == true and (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), item.x, item.y, item.z, true) > 2) then
                    TriggerEvent("pNotify:SendNotification",{text = "🛑 Du gik væk fra lægen, og blev derfor ikke tilset færdigt.",type = "info",timeout = (4000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                    treatment = false
                    timer = false
                end
            end
        end
    end
end)


Citizen.CreateThread(function()

    RequestModel(GetHashKey("s_m_m_doctor_01"))
    while not HasModelLoaded(GetHashKey("s_m_m_doctor_01")) do
        Wait(1)
    end
    local hospitalped =  CreatePed(4, 0xd47303ac, 338.85, -1394.56, 31.51, 49.404, false, true)
    SetEntityHeading(hospitalped, 49.404)
    FreezeEntityPosition(hospitalped, true)
    SetEntityInvincible(hospitalped, true)
    SetBlockingOfNonTemporaryEvents(hospitalped, true)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_casey"))
    while not HasModelLoaded(GetHashKey("ig_casey")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xe0fa2554, 1628.3411865234, 2543.0483398438, 44.564861297607, 318.69863891602, false, true)
    SetEntityHeading(caseyped, 318.69863891602)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_COP_IDLES")
    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_bankman"))
    while not HasModelLoaded(GetHashKey("cs_bankman")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x9760192e, -1159.9146728516,-1718.5594482422,3.9049320220947,303.36206054688, false, true)
    SetEntityHeading(caseyped, 303.36206054688)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_COP_IDLES")
    RequestAnimDict("mp_safehousebeer@")
    TaskPlayAnim(caseyped, "mp_safehousebeer@", "base_drink", 8.0, 8.0, -1, 50, 0, false, false, false)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_dale"))
    while not HasModelLoaded(GetHashKey("cs_dale")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x0ce81655, -1375.46484375,-628.11016845703,29.819562911987,34.907833099365, false, true)
    SetEntityHeading(caseyped, 34.907833099365)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_f_y_bartender_01"))
    while not HasModelLoaded(GetHashKey("s_f_y_bartender_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x780c01bd, -1391.6208496094,-605.7412109375,29.319547653198,117.3715057373, false, true)
    SetEntityHeading(caseyped, 117.3715057373)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_m_y_barman_01"))
    while not HasModelLoaded(GetHashKey("s_m_y_barman_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xe5a11106, -561.75408935547,286.58889770508,81.176399230957,262.00085449219, false, true)
    SetEntityHeading(caseyped, 262.00085449219)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("u_f_y_bikerchic"))
    while not HasModelLoaded(GetHashKey("u_f_y_bikerchic")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xfa389d4f, -564.27783203125,279.2751159668,81.976707458496,173.14450073242, false, true)
    SetEntityHeading(caseyped, 173.14450073242)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_m_m_tranvest_01"))
    while not HasModelLoaded(GetHashKey("a_m_m_tranvest_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xe0e69974, 1984.2738037109,3054.4206542969,46.215156555176,236.25871276855, false, true)
    SetEntityHeading(caseyped, 236.25871276855)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
end)
-- Karsten Kanyle starter her
Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_chef"))
    while not HasModelLoaded(GetHashKey("csb_chef")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xa347ca8a, 468.34915161133,-728.70190429688,26.365694046021,139.04251098633, false, true)
    SetEntityHeading(caseyped, 139.04251098633)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_SMOKING")
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_chef"))
    while not HasModelLoaded(GetHashKey("csb_chef")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xa347ca8a, -29.428693771362,-1979.8030273438,4.5072467803955,60.083408355713, false, true)
    SetEntityHeading(caseyped, 60.083408355713)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_BUM_SLUMPED")
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_chef"))
    while not HasModelLoaded(GetHashKey("csb_chef")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xa347ca8a, -837.93676757813,-135.29945373535,27.184965133667,33.264755249023, false, true)
    SetEntityHeading(caseyped, 33.264755249023)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STAND_IMPATIENT")
end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("mp_m_g_vagfun_01"))
    while not HasModelLoaded(GetHashKey("mp_m_g_vagfun_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xC4A617BD, -1890.3912353516,2091.3488769531,140.10940551758,277.64846801758, false, true)
    SetEntityHeading(caseyped, 277.64846801758)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_LEANING")

    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 1, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("mp_m_g_vagfun_01"))
    while not HasModelLoaded(GetHashKey("mp_m_g_vagfun_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xC4A617BD, 568.56848144531,-3116.3723144531,17.768402099609,176.65357971191, false, true)
    SetEntityHeading(caseyped, 176.65357971191)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_LEANING")

    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 1, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_vagspeak"))
    while not HasModelLoaded(GetHashKey("ig_vagspeak")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xF9FD068C, -1887.8520507813,2093.1613769531,139.99267578125,163.65740966797, false, true)
    SetEntityHeading(caseyped, 163.65740966797)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_SMOKING")

    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_vagspeak"))
    while not HasModelLoaded(GetHashKey("ig_vagspeak")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xF9FD068C, -1889.6057128906,2089.7673339844,139.9945526123,284.94931030273, false, true)
    SetEntityHeading(caseyped, 284.94931030273)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "PROP_HUMAN_BUM_SHOPPING_CART")


    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_vagspeak"))
    while not HasModelLoaded(GetHashKey("ig_vagspeak")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xF9FD068C, 566.17388916016,-3117.7312011719,17.768579483032,243.12469482422, false, true)
    SetEntityHeading(caseyped, 243.12469482422)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "PROP_HUMAN_BUM_SHOPPING_CART")


    RequestAnimDict("amb@world_human_hang_out_street@male_c@base")
    TaskPlayAnim(caseyped, "amb@world_human_hang_out_street@male_c@base", "base", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_vagspeak"))
    while not HasModelLoaded(GetHashKey("ig_vagspeak")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xF9FD068C, 586.64782714844,-3119.2038574219,17.711666107178,269.76547241211, false, true)
    SetEntityHeading(caseyped, 269.76547241211)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STAND_MOBILE_UPRIGHT")


    --RequestAnimDict("amb@world_human_hang_out_street@male_c@base")
    --TaskPlayAnim(caseyped, "amb@world_human_hang_out_street@male_c@base", "base", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_c_rottweiler"))
    while not HasModelLoaded(GetHashKey("a_c_rottweiler")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x9563221d, -1890.5649414063,2092.2463378906,139.99348449707,238.13929748535, false, true)
    SetEntityHeading(caseyped, 238.13929748535)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_c_rottweiler"))
    while not HasModelLoaded(GetHashKey("a_c_rottweiler")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x9563221d, 567.40246582031,-3116.6899414063,18.800747756958,204.8321685791, false, true)
    SetEntityHeading(caseyped, 223.79219055176)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    --RequestAnimDict("amb@prop_human_seat_chair@male@left_elbow_on_knee@base")
    --TaskPlayAnim(caseyped, "amb@prop_human_seat_chair@male@left_elbow_on_knee@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
-- Bahama Mammas starter her
Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_stripper_01"))
    while not HasModelLoaded(GetHashKey("csb_stripper_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xaeea76b5, -1383.4692382813,-612.19390869141,30.707844924927,118.58304595947, false, true)
    SetEntityHeading(caseyped, 118.58304595947)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("mini@strip_club@private_dance@part2")
    TaskPlayAnim(caseyped, "mini@strip_club@private_dance@part2", "priv_dance_p2", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_stripper_01"))
    while not HasModelLoaded(GetHashKey("csb_stripper_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xaeea76b5, -1380.0822753906,-617.560546875,30.758071899414,121.59293365479, false, true)
    SetEntityHeading(caseyped, 121.59293365479)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("mini@strip_club@private_dance@part1")
    TaskPlayAnim(caseyped, "mini@strip_club@private_dance@part1", "priv_dance_p1", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("g_m_y_famca_01"))
    while not HasModelLoaded(GetHashKey("g_m_y_famca_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xe83b93b7, -1381.7045898438,-625.33160400391,30.301984786987,12.272229194641, false, true)
    SetEntityHeading(caseyped, 12.272229194641)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("missfbi3_sniping")
    TaskPlayAnim(caseyped, "missfbi3_sniping", "dance_m_default", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("g_f_y_families_01"))
    while not HasModelLoaded(GetHashKey("g_f_y_families_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x4e0ce5d3, -1380.6751708984,-624.92950439453,30.301984786987,34.039691925049, false, true)
    SetEntityHeading(caseyped, 34.039691925049)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("missfbi3_sniping")
    TaskPlayAnim(caseyped, "missfbi3_sniping", "dance_m_default", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("g_m_y_famdnf_01"))
    while not HasModelLoaded(GetHashKey("g_m_y_famdnf_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xdb729238, -1379.6878662109,-623.91058349609,30.301984786987,67.23811340332, false, true)
    SetEntityHeading(caseyped, 67.23811340332)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("missfbi3_sniping")
    TaskPlayAnim(caseyped, "missfbi3_sniping", "dance_m_default", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_f_y_genhot_01"))
    while not HasModelLoaded(GetHashKey("a_f_y_genhot_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x2f4aec3e, -1388.5895996094,-625.24615478516,30.30008097229,333.29211425781, false, true)
    SetEntityHeading(caseyped, 333.29211425781)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_DOG_SITTING_RETRIEVER")

    RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_m_y_hipster_01"))
    while not HasModelLoaded(GetHashKey("a_m_y_hipster_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x2307a353, -1389.7907714844,-619.00823974609,29.819576263428,311.63220214844, false, true)
    SetEntityHeading(caseyped, 311.63220214844)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STRIP_WATCH_STAND")

    --RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    --TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_f_y_hooker_03"))
    while not HasModelLoaded(GetHashKey("s_f_y_hooker_03")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x031640ac, -1387.5943603516,-616.98559570313,29.819576263428,290.42901611328, false, true)
    SetEntityHeading(caseyped, 290.42901611328)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STRIP_WATCH_STAND")

    RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_m_y_juggalo_01"))
    while not HasModelLoaded(GetHashKey("a_m_y_juggalo_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x91ca3e2c, -1383.4265136719,-620.10192871094,29.819580078125,69.387283325195, false, true)
    SetEntityHeading(caseyped, 69.387283325195)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_PARTYING")

    --RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    --TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_jewelass"))
    while not HasModelLoaded(GetHashKey("cs_jewelass")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x4440a804, -1385.1784667969,-621.39691162109,29.819580078125,353.64236450195, false, true)
    SetEntityHeading(caseyped, 353.64236450195)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_PARTYING")

    --RequestAnimDict("rcmnigel1bnmt_1b")
    --TaskPlayAnim(caseyped, "rcmnigel1bnmt_1b", "dance_loop_tyler", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_f_y_rurmeth_01"))
    while not HasModelLoaded(GetHashKey("a_f_y_rurmeth_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x3f789426, -1388.072265625,-620.94281005859,29.819580078125,11.870373725891, false, true)
    SetEntityHeading(caseyped, 11.870373725891)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STRIP_WATCH_STAND")

    RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_russiandrunk"))
    while not HasModelLoaded(GetHashKey("cs_russiandrunk")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x46521a32, -1387.7486572266,-614.61981201172,29.819580078125,290.14810180664, false, true)
    SetEntityHeading(caseyped, 290.14810180664)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STRIP_WATCH_STAND")

    RequestAnimDict("mini@strip_club@idles@dj@base")
    TaskPlayAnim(caseyped, "mini@strip_club@idles@dj@base", "base", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_f_y_scdressy_01"))
    while not HasModelLoaded(GetHashKey("a_f_y_scdressy_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xdb5ec400, -1390.1226806641,-616.37023925781,29.819564819336,256.57159423828, false, true)
    SetEntityHeading(caseyped, 256.57159423828)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STRIP_WATCH_STAND")

    RequestAnimDict("missfbi3_sniping")
    TaskPlayAnim(caseyped, "missfbi3_sniping", "dance_m_default", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_f_y_juggalo_01"))
    while not HasModelLoaded(GetHashKey("a_f_y_juggalo_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xdb134533, -1383.4411621094,-619.14562988281,29.819561004639,96.337471008301, false, true)
    SetEntityHeading(caseyped, 96.337471008301)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_PARTYING")

    --RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    --TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
-- Bahama mammas slutter her
Citizen.CreateThread(function()
    RequestModel(GetHashKey("u_m_y_tattoo_01"))
    while not HasModelLoaded(GetHashKey("u_m_y_tattoo_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x94ae2b8c, -2186.9040527344,4249.9233398438,47.939937591553,34.756736755371, false, true)
    SetEntityHeading(caseyped, 34.756736755371)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_CLIPBOARD")

    --RequestAnimDict("misschinese2_crystalmazemcs1_cs")
    --TaskPlayAnim(caseyped, "misschinese2_crystalmazemcs1_cs", "dance_loop_tao", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("u_m_y_tattoo_01"))
    while not HasModelLoaded(GetHashKey("u_m_y_tattoo_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x94ae2b8c, -607.38500976563,-1629.8386230469,26.010812759399,263.42895507813, false, true)
    SetEntityHeading(caseyped, 263.42895507813)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    --TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_CLIPBOARD")

    RequestAnimDict("amb@world_human_drug_dealer_hard@male@idle_a")
    TaskPlayAnim(caseyped, "amb@world_human_drug_dealer_hard@male@idle_a", "idle_c", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_omega"))
    while not HasModelLoaded(GetHashKey("cs_omega")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x8b70b405, 1126.1494140625,-980.21728515625,44.415744781494,185.19454956055, false, true)
    SetEntityHeading(caseyped, 185.19454956055)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_DRUG_DEALER")

    --RequestAnimDict("amb@world_human_drug_dealer_hard@male@idle_a")
    --TaskPlayAnim(caseyped, "amb@world_human_drug_dealer_hard@male@idle_a", "idle_c", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("u_m_y_hippie_01"))
    while not HasModelLoaded(GetHashKey("u_m_y_hippie_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xf041880b, 1407.0301513672,3666.0280761719,33.064743041992,58.300922393799, false, true)
    SetEntityHeading(caseyped, 58.300922393799)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_DRUG_DEALER")

    --RequestAnimDict("amb@world_human_drug_dealer_hard@male@idle_a")
    --TaskPlayAnim(caseyped, "amb@world_human_drug_dealer_hard@male@idle_a", "idle_c", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_f_y_migrant_01"))
    while not HasModelLoaded(GetHashKey("s_f_y_migrant_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xd55b2bf5, 657.76196289063,-789.42834472656,23.549493789673,179.82698059082, false, true)
    SetEntityHeading(caseyped, 179.82698059082)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "PROP_HUMAN_PARKING_METER")

    --RequestAnimDict("amb@world_human_drug_dealer_hard@male@idle_a")
    --TaskPlayAnim(caseyped, "amb@world_human_drug_dealer_hard@male@idle_a", "idle_c", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_m_m_migrant_01"))
    while not HasModelLoaded(GetHashKey("s_m_m_migrant_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0xed0ce4c6, 656.22442626953,-789.25579833984,23.549493789673,273.49267578125, false, true)
    SetEntityHeading(caseyped, 273.49267578125)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_CLIPBOARD")

    --RequestAnimDict("amb@world_human_drug_dealer_hard@male@idle_a")
    --TaskPlayAnim(caseyped, "amb@world_human_drug_dealer_hard@male@idle_a", "idle_c", 8.0, 8.0, -1, 1, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("cs_omega"))
    while not HasModelLoaded(GetHashKey("cs_omega")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x8b70b405, -1171.0771484375,-1571.0153808594,3.6636214256287,123.35715484619, false, true)
    SetEntityHeading(caseyped, 123.35715484619)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_DRUG_DEALER")

    --RequestAnimDict("anim@safehouse@bong")
    --TaskPlayAnim(caseyped, "anim@safehouse@bong", "bong__stage1", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_m_y_methhead_01"))
    while not HasModelLoaded(GetHashKey("a_m_y_methhead_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x696be0a9, 2434.1123046875,4969.482421875,41.347576141357,13.397799491882, false, true)
    SetEntityHeading(caseyped, 13.397799491882)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "PROP_HUMAN_PARKING_METER")

    --RequestAnimDict("anim@safehouse@bong")
    --TaskPlayAnim(caseyped, "anim@safehouse@bong", "bong__stage1", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("a_f_y_rurmeth_01"))
    while not HasModelLoaded(GetHashKey("a_f_y_rurmeth_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x3f789426, 31.707141876221,3669.8942871094,39.440631866455,66.72925567627, false, true)
    SetEntityHeading(caseyped, 66.72925567627)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "PROP_HUMAN_PARKING_METER")

    --RequestAnimDict("anim@safehouse@bong")
    --TaskPlayAnim(caseyped, "anim@safehouse@bong", "bong__stage1", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_f_y_baywatch_01"))
    while not HasModelLoaded(GetHashKey("s_f_y_baywatch_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x4a8e5536, -2021.5544433594,-1044.8266601563,1.4467449188232,198.69834899902, false, true)
    SetEntityHeading(caseyped, 198.69834899902)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_STAND_FISHING")

    --RequestAnimDict("anim@safehouse@bong")
    --TaskPlayAnim(caseyped, "anim@safehouse@bong", "bong__stage1", 8.0, 8.0, -1, 50, 0, false, false, false)


end)
Citizen.CreateThread(function()
    RequestModel(GetHashKey("s_m_y_baywatch_01"))
    while not HasModelLoaded(GetHashKey("s_m_y_baywatch_01")) do
        Wait(1)
    end
    local caseyped =  CreatePed(4, 0x0b4a6862, -2017.3350830078,-1040.1569824219,1.4472992420197,249.64794921875, false, true)
    SetEntityHeading(caseyped, 249.64794921875)
    FreezeEntityPosition(caseyped, true)
    SetEntityInvincible(caseyped, true)
    SetBlockingOfNonTemporaryEvents(caseyped, true)
    TaskStartScenarioInPlace(caseyped, "WORLD_HUMAN_BINOCULARS")

    --RequestAnimDict("anim@safehouse@bong")
    --TaskPlayAnim(caseyped, "anim@safehouse@bong", "bong__stage1", 8.0, 8.0, -1, 50, 0, false, false, false)


end)