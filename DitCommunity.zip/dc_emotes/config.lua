
config = {}

config.animWhileDead = "Du kan ikke bruge animationer, når du er død"
config.animWhileHandcuffed = "Du kan ikke bruge animationer i håndjern"
config.animInWater = "Du kan ikke bruge animationer i vandet"
config.animInVeh = "Du kan ikke bruge animationer i et køretøj"