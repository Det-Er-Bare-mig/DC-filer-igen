vcf_files = {
	"AMBULANCE.xml",
	"FBI.xml",
	"FBI2.xml",
	"mercedesems.xml",
	"POLICE.xml",
	"POLICE2.xml",
	"POLICE3.xml",
	"POLICE4.xml",
	"POLICEB.xml",
	"POLICEOLD2.xml",
	"SHERIFF.xml",
	"FLATBED.xml",
	"SHERIFF2.xml",
	"PBUS.xml",
	"POLICE3.xml",
	"POLICE.xml",
	"BMWGRAND.xml",
	"BMWEMS.xml",
	"TOURANEMS.xml",
	"POLICE2.xml",
	"FLATBED.xml",
	"paramed.xml",
	"politibmwx5m.xml",
	"POLICE5.xml",
	"POLICE7.xml",
	"POLITIM5.xml",
	"POLICEB1.xml",
	"POLICEOLD5.xml",
	"JAGUARXFRS.xml",
	"hauler.xml",
	"POLICE6.xml",
	"TOURANC.xml",
	"POLICEGT350R.xml",
	"POLICERS6.xml",
	"FBIRS6.xml",
	"POLICEB2.xml",
	"KEVIN.xml",
	"vwems.xml"
}

pattern_files = {
	"WIGWAG.xml",
	"WIGWAG3.xml",
	"FAST.xml",
	"COMPLEX.xml",
	"TOURANC.xml",
	"BACKFOURTH.xml",
	"hauler.xml",
	"BACKFOURTH2.xml",
	"T_ADVIS_RIGHT_LEFT.xml",
	"T_ADVIS_LEFT_RIGHT.xml",
	"T_ADVIS_BACKFOURTH.xml",
	"WIGWAG5.xml"
}

modelsWithTrafficAdvisor = {
	"AMBULANCE.xml",
	"FBI.xml",
	"FBI2.xml",
	"mercedesems.xml",
	"POLICE.xml",
	"POLICE2.xml",
	"POLICE3.xml",
	"POLICE4.xml",
	"POLICEB.xml",
	"POLICEOLD2.xml",
	"SHERIFF.xml",
	"TOURANC.xml",
	"FLATBED.xml",
	"hauler.xml",
	"SHERIFF2.xml",
	"PBUS.xml",
	"POLICE3.xml",
	"POLICE.xml",
	"BMWGRAND.xml",
	"POLICE2.xml",
	"FLATBED.xml",
	"politibmwx5m.xml",
	"POLICE5.xml",
	"POLICE7.xml",
	"POLITIM5.xml",
	"POLICEB1.xml",
	"POLICEOLD5.xml",
	"JAGUARXFRS.xml",
	"POLICE6.xml",
	"POLICEGT350R.xml",
	"POLICERS6.xml",
	"FBIRS6.xml",
	"POLICEB2.xml",
	"KEVIN.xml",
	"vwems.xml"
}

modelsWithFireSiren =
{
    "FIRETRUK",
}

modelsWithAmbWarnSiren =
{   
    "AMBULANCE",
	"AMBUCAR",
	"AKUT2",
    "FIRETRUK",
    "LGUARD",
}

stagethreewithsiren = false
playButtonPressSounds = true
vehicleStageThreeAdvisor = {
	"AMBULANCE.xml",
	"FBI.xml",
	"FBI2.xml",
	"mercedesems.xml",
	"POLICE.xml",
	"POLICE2.xml",
	"POLICE3.xml",
	"POLICE4.xml",
	"POLICEB.xml",
	"POLICEOLD2.xml",
	"SHERIFF.xml",
	"FLATBED.xml",
	"SHERIFF2.xml",
	"PBUS.xml",
	"POLICE3.xml",
	"POLICE.xml",
	"BMWGRAND.xml",
	"POLICE2.xml",
	"hauler.xml",
	"FLATBED.xml",
	"politibmwx5m.xml",
	"POLICE5.xml",
	"POLICE7.xml",
	"POLITIM5.xml",
	"POLICEB1.xml",
	"POLICEOLD5.xml",
	"JAGUARXFRS.xml",
	"POLICE6.xml",
	"POLICEGT350R.xml",
	"POLICERS6.xml",
	"TOURANC.xml",
	"FBIRS6.xml",
	"POLICEB2.xml",
	"KEVIN.xml",
	"vwems.xml"
}


vehicleSyncDistance = 150
envirementLightBrightness = 0.2

build = "master"

shared = {
	horn = 86,
}

keyboard = {
	modifyKey = 132,
	stageChange = 85,
	guiKey = 243,
	takedown = 245,
	siren = {
		tone_one = 157,
		tone_two = 158,
		tone_three = 160,
		dual_toggle = 164,
		dual_one = 165,
		dual_two = 159,
		dual_three = 161,
	},
	pattern = {
		primary = 246,
		secondary = 303,
		advisor = 182,
	},
}

controller = {
	modifyKey = 73,
	stageChange = 80,
	takedown = 74,
	siren = {
		tone_one = 173,
		tone_two = 85,
		tone_three = 172,
	},
}