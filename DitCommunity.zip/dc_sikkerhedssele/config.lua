Cfg             = {}
Cfg.DiffTrigger = 0.255 
Cfg.MinSpeed    = 8.25 --THIS IS IN m/s
--Cfg.Strings     = { belt_on = '✅ Sikkerhedssele fastspændt.', belt_off = '⛔️ Sikkerhedssele løsnet.' }
