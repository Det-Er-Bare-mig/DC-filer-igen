-----------------------------------------------------------
--                      Citizens                         --
-----------------------------------------------------------
local Blips = true
local delay = 1000
local spawn = true
local place1 = false
local place2 = false
local place3 = false
local garage = true
local park = false
local menuopen = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while garage do
            delay = 1
            Citizen.Wait(delay)
            for k,v in pairs(Config.Coords) do
                if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), v.x, v.y, v.z, true ) <= 4 then
                  --  DrawMarker(27, v.x, v.y, v.z-0.8, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 2.0, 2.0, 0.1, 11, 149, 230, 150, false, true, 2, nil, nil, false)
                    DrawMarker(27, v.x, v.y, v.z-0.9, 0, 0, 0, 0, 0, 0, 1.001, 1.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                    if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), v.x, v.y, v.z, true ) <= 2 then
                    DrawText3Ds(v.x,v.y,v.z, "Tryk ~b~[E]~s~ for at åbne ~b~Læge Garage~s~ ", 3.0, 7)
                    if IsControlJustPressed(1, 38) then
                        garage = false
                        menuopen = true
                        TriggerServerEvent("garage:enter")
                        TriggerEvent("reset:local")
                    end
                  end
                end
            end
        end
        delay = 1000
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while park do
            delay = 1
            Citizen.Wait(delay)
            for k,v in pairs(Config.Parkcoords) do
                if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), v.x, v.y, v.z, true ) <= 6 then
                    DrawMarker(27, v.x, v.y, v.z-0.8, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 2.0, 2.0, 0.2, 11, 149, 230, 150, false, true, 2, nil, nil, false)
                    if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), v.x, v.y, v.z, true ) <= 2 then
                    DrawText3Ds(v.x,v.y,v.z, "Tryk ~b~[E]~s~ for at parkere ~b~Læge Bil~s~ ", 3.0, 7)
                    if IsControlJustPressed(1, 38) then
                        TriggerServerEvent("park")
                    end
                end
            end
            delay = 1000
        end
    end
    end
end)

Citizen.CreateThread(function()
    if Blips then
      for k,v in ipairs(Config.Coords) do
        local blip = AddBlipForCoord(v.x, v.y, v.z)
        SetBlipSprite(blip, 61)
        SetBlipScale(blip, 1.0)
        SetBlipColour(blip, 38)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING");
        AddTextComponentString("Ems Garage")
        EndTextCommandSetBlipName(blip)
      end
    end
end)

Citizen.CreateThread(function ()
    while true do
    local ped = PlayerPedId()
        Citizen.Wait(delay)
        if IsPedInAnyVehicle(ped, true) then
            garage = false
            park = true
        elseif menuopen then
            park = false
            menuopen = false
        else
            garage = true
            park = false
        end
    end
end)

-----------------------------------------------------------
--                      EVENTS                           --
-----------------------------------------------------------

RegisterNetEvent("spawncar")
AddEventHandler("spawncar", function(car)
    local ped = PlayerPedId()
    SendNUIMessage({status = false})
    SetNuiFocus(false,false)
    for k,v in pairs(Config.Spawncoords) do
        if k == "coords" then
            Bil = car
            RequestModel(GetHashKey(Bil));
                while not HasModelLoaded(GetHashKey(Bil)) do
                RequestModel(GetHashKey(Bil));
                Wait(50)
            end
            if place1 then
                vehicle = CreateVehicle(GetHashKey(Bil), v.pos.x,v.pos.y,v.pos.z,v.pos.h, true, false)
                Wait(500)
                SetPedIntoVehicle(ped,vehicle,-1)
                place1 = false
            elseif place2 then
                vehicle = CreateVehicle(GetHashKey(Bil), v.pos2.x,v.pos2.y,v.pos2.z,v.pos2.h, true, false)
                Wait(500)
                SetPedIntoVehicle(ped,vehicle,-1)
                place2 = false
            elseif place3 then
                vehicle = CreateVehicle(GetHashKey(Bil), v.pos3.x,v.pos3.y,v.pos3.z,v.pos3.h, true, false)
                Wait(500)
                SetPedIntoVehicle(ped,vehicle,-1)
                place3 = false
            end
        end
    end
end)

RegisterNetEvent("checkplace")
AddEventHandler("checkplace", function(car)
    Citizen.CreateThread(function ()
        while true do
            Citizen.Wait(1)
            if spawn then
                for k,v in pairs(Config.Spawncoords) do
                    if k == "coords" then
                        if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.pos.x, v.pos.y, v.pos.z, true) <= 100 then
                            spawn = false
                            place1 = true
                            TriggerEvent("spawncar", car)
                        elseif GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.pos2.x, v.pos2.y, v.pos2.z, true) <= 100 then
                            spawn = false
                            place2 = true
                            TriggerEvent("spawncar", car)
                        elseif GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.pos3.x, v.pos3.y, v.pos3.z, true) <= 100 then
                            spawn = false
                            place3 = true
                            TriggerEvent("spawncar", car)
                        end
                    end
                end
            end
            break
        end
    end)
end)

RegisterNetEvent("reset:local")
AddEventHandler("reset:local", function()
    spawn = true
end)

RegisterNetEvent("park:client")
AddEventHandler("park:client", function()
    local ped = PlayerPedId()
    local car = GetVehiclePedIsIn(ped, true)
    TaskLeaveVehicle(ped, car)
    Wait(2000)
    SetEntityAsMissionEntity(car,true,true)
    DeleteVehicle(car)
end)

-----------------------------------------------------------
--                     Menu build                        --
-----------------------------------------------------------

RegisterNetEvent("dc_emsgarage:open")
AddEventHandler("dc_emsgarage:open", function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "emspage",
        status = true,
        carname1 = Config.car1name,
        carname2 = Config.car2name,
        carname3 = Config.car3name,
        carname4 = Config.car4name,
        carname5 = Config.car5name,
        carname6 = Config.car6name,
        carname7 = Config.car7name,
        carname8 = Config.car8name,
        carname9 = Config.car9name,
        carname10 = Config.car10name,
        carname11 = Config.car11name,
        carname12 = Config.car12name
    })
end)

-----------------------------------------------------------
--                      Callbacks                        --
-----------------------------------------------------------

RegisterNUICallback("close", function (data, callback)
    SetNuiFocus(false, false)
    garage = false
end)

RegisterNUICallback("bil1", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car1
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil2", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car2
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil3", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car3
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil4", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car4
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil5", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car5
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil6", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car6
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil7", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car7
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil8", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car8
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil9", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car9
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil10", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car10
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil11", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car11
    TriggerServerEvent("spawn:check", car)
end)

RegisterNUICallback("bil12", function (data, callback)
    SetNuiFocus(true, true)
    car = Config.car12
    TriggerServerEvent("spawn:check", car)
end)

-----------------------------------------------------------
--                        3D                             --
-----------------------------------------------------------

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end

-----------------------------------------------------------
--                       NUI                             --
-----------------------------------------------------------

AddEventHandler("onResourceStop",function(a)if a==GetCurrentResourceName()then SetNuiFocus(false,false) end end)