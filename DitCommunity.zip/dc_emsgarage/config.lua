Config = {}
-----------------------------------------
--              DIVERSE                --
-----------------------------------------
Config.perm = 'ems.vehicle'
-----------------------------------------
--               COORDS                --
-----------------------------------------
Config.Coords = {
    {x =294.58764648438,y =-594.42742919922,z =43.25074005127}, -- 294.58764648438,-594.42742919922,43.25074005127 -- Byen
    {x =1827.5225830078,y =3691.5432128906,z =34.22424697876}, -- 1827.5225830078,3691.5432128906,34.22424697876 -- Sandy
    {x =-242.81532287598,y =6325.40234375,z =32.426177978516} -- -242.81532287598,6325.40234375,32.426177978516 -- Paleto
}

Config.Parkcoords = {
    {x =288.59921264648,y =-595.71697998047,z =43.181106567383}, -- 288.59921264648,-595.71697998047,43.181106567383 -- Byen
    {x =1827.6134033203,y =3693.7058105469,z =34.224269866943}, -- 1827.6134033203,3693.7058105469,34.224269866943 -- Sandy
    {x =-252.43876647949,y =6347.1508789063,z =32.403274536133} -- -252.43876647949,6347.1508789063,32.403274536133 -- Paleto
}

Config.Spawncoords = {
    ["coords"] = {
        pos = {x =285.97219848633,y =-613.20294189453,z =44.387035369873,h =70.00}, -- 285.97219848633,-613.20294189453,43.387035369873 -- Byen
        pos2 = {x =1832.7995605469,y =3696.634765625,z =34.224273681641,h =300.00}, -- 1832.7995605469,3696.634765625,34.224273681641 -- Sandy
        pos3 = {x =-258.19369506836,y =6347.693359375,z =32.426391601563,h =270.00}, -- -258.19369506836,6347.693359375,32.426391601563 -- Paleto
    },
}
-----------------------------------------
--              NAVNE I UI             --
-----------------------------------------
Config.car1name = 'Ambulance' -- Bil 1 i ui'ets navn
Config.car2name = 'Volkswagen' -- Bil 2 i ui'ets navn
Config.car3name = 'Audi' -- Bil 3 i ui'ets navn
Config.car4name = 'Touran' -- Bil 4 i ui'ets navn
Config.car5name = 'BMW' -- Bil 5 i ui'ets navn
Config.car6name = 'Audi RS6' -- Bil 6 i ui'ets navn
Config.car7name = 'Mercedes' -- Bil 7 i ui'ets navn
Config.car8name = 'Ingen' -- Bil 8 i ui'ets navn
Config.car9name = 'Ingen' -- Bil 9 i ui'ets navn
Config.car10name = 'Ingen' -- Bil 10 i ui'ets navn
Config.car11name = 'Ingen' -- Bil 11 i ui'ets navn
Config.car12name = 'Ingen' -- Bil 12 i ui'ets navn
-----------------------------------------
--                BILER                --
-----------------------------------------
Config.car1 = 'ambulance' -- Spawnkoden til bil 1 i ui
Config.car2 = 'vwems' -- Spawnkoden til bil 2 i ui
Config.car3 = 'audiems' -- Spawnkoden til bil 3 i ui
Config.car4 = 'touranems' -- Spawnkoden til bil 4 i ui
Config.car5 = 'bmwems' -- Spawnkoden til bil 5 i ui
Config.car6 = 'paramed' -- Spawnkoden til bil 6 i ui
Config.car7 = 'mercedesems' -- Spawnkoden til bil 7 i ui
Config.car8 = '' -- Spawnkoden til bil 8 i ui
Config.car9 = '' -- Spawnkoden til bil 9 i ui
Config.car10 = '' -- Spawnkoden til bil 10 i ui
Config.car11 = '' -- Spawnkoden til bil 11 i ui
Config.car12 = '' -- Spawnkoden til bil 12 i ui 
-----------------------------------------
--                NOTIFY               --
-----------------------------------------
Config.ikke = 'Dette er ikke et køretøj'
Config.success = 'Du tog bil ud af garagen'
Config.adgang = 'Du har ikke adgang'
-----------------------------------------
--                INFO                 --
-----------------------------------------
-- Ikke skriv i '' vis du ikke vil have den spawner en bil så skriver den dette er ikke en bil -- DETTE ER UNDER KATEGORIEN BILER