Citizen.CreateThread(function() 
	while true do
	  N_0xf4f2c0d4ee209e20() 
	  Wait(1000)
	end 
  end)