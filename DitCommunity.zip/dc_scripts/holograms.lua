
Citizen.CreateThread(function()
    Holograms()
end)

function Holograms()
		while true do
			Citizen.Wait(0)			
				-- Hologram No. 1
		if GetDistanceBetweenCoords( 233.57,-403.55,47.92, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
			Draw3DText( 233.57,-403.55,47.92 -1.400, "Velkommen Til DitCommunity™", 4, 0.1, 0.1)
			Draw3DText( 233.57,-403.55,47.92 -1.600, "Husk og læs vores regler på discord!", 4, 0.1, 0.1)
			Draw3DText( 233.57,-403.55,47.92 -1.800, "Nyd dit ophold!", 4, 0.1, 0.1)		
		end		
		if GetDistanceBetweenCoords( 242.45,-406.52,47.92, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
			Draw3DText( 242.45,-406.52,47.92 -1.400, "Velkommen Til DitCommunity™", 4, 0.1, 0.1)
			Draw3DText( 242.45,-406.52,47.92 -1.600, "Husk og læs vores regler på discord!", 4, 0.1, 0.1)
			Draw3DText( 242.45,-406.52,47.92 -1.800, "Nyd dit ophold!", 4, 0.1, 0.1)		
		end		
		--Hologram No. 2
		if GetDistanceBetweenCoords(237.82,-405.05,47.92, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
		Draw3DText( 237.82,-405.05,47.92 -1.400, "Discord: Discord.gg/WmU4Srn", 4, 0.1, 0.1)
		Draw3DText( 237.82,-405.05,47.92 -1.600, "Website: www.DitCommunity.dk", 4, 0.1, 0.1)
		Draw3DText( 237.82,-405.05,47.92 -1.800, "Udvikler: Nixdk", 4, 0.1, 0.1)	
		end
	 if GetDistanceBetweenCoords( 238.18,-412.18,48.11, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
		Draw3DText( 237.70631408691,-415.49392700195,47.948097229004 -1.400, "Skift identitet", 4, 0.1, 0.1)
	    Draw3DText( 237.9271697998,-412.01062011719,47.947887420654 -1.400, "Skift dit job", 4, 0.1, 0.1)	----242.57331848145,-410.85018920898,47.924320220947			
	    Draw3DText( 235.98139953613,-418.27935791016,47.948108673096 -1.400, "Skift dit tøj", 4, 0.1, 0.1)	
	end	
	end
end

-------------------------------------------------------------------------------------------------------------------------
function Draw3DText(x,y,z,textInput,fontId,scaleX,scaleY)
         local px,py,pz=table.unpack(GetGameplayCamCoords())
         local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)    
         local scale = (1/dist)*20
         local fov = (1/GetGameplayCamFov())*100
         local scale = scale*fov   
         SetTextScale(scaleX*scale, scaleY*scale)
         SetTextFont(fontId)
         SetTextProportional(1)
         SetTextColour(250, 250, 250, 255)		-- You can change the text color here
         SetTextDropshadow(1, 1, 1, 1, 255)
         SetTextEdge(2, 0, 0, 0, 150)
         SetTextDropShadow()
         SetTextOutline()
         SetTextEntry("STRING")
         SetTextCentre(1)
         AddTextComponentString(textInput)
         SetDrawOrigin(x,y,z+2, 0)
         DrawText(0.0, 0.0)
		 ClearDrawOrigin()
        end
