AddEventHandler("playerSpawned", function(spawn)
TriggerEvent("chatMessage", "", { 255, 0, 0 }, "Velkommen til DitCommunity™")
TriggerEvent("chatMessage", "", { 255, 0, 0 }, "Dette er en Åben Beta test - Forvent bugs og andet.")
TriggerEvent("chatMessage", "", { 255, 0, 0 }, "Husk at læse vores regler på discord.")
TriggerEvent("chatMessage", "", { 255, 0, 0 }, "Alle nye spillere bedes huske at, skifte deres tøj og oprettet en identitet på rådhuset.")
TriggerEvent("chatMessage", "", { 0, 255, 0 }, "Join vores discord: Discord.gg/WmU4Srn")
TriggerEvent("chatMessage", "", { 0, 255, 0 }, "Nyd opholdet i byen.")
end)