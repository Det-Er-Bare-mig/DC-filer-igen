-- https://github.com/GroovyGiantPanda/FiveMRpServerResources/blob/master/src/FiveM/RPClient/Enums/ObjectHash.cs#L7996

-- Medical beds hashes: 1631638868(v_med_bed1), 2117668672(v_med_bed2), 3112004387(v_med_cor_emblmtable)

local bed_hashes = {2117668672, 1631638868, 3203580969, 3112004387}

local closest_bed = 0

local closest_bed_pos = nil

local is_on_bed = false

local entry_pos = nil

local onBack = true



local disabledControls = {

  357, 354, 345, 337, 323, 252, 186, 154, 120, 105, -- X

  79, 26, 253, 319, 324, -- C

  74, 101, 104, 304, -- H

  183, 47, 58, 113, -- G

  288 -- F1

}



-- Cam

local cam = nil

local fov_max = 80.0

local fov_min = 10.0 -- max zoom level (smaller fov is more zoom)

local fov = (fov_max+fov_min)*0.5



local function DrawText3Ds(x,y,z, text)

  local onScreen,_x,_y = World3dToScreen2d(x,y,z)

  local px,py,pz = table.unpack(GetGameplayCamCoords())

  local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)

  local color = {r = 255, g = 255, b = 255, alpha = 200} -- Color of the text



  local scale = (1/dist)*2

  local fov = (1/GetGameplayCamFov())*100

  local scale = scale*fov



  if onScreen and dist < 10 then

      SetTextScale(0.35, 0.35)

      SetTextFont(font)

      SetTextProportional(1)

      SetTextColour(color.r, color.g, color.b, color.alpha)

      SetTextEntry("STRING")

      SetTextDropshadow(0, 0, 0, 0, 255)

      SetTextCentre(1)

      SetTextOutline()

      SetTextEdge(2, 0, 0, 0, 150)

      SetTextDropShadow()

      AddTextComponentString(text)

      DrawText(_x,_y)

      local factor = (string.len(text)) / 240
      DrawRect(_x,_y+0.0125, 0.045+ factor, 0.03, 41, 11, 41, 68)
  

  end

end



local function DrawTextOnScreen(text)

  SetTextFont(0)

  SetTextProportional(1)

  SetTextScale(0.3, 0.3)

  SetTextColour(255, 255, 255, 255)

  SetTextDropshadow(0, 0, 0, 0, 255)

  SetTextEdge(1, 0, 0, 0, 255)

  SetTextDropShadow()

  SetTextOutline()

  SetTextCentre(true)

  SetTextEntry("STRING")

  AddTextComponentString(text)

  DrawText(0.5, 0.9)

end



local function CheckInputRotation(cam, zoomvalue)

	local rightAxisX = GetDisabledControlNormal(0, 220)

	local rightAxisY = GetDisabledControlNormal(0, 221)

	local rotation = GetCamRot(cam, 2)

	if rightAxisX ~= 0.0 or rightAxisY ~= 0.0 then

		new_z = rotation.z + rightAxisX*-1.0*(7.0)*(zoomvalue+0.1)

		new_x = math.max(math.min(90.0, rotation.x + rightAxisY*-1.0*(7.0)*(zoomvalue+0.1)), -89.5) -- Clamping at top (cant see top of heli) and at bottom (doesn't glitch out in -90deg)

    SetCamRot(cam, new_x, 0.0, new_z, 2)

	end

end



local function calculateAddToZ(obj)

  local model = GetEntityModel(obj)

  local addToZ = 0.4



  -- Special case for v_med_cor_emblmtable

  if model == -1182962909 then

    addToZ = 1.0

  elseif model == -1091386327 then

    addToZ = 0.2

  end



  return addToZ

end



local function getHumanState(state)

  local state = state or onBack



  return state and "ryggen" or "maven"

end



local function playAnim(dict, name, flags, callback)

  if dict == nil or name == nil then

      return

  end



  flags = flags or 0

  local i = 0

  while not HasAnimDictLoaded(dict) and i < 1000 do -- max time, 10 seconds

    Citizen.Wait(10)

    RequestAnimDict(dict)

    i = i+1

  end



  -- play anim

  if HasAnimDictLoaded(dict) then

    local inspeed = 8.0001

    local outspeed = -8.0001



    TaskPlayAnim(GetPlayerPed(-1),dict,name,inspeed,outspeed,-1,flags,0,0,0,0)

  end



  -- Callback

  if callback ~= nil and callback then

      callback()

  end

end



local function placePlayerOnBed(obj)

    local animation = onBack and {"amb@world_human_sunbathe@male@back@base", "base"} or {"amb@world_human_sunbathe@male@front@base", "base"}

    local pos = GetEntityCoords(obj)

    local ped = GetPlayerPed(-1)

    local addToZ = calculateAddToZ(obj)



    if onBack and GetHashKey("mp_f_freemode_01") == GetEntityModel(ped) then

      animation = {"amb@world_human_sunbathe@female@back@base", "base"}

    end



    -- Teleport player, change heading and play animation

    --AttachEntityToEntity(ped, closest_bed, -1, 0.0, 0.0, 0.94 + calculateAddToZ(obj), 0, 0, 0.0, false, false, false, false, 0, false)

    pos = GetOffsetFromEntityInWorldCoords(obj, 0.0, 0.0, 0.0 + calculateAddToZ(obj))

    SetEntityCoords(ped, pos.x, pos.y, pos.z + addToZ, 0, 0, 0, false)

    Citizen.Wait(50)

    SetEntityHeading(ped, GetEntityHeading(obj))

    Citizen.Wait(50)

    playAnim(animation[1], animation[2], 1)

end



local function leaveBed()

  local ped = PlayerPedId()

  is_on_bed = false



  -- Cancels animation and unfreezes player

  ClearPedTasks(ped)

  DetachEntity(ped, true, false)



  -- Teleport back to entry point

  SetEntityCoords(ped, entry_pos.x, entry_pos.y, closest_bed_pos.z, 0, 0, 0, false) -- We use the beds z cordinations to prevent player in abusing it to bug outside ymaps and other places



  -- Remove and detory cam

  RenderScriptCams(false, false, 0, 1, 0) -- Return to gameplay camera

  DestroyCam(cam, true)

  cam = nil

end



Citizen.CreateThread(function()

  while true do

    Citizen.Wait(1)



    if closest_bed ~= 0 then

      if is_on_bed then

        local rot = GetCamRot(cam, 2)

        DrawTextOnScreen("Tryk ~b~[Z]~s~ for at rejse dig op.\n~b~[SHIFT]~s~ For at vende dig om")



        -- Block the usage of kors, handsup, phone, laydown(C) and fall('G' ragdoll) while on bed

        for k, v in pairs(disabledControls) do

          DisableControlAction(1, v, true)

        end



        -- Wait input from user to cancel animation

        if IsControlJustPressed(0, 48) then

          leaveBed()

        elseif IsControlJustPressed(0, 21) then

          onBack = not onBack

          placePlayerOnBed(closest_bed)



        end





        local zoomvalue = (1.0/(fov_max-fov_min))*(fov-fov_min)

        CheckInputRotation(cam, zoomvalue)

      else

        DrawText3Ds(closest_bed_pos.x, closest_bed_pos.y, closest_bed_pos.z + calculateAddToZ(closest_bed), "Tryk ~b~[E]~s~ for at lægge dig på " .. getHumanState())



        -- Wait input from user to lay on bed

        if IsControlJustPressed(0, 46) then

          entry_pos = GetEntityCoords(PlayerPedId(), true)

          is_on_bed = true

          placePlayerOnBed(closest_bed)



          -- Cam

          cam = CreateCam("DEFAULT_SCRIPTED_FLY_CAMERA", true)

          AttachCamToEntity(cam, closest_bed, 0.0,0.0,calculateAddToZ(closest_bed) + 1.8, true)

          RenderScriptCams(true, false, 0, 1, 0)

        elseif IsControlJustPressed(0, 21) then

          onBack = not onBack

        end

      end

    end



  end

end)



RegisterCommand("debug", function(source, args, raw)

  TriggerEvent("chatMessage", "Model is: " .. GetEntityModel(closest_bed ))

end, false)



Citizen.CreateThread(function()

  while true do

    local ped = PlayerPedId()

    local pos = GetEntityCoords(ped, true)



    if closest_bed ~= 0 and closest_bed_pos ~= nil then

      local distance = GetDistanceBetweenCoords(pos.x, pos.y, pos.z, closest_bed_pos.x, closest_bed_pos.y, closest_bed_pos.z, false)



      -- Remove active bed if PED is more then 2 units away or inside a vehicle

      if distance >= 2.0 or IsPedInAnyVehicle(ped, true) then

        if is_on_bed then

          leaveBed()

          print("[LayOnBed] Player was moved out of the bed without leaving it, forcefully leaving bed...")

        end



        closest_bed = 0

      else

        closest_bed_pos = GetEntityCoords(closest_bed, false)

      end

    end



    -- We don't have a bed currently. Try to locate one if the player is not inside a vehicle

    if not IsPedInAnyVehicle(ped, true) and closest_bed == 0 then



      -- Look through all bed types

      for k, hash in pairs(bed_hashes) do

        obj = GetClosestObjectOfType(pos.x, pos.y, pos.z, 0.9, hash, false, false, false)



        -- Check if we found a match if we set the values and break the for loop

        if obj ~= 0 then

          closest_bed = obj

          closest_bed_pos = GetEntityCoords(obj, false)

          break

        end

      end

    end



    Citizen.Wait(800)

  end

end)