-- CLIENT SCRIPT BY TREY WOODS

Citizen.CreateThread(function() TriggerEvent('chat:addSuggestion', '/discord', 'Viser vores discord link i chatten, når du skriver /discord. | Lavet af Nixdk.') end)
RegisterCommand("discord", function(source, args, rawCommandString)
    TriggerEvent('chatMessage', "[DITCOMMUNITY]", { 255, 0, 62 }, "Discord Link: https://discord.gg/WmU4Srn")
end, false)

-- CLIENT SCRIPT BY TREY WOODS