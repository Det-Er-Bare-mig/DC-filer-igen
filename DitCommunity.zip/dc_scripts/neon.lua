local light = false
local sound = false


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
			local ped = GetPlayerPed(-1)
			if IsPedSittingInAnyVehicle(ped) then
				local veh = GetVehiclePedIsUsing(ped)
				if DoesEntityExist(veh) and (IsThisModelACar(GetEntityModel(veh)) or IsThisModelABike(GetEntityModel(veh)))  then
					if IsControlJustReleased(0, 289) then
						if (light == false) then
						  light = true
						 while (light == true) do
							SetVehicleNeonLightEnabled(veh,0,true)
							SetVehicleNeonLightEnabled(veh,1,true)
							SetVehicleNeonLightEnabled(veh,2,true)
							SetVehicleNeonLightEnabled(veh,3,true)
							Citizen.Wait(0)
						end
					end
						
				 end
			end
		end
	 end
end)
	
	
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
			local ped = GetPlayerPed(-1)
			if IsPedSittingInAnyVehicle(ped) then
				local veh = GetVehiclePedIsUsing(ped)
				if DoesEntityExist(veh) and (IsThisModelACar(GetEntityModel(veh)) or IsThisModelABike(GetEntityModel(veh)))  then
					if IsControlJustReleased(0, 289) then
						if (light == true) then
							SetVehicleNeonLightEnabled(veh,0,false)
							SetVehicleNeonLightEnabled(veh,1,false)
							SetVehicleNeonLightEnabled(veh,2,false)
							SetVehicleNeonLightEnabled(veh,3,false)
							light = false
						end
				end
			end
		end
	 end
	end)