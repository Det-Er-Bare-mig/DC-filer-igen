Config = {}
Config.Locale = 'en'

Config.progressBars = true          --  If your server has progressBars and wants to use vs text for mugging time.
Config.MinMoney = 650                 --  Min amount of money received from mugging
Config.MaxMoney = 7500               --  Max amount of money received from mugging.
Config.RobWaitTime = 8              --  Current seconds it takes to finish mugging
Config.AddItemsPerctent = 40        --  This is percent the script will add items as well as cash from mugging set to 0 to turn off.
Config.AddItemsMax = 20             --  This is the max number of items you can receive from NPC from mugging - min is 1
Config.CoolDownTime = 40            --  This is time between mugging NPC in seconds. Setting to 0 will turn off cooldown.
Config.RequiredPermission = "police.service"
Config.Language = {
    RequiredPermission = "Observeret røveri",
    CallAlreadyTaken = "Dette opkald er allerede taget af en anden."
}

Config.MustUseVoice = false          --  With this on, the player must be speaking in game when trying to much someone or the npc will ignore.  


Config.giveableItems = {
      'hash',
      'Kokain'
  }

