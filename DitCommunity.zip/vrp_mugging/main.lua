local lastrobbed, cooldowntime = 0,0,0
local robbing, currentrobbing, notneeded, checkforvoice, IsMuggingAllowed  = false, false, false, false, true
local playerPed, pCoords, tCoords = nil, nil, nil

function voicecheck()
   
end


function CoolDown()
    cooldowntime = Config.CoolDownTime
    while not IsMuggingAllowed do
        Wait(1000)
        cooldowntime = cooldowntime - 1
        if cooldowntime == 0 then
            IsMuggingAllowed = true
        end
    end
end

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())

    SetTextScale(0.38, 0.38)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    --DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 0, 0, 0, 80)
end

Citizen.CreateThread(function()
    while true do
    Citizen.Wait(0)
    if not robbing and not IsPedInAnyVehicle(GetPlayerPed(-1),true) then
        if IsPlayerFreeAiming(PlayerId()) then
            local aiming, targetPed = GetEntityPlayerIsFreeAimingAt(PlayerId())
            if IsPedArmed(GetPlayerPed(-1), 7) and IsPedArmed(GetPlayerPed(-1), 4) and not IsPedFleeing(targetPed) and not IsPedAPlayer(targetPed) and IsPedHuman(targetPed) and not IsEntityAMissionEntity(targetPed) then
                    if aiming then
                    playerPed = GetPlayerPed(-1)
                    pCoords = GetEntityCoords(playerPed, true)
                    tCoords = GetEntityCoords(targetPed, true)
                        if DoesEntityExist(targetPed) and IsEntityAPed(targetPed) and not IsPedDeadOrDying(targetPed) then
                            if GetDistanceBetweenCoords(pCoords.x, pCoords.y, pCoords.z, tCoords.x, tCoords.y, tCoords.z, true) <= 5.0 then
                                if IsPedInAnyVehicle(targetPed, true) then
                                    local localvehicle = GetVehiclePedIsIn(targetPed, false)
                                    if IsVehicleStopped(localvehicle) and not robbing and IsMuggingAllowed then
                                        TaskLeaveVehicle(targetPed, localvehicle, 1)
                                        ResetPedLastVehicle(targetPed)
                                        ClearPedTasks(targetPed)
                                        if targetPed == lasttargetPed then
                                            AddShockingEventAtPosition(99, GetEntityCoords(targetPed),0.5)  
                                        elseif not robbing and IsMuggingAllowed then
                                            robNpc(targetPed)
                                        end
                                    end
                                else 
                                    if targetPed == lasttargetPed then
                                        AddShockingEventAtPosition(99, GetEntityCoords(targetPed),0.5)  
                                    elseif not robbing and IsMuggingAllowed then
                                        robNpc(targetPed)
                                    end
                                end
                            end
                        end    
                    end
                end
            end
        end  
    end
end)

function robNpc(targetPed)
    Citizen.CreateThread(function()
        Citizen.Wait(0)
        local roblocalcoords, x, y, z = GetEntityCoords(targetPed)
        if not currentrobbing then 
            if Config.MustUseVoice then
				DrawText3Ds(roblocalcoords.x, roblocalcoords.y, roblocalcoords.z, "Mug...")
            else
				DrawText3Ds(roblocalcoords.x, roblocalcoords.y, roblocalcoords.z, "[E] » Stjæl")
            end
        elseif lasttargetPed == targetPed then
			DrawText3Ds(roblocalcoords.x, roblocalcoords.y, roblocalcoords.z, "Allerede røvet..")
        else
            if not Config.progressBars then
			DrawText3Ds(roblocalcoords.x, roblocalcoords.y, roblocalcoords.z, "Stjæler")
            end
        end
        
        
        TaskHandsUp(targetPed, 5500, 0, 0, true)
        if Config.MustUseVoice and NetworkIsPlayerTalking(PlayerId()) then notneeded = true end
        if not Config.MustUseVoice and IsControlJustReleased(0,38) then notneeded = true end
        if notneeded then
            notneeded = false
            local plyPos = GetEntityCoords(GetPlayerPed(-1),  true)
            local s1, s2 = Citizen.InvokeNative( 0x2EB41072B4C1E4C0, plyPos.x, plyPos.y, plyPos.z, Citizen.PointerValueInt(), Citizen.PointerValueInt() )
            local street1 = GetStreetNameFromHashKey(s1)
            local street2 = GetStreetNameFromHashKey(s2)
            local reportcoords = {
                x = plyPos.x,
                y = plyPos.y,
                z = plyPos.z - 1,
            }
            if not currentrobbing then
                PlayAmbientSpeech1(targetPed, "GUN_BEG", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR")
                currentrobbing = true
                TaskHandsUp(targetPed, Config.RobWaitTime * 1000, 0, 0, true)
                if Config.progressBars then
                    exports['progressBars']:startUI(Config.RobWaitTime * 1000, "Sjæler ting...")
                end 
                Citizen.Wait(Config.RobWaitTime * 1000)
                playerPed = GetPlayerPed(-1)
                pCoords = GetEntityCoords(playerPed, true)
                tCoords = GetEntityCoords(targetPed, true)
                if GetDistanceBetweenCoords(pCoords.x, pCoords.y, pCoords.z, tCoords.x, tCoords.y, tCoords.z, true) <= 5.0 then 
                    if not IsPedDeadOrDying(targetPed) then
                        AddShockingEventAtPosition(99, GetEntityCoords(targetPed),0.5)
                        TriggerServerEvent("vrp_mugging:call", roblocalcoords["x"], roblocalcoords["y"]) -- Trigger a server event with parameters
                        TriggerServerEvent("vrp_mugging:giveMoney")
                        additems = math.random(1,100)
                            if additems <= Config.AddItemsPerctent then
                                    randomitemcount = math.random(1,Config.AddItemsMax)
                                for i = randomitemcount,1,-1
                                do
                                    local randomitempull = math.random(1, #Config.giveableItems)
                                    local itemName = Config.giveableItems[randomitempull]
                                    TriggerServerEvent('vrp_mugging:giveItems', (itemName))
                                end
                            end
                        randomact = math.random(1,10)
                        if randomact > 6 then
                            PlayAmbientSpeech1(targetPed, "GENERIC_INSULT_HIGH", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR")
                        elseif randomact > 3 then
                            PlayAmbientSpeech1(targetPed, "GENERIC_FRIGHTENED_HIGH", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR")
                        end
                        robbing = true
                        lastrobbed = math.random(1, 100)
                        lasttargetPed = targetPed
                        robbing = false
                        currentrobbing = false
                        if Config.CoolDownTime ~= 0 then
                            IsMuggingAllowed = false
                            CoolDown()
                        end
                    else
                        
                        if Config.CoolDownTime ~= 0 then
                            IsMuggingAllowed = false
                            CoolDown()
                        end
                        robbing = false
                        currentrobbing = false
                    end
                else
                    if Config.CoolDownTime ~= 0 then
                        IsMuggingAllowed = false
                        CoolDown()
                    end
           --         exports['mythic_notify']:DoCustomHudText('error', 'For langt væk fra NPC', 5000)
                    TriggerClientEvent("pNotify:SendNotification", source,{text = "For langt væk fra NPC", type = "success", queue = "global", timeout = 4000, layout = "bottomCenter",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
                    lastrobbed = math.random(1, 100)
                    robbing = false
                    currentrobbing = false
                end
            end
        end
    end)
end


