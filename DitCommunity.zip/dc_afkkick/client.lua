local previous_coords = nil

local afkWarnAt = 150

local warningInterval = 30

local maxAfk = 15 * 60 -- 15 minutes





local timeleft = maxAfk

local hasUserCancelledKickBefore = false

local debug = {}



local randomAfkCancelMessages = {

	"Du lever stadig 👍",

	"Super der er stadig liv i dag 💓",

	"Det var du længe om troede skam du var død. ☠️",

	"Nå du er ikke død? ☠️",

	"Pas på du ikke får krampe næste gang du står stille så længe... 🙋",

	"Der var du sgu 😉",

	"Back on track 🏃",

	"Undskyld, forstyrrer AFK beskeden ❓",

	"Pas på du ikke falder i søvn 😴",

	"Ja god morgen 🌅",

	"Sovet godt ❓",

	"Hej igen 🙋‍",

	"Halløjsovs 🙋",

	"Halløj 🙋",

	"Så er der gang i den igen 🏃",

	"Sådan 👍",

	"Davs du 🙋",

	"Se der er liv 💓",

	"Tid til at tag en køretur ❓🚗",

	"Burde man tag en cykeltur ❓🚴",

	"Troede sgu du var groet fast 🌵",

	"Tid til et smut forbi burgershot ❓🍔",

	"🚶 🐕 🏞️",

	"Tid til at spille fodbold ❓⚽",

	"Øv du fik ikke slået <span style='color: IndianRed'>Nixdk's</span> rekord denne gang",

	"Der skal længere til for at slå <span style='color: IndianRed'>Nixdk's</span> afk rekord"

}

local function notify(message, timeout, notify_type, format, shouldKill)

	local text = (format or "<center><b>%s</b></center>"):format(message)



	if type(shouldKill) ~= "boolean" then

		shouldKill = true

	end



	TriggerEvent("pNotify:SendNotification", {

		text = text,

		type = notify_type or "error",

		timeout = timeout or 4000,

		layout = "bottomCenter",

		queue = "dc_afk",

		killer = shouldKill and "dc_afk" or false,

	})

end



local function getRandomCancelMessage()

	local rng = math.random(1, #randomAfkCancelMessages)



	return randomAfkCancelMessages[rng]

end



function debug.isEnabled()

	return GetConvarInt("dc_afk.debug", 0) == 1

end



function debug.message(message)

	if debug.isEnabled() then

		print("[dc_AFK DEBUG] " .. message)

	end

end



Citizen.CreateThread(function()

	Citizen.Wait(0)

	while true do

		local ped = PlayerPedId()

		local coords = GetEntityCoords(ped)



		local dist = GetDistanceBetweenCoords(coords, previous_coords, false)



		if dist < 0.75 then

			timeleft = timeleft - 1

			debug.message("Timer: " .. timeleft/60 .. "("..timeleft.."s) dist: " .. dist)



			if timeleft <= 0 then

				TriggerServerEvent("dc_afk:kickme")

				timeleft = maxAfk

			elseif timeleft <= afkWarnAt and (timeleft % warningInterval) == 0 then

				local commandhelp = hasUserCancelledKickBefore and " " or " eller Skriv <code style='background: rgba(255,99,71, 0.4)'>/afk</code><br/>"

				local timeout = warningInterval * 400

				notify("Du bliver kicked om <span style='color: Tomato'>" .. timeleft .. "</span> sekunder for at være AFK!<br/>", timeout)

				notify("<i>Bevæg dig" .. commandhelp .. "for at annullere AFK-kick</i>", timeout, nil, nil, false)

			end



		else

			if timeleft <= afkWarnAt then

				local message = getRandomCancelMessage()

				notify(message .. "<br/><br/><b>AFK timer er blevet resat</b>", nil, "success", "<center>%s</center>")

			end



			timeleft = maxAfk

			hasUserCancelledKickBefore = false

			debug.message("Timer reset. Dist: " .. dist)

		end



		previous_coords = coords

		Citizen.Wait(1000)

	end

end)



RegisterCommand("afk", function()

	if timeleft <= afkWarnAt then

		if hasUserCancelledKickBefore then

			notify("⚠️ Du har allerede annulleret 1 AFK-kick uden at bevæge dig. Bevæg dig for at annullere AFK kick.")

			return

		end



		hasUserCancelledKickBefore = true

		timeleft = maxAfk

		notify("✅ AFK-kick annulleret", nil, "success")

		return

	end



	notify("❓ Du er ikke ved at blive AFK kicked")

end)

