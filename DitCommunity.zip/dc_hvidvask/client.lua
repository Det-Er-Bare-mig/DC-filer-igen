-------------------------------------------------------------------------------------------------
--                                          HVIDVASKNING                                       --
-------------------------------------------------------------------------------------------------
local hvidvask1 = {
    {1120.1588134766,-3195.7839355468,-40.40087890625, hTimer = 0, item = "dirty_money"},
}

local hvidvask2 = {
    {211.57493591309,-934.88977050781,24.275949478149,237.76953125, hTimer = 0, item = "dirty_money"}
}

local hvidvask3 = {
    {29.901927947998,3665.4541015625,40.440582275391, hTimer = 0, item = "dirty_money"}
}

local hvidvask4 = {
    {-191.72076416016,6145.3916015625,36.863021850586, hTimer = 0, item = "dirty_money"}
}

local hvidvask5 = {
    {-156.06336975098,6199.03515625,31.320308685303, hTimer = 0, item = "dirty_money"}
}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k,v in pairs(config.lokation1) do
            if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
                DrawMarker(27, v.Pos.x, v.Pos.y, v.Pos.z-0.8, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 5.0 then
                    DrawText3d(v.Pos.x, v.Pos.y, v.Pos.z, "~b~HVIDVASK ~n~ ~s~[E] ~s~FOR AT HVIDVASKE ~b~10.000 ~s~"..config.skejs.valuta.."")
                    if (IsControlJustReleased(1, 51)) then
                        FreezeEntityPosition((GetPlayerPed(-1)),true)
                        TaskStartScenarioInPlace(PlayerPedId(), config.scenario, 0, true)
                        exports['progressBars']:startUI(10000, "Hvidvasker pengene...")
                        Citizen.Wait(1000)
                        spawnHvidvask1(k)
                        Citizen.Wait(9000)
                        v.hTimer = math.random(0,0)
                        sletHvidvask1(k)
                        FreezeEntityPosition((GetPlayerPed(-1)),false)
                        ClearPedTasksImmediately(GetPlayerPed(-1))
                        TriggerServerEvent('HvidvaskPenge1',hvidvask1[k].item)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k,v in pairs(config.lokation2) do
            if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
                DrawMarker(27, v.Pos.x, v.Pos.y, v.Pos.z-0.8, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 5.0 then
                    DrawText3d(v.Pos.x, v.Pos.y, v.Pos.z, "~b~HVIDVASK ~n~ ~s~[E] ~s~FOR AT HVIDVASKE ~b~20.000 ~s~"..config.skejs.valuta.."")
                    if (IsControlJustReleased(1, 51)) then
                        FreezeEntityPosition((GetPlayerPed(-1)),true)
                        TaskStartScenarioInPlace(PlayerPedId(), config.scenario, 0, true)
                        exports['progressBars']:startUI(10000, "Hvidvasker pengene...")
                        Citizen.Wait(1000)
                        spawnHvidvask2(k)
                        Citizen.Wait(9000)
                        v.hTimer = math.random(0,0)
                        sletHvidvask2(k)
                        FreezeEntityPosition((GetPlayerPed(-1)),false)
                        ClearPedTasksImmediately(GetPlayerPed(-1))
                        TriggerServerEvent('HvidvaskPenge2',hvidvask2[k].item)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k,v in pairs(config.lokation3) do
            if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
                DrawMarker(27, v.Pos.x, v.Pos.y, v.Pos.z-0.8, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 5.0 then
                    DrawText3d(v.Pos.x, v.Pos.y, v.Pos.z, "~b~HVIDVASK ~n~ ~s~[E] ~s~FOR AT HVIDVASKE ~b~30.000 ~s~"..config.skejs.valuta.."")
                    if (IsControlJustReleased(1, 51)) then
                        FreezeEntityPosition((GetPlayerPed(-1)),true)
                        TaskStartScenarioInPlace(PlayerPedId(), config.scenario, 0, true)
                        exports['progressBars']:startUI(10000, "Hvidvasker pengene...")
                        Citizen.Wait(1000)
                        spawnHvidvask3(k)
                        Citizen.Wait(9000)
                        v.hTimer = math.random(0,0)
                        sletHvidvask3(k)
                        FreezeEntityPosition((GetPlayerPed(-1)),false)
                        ClearPedTasksImmediately(GetPlayerPed(-1))
                        TriggerServerEvent('HvidvaskPenge3',hvidvask3[k].item)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k,v in pairs(config.lokation4) do
            if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
                DrawMarker(27, v.Pos.x, v.Pos.y, v.Pos.z-0.8, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 5.0 then
                    DrawText3d(v.Pos.x, v.Pos.y, v.Pos.z, "~b~HVIDVASK ~n~ ~s~[E] ~s~FOR AT HVIDVASKE ~b~50.000 ~s~"..config.skejs.valuta.."")
                    if (IsControlJustReleased(1, 51)) then
                        FreezeEntityPosition((GetPlayerPed(-1)),true)
                        TaskStartScenarioInPlace(PlayerPedId(), config.scenario, 0, true)
                        exports['progressBars']:startUI(10000, "Hvidvasker pengene...")
                        Citizen.Wait(1000)
                        spawnHvidvask4(k)
                        Citizen.Wait(9000)
                        v.hTimer = math.random(0,0)
                        sletHvidvask4(k)
                        FreezeEntityPosition((GetPlayerPed(-1)),false)
                        ClearPedTasksImmediately(GetPlayerPed(-1))
                        TriggerServerEvent('HvidvaskPenge4',hvidvask4[k].item)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k,v in pairs(config.lokation5) do
            if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
                DrawMarker(27, v.Pos.x, v.Pos.y, v.Pos.z-0.8, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 0, 155, 255, 200, 0, 1, 0, 50)
                if GetDistanceBetweenCoords(v.Pos.x, v.Pos.y, v.Pos.z, GetEntityCoords(GetPlayerPed(-1))) < 5.0 then
                    DrawText3d(v.Pos.x, v.Pos.y, v.Pos.z, "~b~HVIDVASK ~n~ ~s~[E] ~s~FOR AT HVIDVASKE ~b~100.000 ~s~"..config.skejs.valuta.."")
                    if (IsControlJustReleased(1, 51)) then
                        FreezeEntityPosition((GetPlayerPed(-1)),true)
                        TaskStartScenarioInPlace(PlayerPedId(), config.scenario, 0, true)
                        exports['progressBars']:startUI(10000, "Hvidvasker pengene...")
                        Citizen.Wait(1000)
                        spawnHvidvask5(k)
                        Citizen.Wait(9000)
                        v.hTimer = math.random(0,0)
                        sletHvidvask5(k)
                        FreezeEntityPosition((GetPlayerPed(-1)),false)
                        ClearPedTasksImmediately(GetPlayerPed(-1))
                        TriggerServerEvent('HvidvaskPenge5',hvidvask5[k].item)
                    end
                end
            end
        end
    end
end)

-------------------------------------------------------------------------------------------------
--                                          FUNKTIONER                                         --
-------------------------------------------------------------------------------------------------

function DrawText3d(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
	local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 20,20,20,0)
end

function spawnHvidvask1(k)
    local hPoint = hvidvask1[k]
    hvidvask1[k].object = CreateObject(GetHashKey(config.prop), hPoint[1], hPoint[2], hPoint[3]-1, true, true, true)
    PlaceObjectOnGroundProperly(hPoint.object)
    FreezeEntityPosition(hPoint.object, true)
end

function spawnHvidvask2(k)
    local hPoint = hvidvask2[k]
    hvidvask2[k].object = CreateObject(GetHashKey(config.prop), hPoint[1], hPoint[2], hPoint[3]-1, true, true, true)
    PlaceObjectOnGroundProperly(hPoint.object)
    FreezeEntityPosition(hPoint.object, true)
end

function spawnHvidvask3(k)
    local hPoint = hvidvask3[k]
    hvidvask3[k].object = CreateObject(GetHashKey(config.prop), hPoint[1], hPoint[2], hPoint[3]-1, true, true, true)
    PlaceObjectOnGroundProperly(hPoint.object)
    FreezeEntityPosition(hPoint.object, true)
end

function spawnHvidvask4(k)
    local hPoint = hvidvask4[k]
    hvidvask4[k].object = CreateObject(GetHashKey(config.prop), hPoint[1], hPoint[2], hPoint[3]-1, true, true, true)
    PlaceObjectOnGroundProperly(hPoint.object)
    FreezeEntityPosition(hPoint.object, true)
end

function spawnHvidvask5(k)
    local hPoint = hvidvask5[k]
    hvidvask5[k].object = CreateObject(GetHashKey(config.prop), hPoint[1], hPoint[2], hPoint[3]-1, true, true, true)
    PlaceObjectOnGroundProperly(hPoint.object)
    FreezeEntityPosition(hPoint.object, true)
end

function sletHvidvask1(k)
    local hObject = hvidvask1[k].object
    if DoesEntityExist(hObject) then
        SetEntityAsMissionEntity(hObject, true, true)
        DeleteObject(hObject)
        SetEntityAsNoLongerNeeded(hObject)
    end
end

function sletHvidvask2(k)
    local hObject = hvidvask2[k].object
    if DoesEntityExist(hObject) then
        SetEntityAsMissionEntity(hObject, true, true)
        DeleteObject(hObject)
        SetEntityAsNoLongerNeeded(hObject)
    end
end

function sletHvidvask3(k)
    local hObject = hvidvask3[k].object
    if DoesEntityExist(hObject) then
        SetEntityAsMissionEntity(hObject, true, true)
        DeleteObject(hObject)
        SetEntityAsNoLongerNeeded(hObject)
    end
end

function sletHvidvask4(k)
    local hObject = hvidvask4[k].object
    if DoesEntityExist(hObject) then
        SetEntityAsMissionEntity(hObject, true, true)
        DeleteObject(hObject)
        SetEntityAsNoLongerNeeded(hObject)
    end
end

function sletHvidvask5(k)
    local hObject = hvidvask5[k].object
    if DoesEntityExist(hObject) then
        SetEntityAsMissionEntity(hObject, true, true)
        DeleteObject(hObject)
        SetEntityAsNoLongerNeeded(hObject)
    end
end