config = {}

config = {
    scenario = "CODE_HUMAN_MEDIC_TEND_TO_DEAD", -- Animationen man laver når man placere pengene på jorden
    prop = "prop_cash_case_02",



    lokation1 = {
        [1] = {
            Pos = {x=1120.1588134766, y=-3195.7839355468, z=-40.40087890625},
            Penge = 10000,
            item = "dirty_money",
            hTimer = 0,
        },
    },
    lokation2 = {
        [1] = {
            Pos = {x=211.57493591309,y=-934.88977050781,z=24.275949478149,237.76953125},
            Penge = 20000,
            item = "dirty_money",
            hTimer = 0,
        },
    },
    lokation3 = {
        [1] = {
            Pos = {x=-1911.1805419922, y=-573.76483154297, z=19.097211837769},
            Penge = 30000,
            item = "dirty_money",
            hTimer = 0,
        },
    },
    lokation4 = {
        [1] = {
            Pos = {x=29.901927947998,y=3665.4541015625,z=40.440582275391},
            Penge = 50000,
            item = "dirty_money",
            hTimer = 0,
        },
    },
    lokation5 = {
        [1] = {
            Pos = {x=-191.72076416016,y=6145.3916015625,z=36.863021850586},
            Penge = 100000,
            item = "dirty_money",
            hTimer = 0,
        },
    },



    skejs = {
        procent = 90, -- Hvor mange procent skal man få, af de sorte penge man hvidvasker? Eksempel: Man hvidvasker 5000 sorte penge og modtager 4000 normale penge
        valuta = "DKK", -- Basically bare hvad der står i 3D teksten af valuta. Eksempel: Tryk [E] for at hvidvaske 1000 DKK
    },
}