

local props = {}

local drawables = {}

local defaultDrawable = {["default"] = {[3] = 15, [4] = 21, [6] = 34, [11] = 15}, [GetHashKey("mp_f_freemode_01")] = {[4] = 19, [6] = 35, [11] = 18}}



local dataTable = {

    ["props"] = {

        [0] = {

            ["på"] = {"veh@bicycle@roadfront@base", "put_on_helmet"},

            ["af"] = {"missheist_agency2ahelmet", "take_off_helmet_stand"},

            ["message"] = "Din hat blev taget %s"

        },

        [1] = {

            ["på"] = {"clothingspecs", "put_on"},

            ["af"] = {"clothingspecs", "take_off"},

            ["message"] = "Dine briller blev taget %s"

        },

        [2] = {

            ["på"] = {"mini@ears_defenders", "takeoff_earsdefenders_idle"},

            ["af"] = {"mini@ears_defenders", "takeoff_earsdefenders_idle"},

            ["message"] = "Dine øreringe/headsets blev taget %s"

        }

    },

    ["drawables"] = {

        [1] = {

            ["på"] = {"veh@bicycle@roadfront@base", "put_on_helmet"},

            ["af"] = {"missheist_agency2ahelmet", "take_off_helmet_stand"},

            ["message"] = "Din maske blev taget %s"

        },

        [4] = {

            ["på"] = {"clothingshoes", "try_shoes_positive_d"},

            ["af"] = {"clothingshoes", "try_shoes_positive_d"},

            ["message"] = "Dine bukser blev taget %s"

        },

        [6] = {

            ["på"] = {"clothingshoes", "try_shoes_positive_d"},

            ["af"] = {"clothingshoes", "try_shoes_positive_d"},

            ["message"] = "Dine sko er blevet taget %s"

        },

        [7] = {

            ["på"] = {"clothingtie", "try_tie_neutral_b"},

            ["af"] = {"clothingtie", "try_tie_neutral_b"},

            ["message"] = "Dit slips/halskæde blev taget "

        },

        [8] = {

            ["på"] = {"clothingtie", "try_tie_positive_a"},

            ["af"] = {"clothingtie", "try_tie_positive_a"},

            ["message"] = "Din undertrøje blev taget %s"

        },

        [9] = {

            ["på"] = {"clothingtie", "try_tie_positive_a"},

            ["af"] = {"clothingtie", "try_tie_positive_a"},

            ["message"] = "Din veste blev taget %s"

        },

        [11] = {

            ["på"] = {"clothingtie", "try_tie_positive_a"},

            ["af"] = {"clothingtie", "try_tie_positive_a"},

            ["message"] = "Din trøje blev taget %s"

        }

    }

}



-- ["command name"] = {type, component, forceState} Tpes: prop or drawable

local commands = {

    -- Props

    ["hat"]         = {"prop", 0},

    ["briller"]     = {"prop", 1},

    ["øre"]         = {"prop", 2},

    ["vhånd"]       = {"prop", 6},

    ["hhånd"]       = {"prop", 7},



    -- Drawables

    ["maske"]        = {"drawable", 1},





    ["bukser"]      = {"drawable", 4},

    ["sko"]         = {"drawable", 6},

    ["hals"]        = {"drawable", 7},

    ["undertrøje"]  = {"drawable", 8},

    ["vest"]        = {"drawable", 9},

    ["trøje"]       = {"drawable", 11},

}



-- Register commands

for cmdName, options in pairs(commands) do

    RegisterCommand(cmdName, function(source, args, raw)

        if options[1] == "prop" then

            toggleProp(options[2], options[3])

        else

            toggleDrawable(options[2], options[3])

        end

    end)

end





-- playAnim on upperbody only

function playAnim(dict, name, flags, callback)



    -- Don't play animations if dict or name is provided

    -- And don't animations if the player is in hand cuffs

    if dict == nil or name == nil then

        return

    end



    flags = flags or 0

    local i = 0

    while not HasAnimDictLoaded(dict) and i < 1000 do -- max time, 10 seconds

      Citizen.Wait(10)

      RequestAnimDict(dict)

      i = i+1

    end



    -- play anim

    if HasAnimDictLoaded(dict) then

      local inspeed = 8.0001

      local outspeed = -8.0001



      TaskPlayAnim(PlayerPedId(),dict,name,inspeed,outspeed,-1,flags,0,0,0,0)

    end



    Citizen.Wait(100)

    while IsEntityPlayingAnim(PlayerPedId(), dict, name, 3) do



      -- Don't allow the animation to be cancled via hotkey

      DisableControlAction(1, 20, true)

      DisableControlAction(1, 48, true)

      Citizen.Wait(1)

    end



    -- Callback

    if callback ~= nil and callback then

        callback()

    end

end





-- True      When the drawable gets added back

-- False     When the drawable gets removed and gets saved

function toggleDrawable(component, forceState)

    local ped = PlayerPedId()

    local drawable = drawables[component]

    local default = getDefaultDrawable(component)

    local currentVariation = GetPedDrawableVariation(ped, component)

    local currentTexture = GetPedTextureVariation(ped, component)

    local currentPalette = GetPedPaletteVariation(ped, component)



    local data = dataTable["drawables"][component] or {["på"] = {}, ["af"] = {}}

    local setToState = currentVariation == default



    -- Special case for undershirt

    if component == 8 then

        setToState = setToState and currentTexture == 240

    end



    -- Check if a foced state is set and use it instead

    if forceState ~= nil and forceState ~= -1 then

        setToState = forceState

    end



    -- Result to be returned

    local result = false



    if setToState then

        if drawable ~= nil then

            -- Play animation if available

            local dict, name = table.unpack(data["på"])

            playAnim(dict, name, 48)



            -- Add the prop back

            -- and return true because we added the prop back

            SetPedComponentVariation(ped, component, drawable["variation"], drawable["texture"], drawable["palette"])

            result = true

        else



            -- We don't have a saved model. Return false default model

            return false

        end

    else

        -- Play animation if available

        local dict, name = table.unpack(data["af"])

        playAnim(dict, name, 48)



        -- Default texture ID

        local defaultTexture = 0



        -- Special case for undershirt

        if component == 8 then

            defaultTexture = 240

        end



        -- Remove the prop and Save it so we can add it back again

        SetPedComponentVariation(ped, component, default, defaultTexture, 0)

        drawables[component] = {["variation"] = currentVariation, ["texture"] = currentTexture, ["palette"] = currentPalette}



        -- Return false as we removed the prop and saved it.

        result = false

    end



    -- Special case for upper body so arms can be added on and off too

    if component == 11 then

        toggleDrawable(3, setToState) -- We force the same state as the shirt to ensure both add backs or removes

    end



    -- Send pNotify message

    sendPNotifyMessage(data, setToState)





    -- And now we return the result

    return result

end





-- True      When the prop is added

-- False     When no props is currently applied

function toggleProp(component, forceState)

    local ped = PlayerPedId()

    local prop = props[component]

    local currentProp = GetPedPropIndex(ped, component)

    local currentTexture = GetPedPropTextureIndex(ped, component)



    local data = dataTable["props"][component] or {["på"] = {}, ["af"] = {}}

    local setToState = currentProp == -1



    -- Check if a foced state is set and use it instead

    if forceState ~= nil then

        setToState = forceState

    end



    -- Result to be returned

    local result = false



    if setToState then



        if prop ~= nil then

            -- Play animation if available

            local dict, name = table.unpack(data["på"])

            playAnim(dict, name, 48)



            -- Add the prop back

            -- and return true because we added the prop back

            SetPedPropIndex(ped, component, prop["prop"], prop["texture"], false)

            result = true

        else



            -- We don't have a saved prop. Return false default prop

            return false

        end

    else

        -- Play animation if available

        local dict, name = table.unpack(data["af"])

        playAnim(dict, name, 48)



        -- Remove the prop and Save it so we can add it back again

        ClearPedProp(ped, component)

        props[component] = {["prop"] = currentProp, ["texture"] = currentTexture}



        -- Return false as we removed the prop and saved it.

        result = false

    end



    -- Send pNotify message

    sendPNotifyMessage(data, setToState)





    -- And now we return the result

    return result

end



function sendPNotifyMessage(data, state)

    -- pNotify message

    local message = data["message"]

    local humanFriendlyState = (state == true) and "på" or "af"



    if message ~= nil then

        TriggerEvent("pNotify:SendNotification", {

            text = '<center><b style="font-family:Segoe UI;"> ' .. string.format(message, humanFriendlyState) .. ' </b></center>',

            type = "success",

            timeout = 4000,

            layout = "bottomCenter"

        })

    end

end



-- Returns default drawable

function getDefaultDrawable(component)

    local ped = PlayerPedId()

    local model = GetEntityModel(ped)



    -- Check if PED is a female if true then try to return defaults for the female model first

    if (GetHashKey("mp_f_freemode_01") == model) and defaultDrawable[model] then -- Check if female

        local result = defaultDrawable[model][component] or 0



        if result ~= nil and result ~= 0 then return result end

    end



    return defaultDrawable["default"][component] or 0

end

