local offonduty = {}
RegisterNetEvent('vrp_offduty:offonduty')
AddEventHandler('vrp_offduty:offonduty', function(list)
    offonduty = list
end)

local isOnDuty = false
local dutyjobs = {
    "Brødrenes Autoværksted",
    "Bennys Auto",
    "Rigspolitichef",
    "Vicerigspolitichef",
    "Politiinspektør",
    "Vicepolitiinspektør",
    "Politikommissær",
    "AKS",
    "Civilbetjent",
    "Politiassistent",
    "Politibetjent",
    "Politielev",
    "Regionschef",
    "Viceregionschef",
    "Overlæge",
    "Akutlæge",
    "Ambulanceredder",
    "Redderelev",
}

local job = "Ingen"
RegisterNetEvent('vrp_offduty:updateJob')
AddEventHandler('vrp_offduty:updateJob', function(jobs)
    job = jobs
    for k,v in pairs(dutyjobs) do
        if v == jobs then
            isOnDuty = true
            break
        end
    end
end)

function DrawText3D(x,y,z, text)
    local onScreen,_x,_y = World3dToScreen2d(x,y,z)

    text = string.gsub(text, "^.", string.upper)

    if onScreen then
        SetTextScale(0.32, 0.32)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
        local factor = (string.len(text)) / 450
        DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
    end
end

local delay = 0
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
        if delay ~= 0 then delay = delay-1 end
        local ped = GetPlayerPed(-1)
        if GetEntityHealth(ped) > 100 then
            for _, duty in pairs(offonduty) do
                if GetDistanceBetweenCoords(GetEntityCoords(ped), duty.coords[1], duty.coords[2], duty.coords[3], true ) < 20 then
                    DrawMarker(27, duty.coords[1], duty.coords[2], duty.coords[3], 0, 0, 0, 0, 0, 0, 1.0, 1.0, 0.5001, 0, 155, 255, 200, 0, 0, 0, 50)
                    if GetDistanceBetweenCoords(GetEntityCoords(ped), duty.coords[1], duty.coords[2], duty.coords[3], true ) < 1.25 then
                        if IsControlJustReleased(1, 86) then
                         TriggerEvent("dc-animation:startWithItem", "notesblok")
                         TriggerEvent('3dme:remoteDisplay', "Går af/på job", player)
                         Citizen.Wait(2500)
                         TriggerEvent("dc-animation:stopAnim", "notesblok")
                            if delay == 0 then
                                TriggerServerEvent("vrp_offduty:duty",_)
                                delay = tonumber(500)
                            else
                                TriggerEvent("pNotify:SendNotification",{
                                    text = "Du skal vente lidt med at skifte job!",
                                    type = "error",
                                    timeout = 3000,
                                    layout = "bottomCenter",
                                    queue = "global",
                                    animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
                                })
                            end
                        end
                        if isOnDuty then
                            DrawText3D(duty.coords[1], duty.coords[2], duty.coords[3]+1, "Tryk ~b~[E]~w~ For at gå af/på job")
                        else
                            DrawText3D(duty.coords[1], duty.coords[2], duty.coords[3]+1, "Tryk ~b~[E]~w~ For at gå af/på job")
                        end
                    end
                end
            end
        end
    end
end)

