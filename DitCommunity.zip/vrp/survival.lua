-- api



function tvRP.varyHealth(variation)

  local ped = PlayerPedId()



  local n = math.floor(GetEntityHealth(ped)+variation)

  SetEntityHealth(ped,n)

end



function tvRP.getHealth()

  return GetEntityHealth(PlayerPedId())

end



function tvRP.setHealth(health)

  local n = math.floor(health)

  SetEntityHealth(PlayerPedId(),n)

end



function tvRP.restoreStamina(stamina)

  local n = math.floor(stamina)

  RestorePlayerStamina(PlayerId(),n+0.0001)

end



function tvRP.setFriendlyFire(flag)

  NetworkSetFriendlyFireOption(flag)

  SetCanAttackFriendly(PlayerPedId(), flag, flag)

end



function tvRP.setPolice(flag)

  local player = PlayerId()

  SetPoliceIgnorePlayer(player, not flag)

  SetDispatchCopsForPlayer(player, flag)

end



function DecimalsToMinutes(dec)

    local ms = tonumber(dec)

    return math.floor(ms / 60).."~w~ minutter og~r~ "..(ms % 60).."~w~ sekunder"

end



-- impact thirst and hunger when the player is running (every 5 seconds)

Citizen.CreateThread(function()

  while true do

    Citizen.Wait(5000)



    if IsPlayerPlaying(PlayerId()) then

      local ped = PlayerPedId()



      -- variations for one minute

      local vthirst = 0

      local vhunger = 0



      -- on foot, increase thirst/hunger in function of velocity

      if IsPedOnFoot(ped) and not tvRP.isNoclip() then

        local factor = math.min(tvRP.getSpeed(),10)



        vthirst = vthirst+1*factor

        vhunger = vhunger+0.5*factor

      end



      -- in melee combat, increase

      if IsPedInMeleeCombat(ped) then

        vthirst = vthirst+10

        vhunger = vhunger+5

      end



      -- injured, hurt, increase

      if IsPedHurt(ped) or IsPedInjured(ped) then

        vthirst = vthirst+2

        vhunger = vhunger+1

      end



      -- do variation

      if vthirst ~= 0 then

        vRPserver.varyThirst({vthirst/12.0})

      end



      if vhunger ~= 0 then

        vRPserver.varyHunger({vhunger/12.0})

      end

    end

  end

end)



-- COMA SYSTEM



local in_coma = false

local coma_left = cfg.coma_duration*60

local health = 200



Citizen.CreateThread(function() -- coma thread

  while true do

    Citizen.Wait(0)

    local ped = PlayerPedId()

    health = GetEntityHealth(ped)



    if health <= cfg.coma_threshold and coma_left > 0 then

      if not in_coma then -- go to coma state

        if IsEntityDead(ped) then -- if dead, resurrect

          local x,y,z = tvRP.getPosition()

          NetworkResurrectLocalPlayer(x, y, z, true, true, false)

          Citizen.Wait(0)

        end



        -- coma state

        in_coma = true

        vRPserver.updateHealth({cfg.coma_threshold}) -- force health update

        --vRPserver.addUserGroup({"- Hold Fri"}) -- putting player off job, when in coma (not working though)

        SetEntityHealth(ped, cfg.coma_threshold)

        SetEntityInvincible(ped,true)

        tvRP.playScreenEffect(cfg.coma_effect,-1)

        tvRP.ejectVehicle()

        tvRP.setRagdoll(true)

      else -- in coma

        -- maintain life

        if health < cfg.coma_threshold then

          SetEntityHealth(ped, cfg.coma_threshold)

        end

      end

    else

      if in_coma then -- get out of coma state



    -- E efter at fået førstehjælp

		if health > cfg.coma_threshold and IsControlPressed(1,51) then

				in_coma = false

				SetEntityInvincible(ped,false)

				tvRP.setRagdoll(false)

				tvRP.stopScreenEffect(cfg.coma_effect)

        tvRP.killComa()

        local comaPlayer = PlayerId()

				TriggerServerEvent("removeComaPlayer", comaPlayer)



					SetTimeout(10000, function()  -- able to be in coma again after coma death after 10 seconds

				coma_left = cfg.coma_duration*60

				end)

	    end





      -- ENTER for at komme til hospital

      if coma_left <= 0 and health <= cfg.coma_threshold and IsControlPressed(1,18) then -- get out of coma by death

        in_coma = false

        SetEntityInvincible(ped,false)

        tvRP.setRagdoll(false)

        tvRP.stopScreenEffect(cfg.coma_effect)

        tvRP.killComa()

        SetEntityHealth(ped, 0)

        local comaPlayer = PlayerId()

				TriggerServerEvent("removeComaPlayer", comaPlayer)



          SetTimeout(10000, function()  -- able to be in coma again after coma death after 10 seconds

        coma_left = cfg.coma_duration*60

        end)

      end





      end

    end

  end

end)





function tvRP.isInComa()

  return in_coma

end



-- kill the player if in coma

function tvRP.killComa()

  if in_coma then

    coma_left = 0

  end

end



function drawTxt(x,y ,width,height,scale, text, r,g,b,a, outline)

    SetTextFont(0)

    SetTextProportional(0)

    SetTextScale(scale, scale)

    SetTextColour(r, g, b, a)

    SetTextDropShadow(0, 0, 0, 0,255)

    SetTextEdge(1, 0, 0, 0, 255)

    SetTextDropShadow()

    if(outline)then

      SetTextOutline()

    end

    SetTextEntry("STRING")

    AddTextComponentString(text)

    DrawText(x - width/2, y - height/2 + 0.005)

end





Citizen.CreateThread(function() -- coma decrease thread

  while true do

    Citizen.Wait(1000)

    if in_coma and coma_left > 0 then

      coma_left = coma_left-1

    end

  end

end)



Citizen.CreateThread(function() -- disable health regen, conflicts with coma system

  while true do

    Citizen.Wait(100)

    -- prevent health regen

    SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)

  end

end)





local ped = PlayerPedId()

Citizen.CreateThread(function() -- coma decrease thread

  while true do

    Citizen.Wait(0)

    local ped = PlayerPedId()

    health = GetEntityHealth(ped)

						if in_coma and coma_left > 0 and health <= cfg.coma_threshold then

						  local coma_timeleft = DecimalsToMinutes(coma_left)

						  drawTxt(0.85, 1.40, 1.0,1.0,0.4, "Du er bevidstløs. Tid tilbage: ~r~"..coma_timeleft, 255, 255, 255, 255)

						elseif in_coma and coma_left <= 0 and health <= cfg.coma_threshold then

							drawTxt(0.87, 1.40, 1.0,1.0,0.4, "Tryk ~b~[ENTER]~w~ for at komme til hospitalet", 255, 255, 255, 255)

						end

  end

end)



Citizen.CreateThread(function() -- coma decrease thread

  while true do

    Citizen.Wait(0)

    local ped = PlayerPedId()

    health = GetEntityHealth(ped)

		if in_coma and health > cfg.coma_threshold then

				drawTxt(0.85, 1.43, 1.0,1.0,0.4, "Du har fået førstehjælp. Tryk ~b~[E]~w~ for at komme op igen", 255, 255, 255, 255)

		end

  end

end)



RegisterNetEvent("vrp:killComa")

AddEventHandler("vrp:killComa", function()

    coma_left = cfg.coma_duration*60

    in_coma = false

end)

