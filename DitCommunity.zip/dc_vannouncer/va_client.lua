local m = {} -- <<< Don't touch this!
-----------[ SETTINGS ]---------------------------------------------------

-- Delay in minutes between messages
m.delay = 10

-- Prefix appears in front of each message. 
-- Suffix appears on the end of each message.
-- Leave a prefix/suffix empty ( '' ) to disable them.
m.prefix = '^4[DC Meddelelse] '
m.suffix = '^4.'

-- You can make as many messages as you want.
-- You can use ^0-^9 in your messages to change text color.
m.messages = {   
    'Du bedes opdatere dig på vores regler jævnligt',
    'Husk at læse vores regler på discord.',
    'Problemer? Så er du velkommen til at joine vores discord, hvor vores staff team vil være klar til at hjælpe dig.',
    'Ansøgninger til Politi, Falck og Staff forgår på vores discord',
    'Hold venligst OOC-snak i chatten på et minimum. Benyt Discord ved spørgsmål.',
    'Admins kan ikke være online 24/7 - Benyt #text-support på Discord hvis vi ikke er ingame.',
    'Det er dit eget ansvar løbende at holde dig opdateret med vores regelsæt som findes på hjemmesiden.',
    'Vi anbefaler at have Medal.tv kørende til beviser ved eksempelvis FailRP, Refund eller andet.',
    'Finder du bugs? Meld dem til os i #rapportér-bugs på Discord.',
    'Serveren genstartes hver morgen kl. 06:00 og hver aften kl. 18:00',
    'Husk altid at have et bevis hvis du vil anklage en anden spiller',
    'Vi lytter meget gerne til jeres forslag. Benyt #forslag på Discord.',
    'Her vil komme lidt info tips engang imellem. Du kan slå disse fra med /info',
    'Alle nye spillere bedes huske at, skifte deres tøj og oprettet en identitet på rådhuset.',
    'Husk at tilmelde dig vores discord: ^1Discord.gg/WmU4Srn',
}

-- Player identifiers on this list will not receive any messages.
-- Simply remove all identifiers if you don't want an ignore list.
m.ignorelist = { 
    'ip:127.0.1.5',
    'steam:123456789123456',
    'license:1654687313215747944131321',
}
--------------------------------------------------------------------------


















-----[ CODE, DON'T TOUCH THIS ]-------------------------------------------
local playerIdentifiers
local enableMessages = true
local timeout = m.delay * 1000 * 60 -- from ms, to sec, to min
local playerOnIgnoreList = false
RegisterNetEvent('va:setPlayerIdentifiers')
AddEventHandler('va:setPlayerIdentifiers', function(identifiers)
    playerIdentifiers = identifiers
end)
Citizen.CreateThread(function()
    while playerIdentifiers == {} or playerIdentifiers == nil do
        Citizen.Wait(1000)
        TriggerServerEvent('va:getPlayerIdentifiers')
    end
    for iid in pairs(m.ignorelist) do
        for pid in pairs(playerIdentifiers) do
            if m.ignorelist[iid] == playerIdentifiers[pid] then
                playerOnIgnoreList = true
                break
            end
        end
    end
    if not playerOnIgnoreList then
        while true do
            for i in pairs(m.messages) do
                if enableMessages then
                    chat(i)
                    print('[vAnnouncer] Message #' .. i .. ' sent.')
                end
                Citizen.Wait(timeout)
            end
            
            Citizen.Wait(0)
        end
    else
        print('[vAnnouncer] Player is on ignorelist, no announcements will be received.')
    end
end)
function chat(i)
    TriggerEvent('chatMessage', '', {255,255,255}, m.prefix .. m.messages[i] .. m.suffix)
end
RegisterCommand('info', function()

    enableMessages = not enableMessages

    if enableMessages then

        status = '^*^2Slået til'

    else

        status = '^*^1Slået fra'

    end

    TriggerEvent('chatMessage', '', {255, 255, 255}, 'Info beskeder er nu '..status)

end, false)
--------------------------------------------------------------------------
