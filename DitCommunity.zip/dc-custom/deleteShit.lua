--print(GetHashKey('v_1_coils06'))local prop = {	-- garage bumme	307771752,	-136782495,	627816582,	-- orange tank trailers	-531344027,	-1184516519,	-- brandstation 	-910308975, -- v_1_vacuum01	503673375, -- v_1_vacuum02	153866875, -- v_1_vacuum003	459896566, -- v_1_vacuum004	838708030 -- v_1_coils06}

Citizen.CreateThread(function()
	while true do
		local pos = GetEntityCoords(GetPlayerPed(-1))

		local handle, object = FindFirstObject()
		local success


		if has_value(prop, GetEntityModel(object)) then
			RemoveProp(object)
		end
		repeat 
			success, object = FindNextObject(handle)

			if has_value(prop, GetEntityModel(object)) then
				RemoveProp(object)
			end
		until not success

		EndFindObject(handle)

		Citizen.Wait(500)
	end
end)

function RemoveProp(object)
	SetEntityAsMissionEntity(object,  false,  true)
	DeleteObject(object)
end

function has_value (tab, val)
    for index, value in ipairs(tab) do
        if value == val then
            return true
        end
    end

    return false
end