INTERIORS = {
    -- HOPITAL
    [2] = {id = 2, x = 293.42376708984, y = -1447.8876953125, z = 29.966588973999,  name = "Tryk på [%key] for at forlade hospitalet", destination = {1}},
    [1] = {id = 1, x = 275.65280151367, y = -1361.4327392578, z = 24.537811279297,  name = "Tryk på [%key] for at tilgå hospitalet", destination = {2}},
	
    -- bjerget
    [28] = {id = 28,x = 442.73156738281, y = 5571.9516601563, z = 781.18878173828,  name = "Tryk på [%key] for at tilgå", destination = {29}},
    [29] = {id = 29,x = -737.19067382813, y = 5594.8120117188, z = 41.654586791992,  name = "Tryk på [%key] for at forlade", destination = {28}},

    -- Lawyer
    [16] = {id = 16, x = -1898.3725585938, y = -572.23272705078, z = 11.844171524048,  name = "Tryk på [%key] for at tilgå", destination = {17}},
    [17] = {id = 17, x = -1902.0192871094, y = -572.36346435547, z = 19.097213745117,  name = "Tryk på [%key] for at forlade", destination = {16}},	
	
	-- New
    [18] = {id = 18, x =  3562.8259277344, y = 3690.3332519531, z = 28.121658325195,  name = "Tryk på [%key] for at tilgå", destination = {19}},
    [19] = {id = 19, x = 3526.3579101563, y = 3673.7409667969, z = 28.121139526367,  name = "Tryk på [%key] for at forlade", destination = {18}},
	
	-- New
    [20] = {id = 20, x =  -1396.8383789063, y = -1008.8212280273, z = 24.70457649231,  name = "Tryk på [%key] for at tilgå", destination = {21}},
    [21] = {id = 21, x = -1370.9072265625, y = -1001.8865966797, z = 8.2923002243042,  name = "Tryk på [%key] for at forlade", destination = {20}},
	
	-- New
    [22] = {id = 22, x =  -262.89254760742, y = -713.45825195313, z = 71.032730102539,  name = "Tryk på [%key] for at tilgå", destination = {23}},
    [23] = {id = 23, x = -271.89880371094, y = -693.51745605469, z = 34.276473999023,  name = "Tryk på [%key] for at forlade", destination = {22}},
	
	-- Helipad hospital
    [32] = {id = 32, x =  333.91326904297, y = -1433.7370605469, z = 46.511093139648,  name = "Tryk på [%key] for at forlade", destination = {33}},
    [33] = {id = 33, x = 246.5251159668, y = -1372.6726074219, z = 24.537788391113,  name = "Tryk på [%key] for at tilgå", destination = {32}},
	
	-- Weed
	[36] = {id = 36, x = 1066.0828857422, y = -3183.353515625, z = -39.163482666016,  name = "Tryk på [%key] for at tilgå", destination = {37}},
    [37] = {id = 37, x = 1744.0701904297, y = -1622.9008789063, z = 112.62669372559,  name = "Tryk på [%key] for at forlade", destination = {36}},
	
	-- Coke
	[38] = {id = 38, x = -289.27917480469, y = -1080.75390625, z = 23.021192550659, name = "Tryk på [%key] for at forlade", destination = {39}},
    [39] = {id = 39,x = 1088.5836181641, y = -3187.9079589844, z = -38.993465423584, name = "Tryk på [%key] for at tilgå", destination = {38}},
	
	-- Coke
	[40] = {id = 40, x = 997.29986572266, y = -3200.8791503906, z = -36.393726348877, name = "Tryk på [[%key] for at tilgå", destination = {41}},
    [41] = {id = 41,x = 484.54901123047, y = -1094.0007324219, z = 43.075675964355, name = "Tryk på [%key] for at forlade", destination = {40}},
	
	-- Hvidvask
	[42] = {id = 42, x = 524.52880859375, y = -3058.8908691406, z = 6.0696272850036, name = "Tryk på [[%key]] for at forlade", destination = {43}},
    [43] = {id = 43,x = 1118.9567871094, y = -3193.2739257812, z = -40.3911819458, name = "Tryk på [%key] for at tilgå", destination = {42}},
	
	--hvidvask 2
	[44] = {id = 44, x = 1138.0948486328, y = -3198.9953613281, z = -39.665679931641, name = "Tryk på [%key] for at tilgå", destination = {45}},
    [45] = {id = 45, x = -7.6719751358032, y = 6486.7490234375, z = 31.491014480591, name = "Tryk på [%key] for at forlade", destination = {44}},
	-- -7.6719751358032,6486.7490234375,31.491014480591
       
       -- Politistation Sandy Shores
   [46] = {id = 46, x = 1848.8763427734, y = 3689.8146972656, z = 34.267078399658, name = "Tryk på [%key] for at gå fra cellerne", destination = {47}}, --1853.8865966797, y = 3716.1584472656, z = 1.0767838954926
   [47] = {id = 47, x =  1853.8865966797, y = 3716.1584472656, z = 1.0767838954926, name = "Tryk på [%key] for at tilgå cellerne", destination = {46}},    
    
	--   Dommerne
	[51] = {id = 51, x = 246.83218383789, y = -337.20690917969, z = -118.79995727539,  name = "Tryk på [%key] for at forlade", destination = {52}},
    [52] = {id = 52, x = 241.24742126465, y = -303.85293579102, z = -118.79996490479,  name = "Tryk på [%key] for at tilgå", destination = {51}},	
    
    	--   Dommerne
	[55] = {id = 55, x = 234.56460571289, y = -413.37432861328, z = -118.46514892578,  name = "Tryk på [%key] for at forlade retssalen", destination = {56}},
    [56] = {id = 56, x = 138.17683410645, y = -765.11120605469, z = 45.752040863037,  name = "Tryk på [%key] for at tilgå retssalen", destination = {55}},	
  
    --advokat
    [57] = {id = 57, x = 136.14820861816, y = -761.69787597656, z = 242.15209960938,  name = "Tryk på [%key] for at forlade retssalen", destination = {58}},
    [58] = {id = 58, x = 136.06248474121, y = -761.81713867188, z = 45.752048492432,  name = "Tryk på [%key] for at tilgå retssalen", destination = {57}},	

  --nyt sygehus

   [65] = {id = 65, x = 315.93975830078, y = -583.26776123047, z = 43.281715393066,  name = "Tryk på [%key] for at forlade retssalen", destination = {66}},
   [66] = {id = 66, x = 339.31286621094, y = -584.00738525391, z = 74.165641784668,  name = "Tryk på [%key] for at tilgå retssalen", destination = {65}},	
 
   [67] = {id = 67, x = 332.09750366211, y = -595.54772949219, z = 43.284030914307,  name = "Tryk på [%key] for at forlade retssalen", destination = {68}},
   [68] = {id = 68, x = 359.50317382813, y = -584.95196533203, z = 28.816568374634,  name = "Tryk på [%key] for at tilgå retssalen", destination = {67}},
   [69] = {id = 69, x = 319.82357788086, y = -559.82220458984, z = 28.743450164795,  name = "Tryk på [%key] for at tilgå retssalen", destination = {70}},		
   [70] = {id = 70, x = 332.93200683594, y = -568.97814941406, z = 43.284030914307,  name = "Tryk på [%key] for at tilgå retssalen", destination = {69}},	

   [71] = {id = 71, x = 1651.2248535156, y = 2573.9709472656, z = 45.564849853516,  name = "Tryk på [%key] for at forlade retssalen", destination = {72}},
   [72] = {id = 72, x = 1629.7426757813, y = 2573.953125, z = 45.564891815186,  name = "Tryk på [%key] for at tilgå retssalen", destination = {71}},
   [73] = {id = 73, x = 1642.67578125, y = 2573.9604492188, z = 45.564853668213,  name = "Tryk på [%key] for at tilgå retssalen", destination = {74}},		
   [74] = {id = 74, x = 1027.4702148438, y = -3101.1823730469, z = -38.999870300293,  name = "Tryk på [%key] for at tilgå retssalen", destination = {73}},	


   [75] = {id = 75, x = -448.22137451172, y = 6007.869140625, z = 31.716375350952,  name = "Tryk på [%key] for at tilgå cellerne", destination = {76}},
   [76] = {id = 76, x = 1863.0659179688, y = 3670.244140625, z = -116.7899017334,  name = "Tryk på [%key] for at forlade cellerne", destination = {75}},
}
