cfg = {}

cfg.healthtext = true
cfg.armortext = true
cfg.hungertext = false
cfg.thirsttext = false
cfg.staminatext = false
cfg.deadtext = "DØD"
cfg.tiredtext = "TRÆT"
