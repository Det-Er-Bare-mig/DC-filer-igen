 	local thirst = 0
local hunger = 0


RegisterNetEvent("kaz_stoffer:stamina")
AddEventHandler("kaz_stoffer:stamina", function ()
tid = 1*60
	while tid > 0 do
	Citizen.Wait(1000)
    RestorePlayerStamina(PlayerId(), 100.0)
	test = 100-GetPlayerSprintStaminaRemaining(PlayerId())
	tid = tid-1
	end	
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(100)
        TriggerServerEvent("getData")

        SendNUIMessage({
            show = IsPauseMenuActive(),
            health = GetEntityHealth(GetPlayerPed(-1)) - 100,
            armor = GetPedArmour(GetPlayerPed(-1)),
            stamina = 100 -  math.ceil(GetPlayerSprintStaminaRemaining(PlayerId())),
            hunger = math.ceil(100-hunger), 
            thirst = math.ceil(100-thirst),
            healthtext = cfg.healthtext,
            armortext = cfg.armortext,	
            hungertext = cfg.hungertext,
            thirsttext = cfg.thirsttext,
            staminatext = cfg.staminatext,
            deadtext = cfg.deadtext,
			tiredtext = cfg.tiredtext
        })
    end
end)

RegisterNetEvent("returnBasics")
AddEventHandler("returnBasics", function (rHunger, rThirst)
    hunger = rHunger
    thirst = rThirst
end)

-- Voice
local voice = {default = 5.0, shout = 12.0, whisper = 1.0, current = 0, level = nil}

AddEventHandler('onClientMapStart', function()
	if voice.current == 0 then
		NetworkSetTalkerProximity(voice.default)
		SendNUIMessage({
     		voicelvl = 60
     	});
	elseif voice.current == 1 then
		NetworkSetTalkerProximity(voice.shout)
		SendNUIMessage({
     		voicelvl = 100
     	});
	elseif voice.current == 2 then
		NetworkSetTalkerProximity(voice.whisper)
		SendNUIMessage({
     		voicelvl = 30
     	});
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)

		if IsControlJustPressed(1, 213) then -- Page UP
			voice.current = (voice.current + 1) % 3
			if voice.current == 0 then
				NetworkSetTalkerProximity(voice.default)
				SendNUIMessage({
					voicelvl = 60
				});
			elseif voice.current == 1 then
				NetworkSetTalkerProximity(voice.shout)
				SendNUIMessage({
					voicelvl = 30
				});
			elseif voice.current == 2 then
				NetworkSetTalkerProximity(voice.whisper)				
				SendNUIMessage({
					voicelvl = 100
				});
			end
		end

		if voice.current == 0 then
			SendNUIMessage({
				voicelvl = 60
			});
		elseif voice.current == 1 then
			SendNUIMessage({
				voicelvl = 30
			});
		elseif voice.current == 2 then
			SendNUIMessage({
				voicelvl = 100
			});
		end
		if NetworkIsPlayerTalking(PlayerId()) then
			SendNUIMessage({talking = true})

		elseif not NetworkIsPlayerTalking(PlayerId()) then
			SendNUIMessage({talking = false})
		end
	end
end)