--[[
─────────────────────────────────────────────────────────────────────────────────────────────────────────
─██████──████████─██████████████─██████████████████─██████████████─██████████████─██████──────────██████─
─██░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
─██░░██──██░░████─██░░██████░░██─████████████░░░░██─██░░██████░░██─██░░██████░░██─██░░░░░░░░░░██──██░░██─
─██░░██──██░░██───██░░██──██░░██─────────████░░████─██░░██──██░░██─██░░██──██░░██─██░░██████░░██──██░░██─
─██░░██████░░██───██░░██████░░██───────████░░████───██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░░░░░░░░░██───██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░██████░░██───██░░██████░░██───████░░████───────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██──██░░██─
─██░░██──██░░██───██░░██──██░░██─████░░████─────────██░░██──██░░██─██░░██──██░░██─██░░██──██░░██████░░██─
─██░░██──██░░████─██░░██──██░░██─██░░░░████████████─██░░██████░░██─██░░██████░░██─██░░██──██░░░░░░░░░░██─
─██░░██──██░░░░██─██░░██──██░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██████████░░██─
─██████──████████─██████──██████─██████████████████─██████████████─██████████████─██████──────────██████─
─────────────────────────────────────────────────────────────────────────────────────────────────────────
]]--

RegisterCommand("open", function()
	TriggerEvent("kaz_clothstore:toggleMenu", '')
end)

local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
  }
  
local LastSex		= -1
local LoadSkin		= nil
local LoadClothes	= nil
local Character		= {}

	local Components = {
		{label = ('sex'),						name = 'sex',				value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('face'),					name = 'face',				value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('skin'),					name = 'skin',				value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('hair_1'),					name = 'hair_1',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('hair_2'),					name = 'hair_2',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('hair_color_1'),			name = 'hair_color_1',		value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('hair_color_2'),			name = 'hair_color_2',		value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('tshirt_1'),				name = 'tshirt_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('tshirt_2'),				name = 'tshirt_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'tshirt_1'},
		{label = ('torso_1'),					name = 'torso_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('torso_2'),					name = 'torso_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'torso_1'},
		{label = ('decals_1'),				name = 'decals_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('decals_2'),				name = 'decals_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'decals_1'},
		{label = ('arms'),					name = 'arms',				value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('arms_2'),					name = 'arms_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('pants_1'),					name = 'pants_1',			value = nil,		min = 0,	zoomOffset = 0.8,		camOffset = -0.5},
		{label = ('pants_2'),					name = 'pants_2',			value = nil,		min = 0,	zoomOffset = 0.8,		camOffset = -0.5,	textureof	= 'pants_1'},
		{label = ('shoes_1'),					name = 'shoes_1',			value = nil,		min = 0,	zoomOffset = 0.8,		camOffset = -0.8},
		{label = ('shoes_2'),					name = 'shoes_2',			value = nil,		min = 0,	zoomOffset = 0.8,		camOffset = -0.8,	textureof	= 'shoes_1'},
		{label = ('mask_1'),					name = 'mask_1',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('mask_2'),					name = 'mask_2',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65,	textureof	= 'mask_1'},
		{label = ('bproof_1'),				name = 'bproof_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('bproof_2'),				name = 'bproof_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'bproof_1'},
		{label = ('chain_1'),					name = 'chain_1',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('chain_2'),					name = 'chain_2',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65,	textureof	= 'chain_1'},
		{label = ('helmet_1'),				name = 'helmet_1',			value = nil,		min = -1,	zoomOffset = 0.6,		camOffset = 0.65,	componentId	= 0 },
		{label = ('helmet_2'),				name = 'helmet_2',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65,	textureof	= 'helmet_1'},
		{label = ('glasses_1'),				name = 'glasses_1',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65},
		{label = ('glasses_2'),				name = 'glasses_2',			value = nil,		min = 0,	zoomOffset = 0.6,		camOffset = 0.65,	textureof	= 'glasses_1'},
		{label = ('watches_1'),				name = 'watches_1',			value = nil,		min = -1,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('watches_2'),				name = 'watches_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'watches_1'},
		{label = ('bracelets_1'),				name = 'bracelets_1',		value = nil,		min = -1,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('bracelets_2'),				name = 'bracelets_2',		value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'bracelets_1'},
		{label = ('bag'),						name = 'bags_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('bag_color'),				name = 'bags_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15,	textureof	= 'bags_1'},
		{label = ('eye_color'),				name = 'eye_color',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('eyebrow_size'),			name = 'eyebrows_2',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('eyebrow_type'),			name = 'eyebrows_1',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('eyebrow_color_1'),			name = 'eyebrows_3',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('eyebrow_color_2'),			name = 'eyebrows_4',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('makeup_type'),				name = 'makeup_1',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('makeup_thickness'),		name = 'makeup_2',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('makeup_color_1'),			name = 'makeup_3',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('makeup_color_2'),			name = 'makeup_4',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('lipstick_type'),			name = 'lipstick_1',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('lipstick_thickness'),		name = 'lipstick_2',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('lipstick_color_1'),		name = 'lipstick_3',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('lipstick_color_2'),		name = 'lipstick_4',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('ear_accessories'),			name = 'ears_1',			value = nil,		min = -1,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('ear_accessories_color'),	name = 'ears_2',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65,	textureof	= 'ears_1'},
		{label = ('chest_hair'),				name = 'chest_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('chest_hair_1'),			name = 'chest_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('chest_color'),				name = 'chest_3',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('bodyb'),					name = 'bodyb_1',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('bodyb_size'),				name = 'bodyb_2',			value = nil,		min = 0,	zoomOffset = 0.75,		camOffset = 0.15},
		{label = ('wrinkles'),				name = 'age_1',				value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('wrinkle_thickness'),		name = 'age_2',				value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('blemishes'),				name = 'blemishes_1',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('blemishes_size'),			name = 'blemishes_2',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('blush'),					name = 'blush_1',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('blush_1'),					name = 'blush_2',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('blush_color'),				name = 'blush_3',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('complexion'),				name = 'complexion_1',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('complexion_1'),			name = 'complexion_2',		value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('sun'),						name = 'sun_1',				value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('sun_1'),					name = 'sun_2',				value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('freckles'),				name = 'moles_1',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('freckles_1'),				name = 'moles_2',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('beard_type'),				name = 'beard_1',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('beard_size'),				name = 'beard_2',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('beard_color_1'),			name = 'beard_3',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65},
		{label = ('beard_color_2'),			name = 'beard_4',			value = nil,		min = 0,	zoomOffset = 0.4,		camOffset = 0.65}
	}
	
	for i=1, #Components, 1 do
	Character[Components[i].name] = Components[i].value
	end



RegisterNetEvent("kaz_clothstore:reset")
AddEventHandler("kaz_clothstore:reset", function()
	for i=1, #Components, 1 do
	Character[Components[i].name] = nil
	end	
	local cam = -1							
	local zoom = "ropa"					
	local isCameraActive
	local camHeading = 0.0
	local angulo = 0
	local camOffset, zoomOffset = 1.8, 0.0
	TriggerEvent("kaz_clothstore:toggleMenu", '')
end)

local cam = -1							
local zoom = "ropa"					
local isCameraActive
local camHeading = 0.0
local angulo = 0
local camOffset, zoomOffset = 1.8, 0.0

local m, f = GetHashKey("mp_m_freemode_01"), GetHashKey("mp_f_freemode_01")
local cor = 0
local menuactive = false

RegisterNetEvent("kaz_clothstore:toggleMenu")
AddEventHandler("kaz_clothstore:toggleMenu", function(restriction)
	menuactive = not menuactive
	if menuactive then
		CreateSkinCam()
		zoom = "ropa"
		SetNuiFocus(true,true)
		local ped = PlayerPedId()
		if IsPedModel(ped, m) then
			SendNUIMessage({ showMenu = true, masc = true, type = restriction})
		elseif IsPedModel(ped, f) then
			SendNUIMessage({ showMenu = true, masc = false, type = restriction})		
		end
	else
		cor = 0
		dados, tipo = nil
		SetNuiFocus(false)
		SendNUIMessage({ showMenu = false, masc = true })

		DeleteSkinCam()
	end
end)

RegisterNUICallback('zoom', function(data, cb)
	zoom = data
end)


function CreateSkinCam()
	if not DoesCamExist(cam) then
		cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
	end
	local playerPed = PlayerPedId()
	local playerHeading = GetEntityHeading(playerPed)
	if playerHeading + 94 < 360.0 then
		camHeading = playerHeading + 94.0
	elseif playerHeading + 94 >= 360.0 then
		camHeading = playerHeading - 266.0 --194
	end
	angulo = camHeading
	isCameraActive = true
	SetCamCoord(cam, GetEntityCoords(GetPlayerPed(-1)))
	SetCamActive(cam, true)
	Citizen.Wait(500)
	RenderScriptCams(true, true, 2000, true, true)
end

function DeleteSkinCam()
	isCameraActive = false
	SetCamActive(cam, false)
	RenderScriptCams(false, true, 2000, true, true)
	cam = nil
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if isCameraActive == true then
			local playerPed = PlayerPedId()
			local coords    = GetEntityCoords(playerPed)
			if zoom == "cara" or zoom == "pelo" then
				zoomOffset = 0.5
				camOffset = 0.7
			elseif zoom == "tops" then
				zoomOffset = 1.2
				camOffset = 0.5
			elseif zoom == "pants" then
				zoomOffset = 1.2
				camOffset = -0.3
			elseif zoom == "ropa" then
				zoomOffset = 1.8
				camOffset = 0.0
			elseif zoom == "zapatos" then
				zoomOffset = 1.0
				camOffset = -0.8
			end
			local angle = camHeading * math.pi / 180.0
			local theta = {
				x = math.cos(angle),
				y = math.sin(angle)
			}

			local pos = {
				x = coords.x + (zoomOffset * theta.x),
				y = coords.y + (zoomOffset * theta.y)
			}

			local angleToLook = camHeading - 200.0 --140.0
			if angleToLook > 360 then
				angleToLook = angleToLook - 360
			elseif angleToLook < 0 then
				angleToLook = angleToLook + 360
			end

			angleToLook = angleToLook * math.pi / 180.0
			local thetaToLook = {
				x = math.cos(angleToLook),
				y = math.sin(angleToLook)
			}

			local posToLook = {
				x = coords.x + (zoomOffset * thetaToLook.x),
				y = coords.y + (zoomOffset * thetaToLook.y)
			}

			SetCamCoord(cam, pos.x, pos.y, coords.z + camOffset)
			PointCamAtCoord(cam, posToLook.x, posToLook.y, coords.z + camOffset)
		else
			Citizen.Wait(500)
		end
	end

end)

RegisterNUICallback("exit", function()
	TriggerEvent("kaz_clothstore:hasExitedMarker")
	TriggerEvent("kaz_clothstore:toggleMenu")
	TriggerEvent("kaz_clothstore:menuClosed")
end)

RegisterNUICallback("rotate", function(data, cb)
	if data == "left" then
		angulo = angulo - 1
	elseif data == "right" then
		angulo = angulo + 1
	end

	if angulo > 360 then
		angulo = angulo - 360
	elseif angulo < 0 then
		angulo = angulo + 360
	end

	camHeading = angulo + 0.0

end)

RegisterNUICallback("update", function(data, cb)
	dados = tonumber(json.encode(data[1]))
	tipo = tonumber(json.encode(data[2]))
	cor = 0
	setRoupa(dados, tipo, cor)
end)

RegisterNUICallback("color", function(data, cb)
	if data == "left" then
		if cor ~= 0 then cor = cor - 1 else cor = 20 end
	elseif data == "right" then
		if cor ~= 21 then cor = cor + 1 else cor = 0 end
	end
	if dados and tipo then setRoupa(dados, tipo, cor) end
end)

function setRoupa(dados, tipo, cor)
	local ped = PlayerPedId()
	local key = ''
	local color = ''
	if(dados < 100) then
		if dados == 1 then
			key = 'mask_1'
			color = 'mask_2'
		elseif dados == 3 then
			key = 'arms'
			color = 'arms_2'
		elseif dados == 4 then
			key = 'pants_1'
			color = 'pants_2'
		elseif dados == 5 then
			key = 'bags_1'
			color = 'bags_2'
		elseif dados == 6 then
			key = 'shoes_1'
			color = 'shoes_2'
		elseif dados == 7 then
			key = 'chain_1'
			color = 'chain_2'
		elseif dados == 8 then 
			key = 'tshirt_1'
			color = 'tshirt_2'
		elseif dados == 9 then
			key = 'bproof_1'
			color = 'bproof_2'
		elseif dados == 11 then
			key = 'torso_1'
			color = 'torso_2'
		end
	else
		dadas = dados-100
		if dadas == 0 then
			key = 'helmet_1'
			color = 'helmet_2'
		elseif dadas == 1 then
			key = 'glasses_1'
			color = 'glasses_2'
		elseif dadas == 2 then
			key = 'ears_1'
			color = 'ears_2'
		elseif dadas == 6 then 
			key = 'watches_1'
			color = 'watches_2'
		end
	end
	setskin(key, tipo)
	setskin(color, cor)
end

function setskin(key, val)
Character[key] = val
	if key == 'sex' then
		loadskin(Character)
	else
		ApplySkin(Character)
	end
end

function ApplySkin(skin, clothes)
	local playerPed = PlayerPedId()
	if Character['face'] ~= nil then 
	SetPedHeadBlendData			(playerPed, Character['face'], Character['face'], Character['face'], Character['skin'], Character['skin'], Character['skin'], 1.0, 1.0, 1.0, true)
	end
	if Character['hair_color_1'] ~= nil then 
	SetPedHairColor				(playerPed,			Character['hair_color_1'],		Character['hair_color_2'])					-- Hair Color
	end
	if Character['age_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 3,		Character['age_1'],				(Character['age_2'] / 10) + 0.0)			-- Age + opacity
	end
	if Character['blemishes_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 0,		Character['blemishes_1'],		(Character['blemishes_2'] / 10) + 0.0)		-- Blemishes + opacity
	end
	if Character['beard_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 1,		Character['beard_1'],			(Character['beard_2'] / 10) + 0.0)			-- Beard + opacity
	end
	if Character['eye_color'] ~= nil then
	SetPedEyeColor				(playerPed,			Character['eye_color'], 0, 1)												-- Eyes color
	end
	if Character['eyebrows_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 2,		Character['eyebrows_1'],		(Character['eyebrows_2'] / 10) + 0.0)		-- Eyebrows + opacity
	end
	if Character['makeup_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 4,		Character['makeup_1'],			(Character['makeup_2'] / 10) + 0.0)			-- Makeup + opacity
	end
	if Character['lipstick_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 8,		Character['lipstick_1'],		(Character['lipstick_2'] / 10) + 0.0)		-- Lipstick + opacity
	end
	if Character['hair_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 2,		Character['hair_1'],			Character['hair_2'], 2)						-- Hair
	end
	if Character['beard_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 1, 1,	Character['beard_3'],			Character['beard_4'])						-- Beard Color
	end
	if Character['eyebrows_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 2, 1,	Character['eyebrows_3'],		Character['eyebrows_4'])					-- Eyebrows Color
	end
	if Character['makeup_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 4, 1,	Character['makeup_3'],			Character['makeup_4'])						-- Makeup Color
	end
	if Character['lipstick_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 8, 1,	Character['lipstick_3'],		Character['lipstick_4'])					-- Lipstick Color
	end
	if Character['blush_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 5,		Character['blush_1'],			(Character['blush_2'] / 10) + 0.0)			-- Blush + opacity
	end
	if Character['blush_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 5, 2,	Character['blush_3'])														-- Blush Color
	end
	if Character['complexion_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 6,		Character['complexion_1'],		(Character['complexion_2'] / 10) + 0.0)		-- Complexion + opacity
	end
	if Character['sun_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 7,		Character['sun_1'],				(Character['sun_2'] / 10) + 0.0)			-- Sun Damage + opacity
	end
	if Character['moles_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 9,		Character['moles_1'],			(Character['moles_2'] / 10) + 0.0)			-- Moles/Freckles + opacity
	end
	if Character['chest_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 10,		Character['chest_1'],			(Character['chest_2'] / 10) + 0.0)			-- Chest Hair + opacity
	end
	if Character['chest_3'] ~= nil then
	SetPedHeadOverlayColor		(playerPed, 10, 1,	Character['chest_3'])														-- Torso Color
	end
	if Character['bodyb_1'] ~= nil then
	SetPedHeadOverlay			(playerPed, 11,		Character['bodyb_1'],			(Character['bodyb_2'] / 10) + 0.0)			-- Body Blemishes + opacity
	end
	if Character['ears_1'] ~= nil then
		if Character['ears_1'] == -1 then
			ClearPedProp(playerPed, 2)
		else
			SetPedPropIndex			(playerPed, 2,		Character['ears_1'],			Character['ears_2'], 2)						-- Ears Accessories
		end
	end

	if Character['tshirt_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 8,		Character['tshirt_1'],			Character['tshirt_2'], 2)					-- Tshirt
	end
	if Character['torso_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 11,		Character['torso_1'],			Character['torso_2'], 2)					-- torso parts
	end
	if Character['arms'] ~= nil then
	SetPedComponentVariation	(playerPed, 3,		Character['arms'],				Character['arms_2'], 2)						-- Amrs
	end
	if Character['decals_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 10,		Character['decals_1'],			Character['decals_2'], 2)					-- decals
	end
	if Character['pants_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 4,		Character['pants_1'],			Character['pants_2'], 2)					-- pants
	end
	if Character['shoes_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 6,		Character['shoes_1'],			Character['shoes_2'], 2)					-- shoes
	end
	if Character['mask_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 1,		Character['mask_1'],			Character['mask_2'], 2)						-- mask
	end
	if Character['bproof_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 9,		Character['bproof_1'],			Character['bproof_2'], 2)					-- bulletproof
	end
	if Character['chain_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 7,		Character['chain_1'],			Character['chain_2'], 2)					-- chain
	end
	if Character['bags_1'] ~= nil then
	SetPedComponentVariation	(playerPed, 5,		Character['bags_1'],			Character['bags_2'], 2)						-- Bag
	end

	if Character['helmet_1'] ~= nil then
		if Character['helmet_1'] == -1 then
			ClearPedProp(playerPed, 0)
		else
			SetPedPropIndex			(playerPed, 0,		Character['helmet_1'],			Character['helmet_2'], 2)					-- Helmet
		end
	end

	if Character['glasses_1'] ~= nil then
		if Character['glasses_1'] == -1 then
			ClearPedProp(playerPed, 1)
		else
			SetPedPropIndex			(playerPed, 1,		Character['glasses_1'],			Character['glasses_2'], 2)					-- Glasses
		end
	end
	
	if Character['watches_1'] ~= nil then
		if Character['watches_1'] == -1 then
			ClearPedProp(playerPed, 6)
		else
			SetPedPropIndex			(playerPed, 6,		Character['watches_1'],			Character['watches_2'], 2)					-- Watches
		end
	end

	if Character['bracelets_1'] ~= nil then
		if Character['bracelets_1'] == -1 then
			ClearPedProp(playerPed,	7)
		else
			SetPedPropIndex			(playerPed, 7,		Character['bracelets_1'],		Character['bracelets_2'], 2)				-- Bracelets
		end
	end
end


function loadskin(skin, cb)
	if skin['sex'] ~= LastSex then
		LoadSkin = skin

		if skin['sex'] == 0 then
			TriggerEvent('skinchanger:loadDefaultModel', true, cb)
		else
			TriggerEvent('skinchanger:loadDefaultModel', false, cb)
		end
	else
		ApplySkin(skin)

		if cb ~= nil then
			cb()
		end
	end

	LastSex = skin['sex']
end
