

vRP = Proxy.getInterface("vRP")  



  Citizen.CreateThread(function()
    while true do
      Citizen.Wait(0)
      local playerPed = GetPlayerPed(-1)
      
      DrawMarker(27, 463.1696472168,-1019.720703125,28.107007980347 - 0.9, 0, 0, 0, 0, 0, 0, 3.0001, 3.0001, 0.5001, 0, 155, 255, 200, 0, 0, 0,100)
    if GetDistanceBetweenCoords(463.1696472168,-1019.720703125,28.107007980347, GetEntityCoords(GetPlayerPed(-1))) < 3.0 then
     
      DrawText3D(463.1696472168,-1019.720703125,28.107007980347, "Tryk [~b~E~s~] for at reparer køretøjet")
        if (IsControlJustReleased(1, 38)) then
          if IsPedInAnyVehicle(playerPed) then
     
            local vehicle = GetVehiclePedIsIn(playerPed)
          
          exports['progressBars']:startUI(3000, "Reparer køretøj...")
          Citizen.Wait(3000)
          
          SetVehicleEngineHealth(vehicle, 9999)
          SetVehiclePetrolTankHealth(vehicle, 9999)
          SetVehicleFixed(vehicle)
          
          else
       
          TriggerEvent("pNotify:SendNotification",{text = "Du er ikke i et køretøjet.",type = "success",timeout = (5000),layout = "centerLeft",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
          
         
        end
      end
    end
  end

    
      end)

   

  

  


  
    
 
  
	



    function DrawText3D(x,y,z, text)
      local onScreen, _x, _y = World3dToScreen2d(x, y, z)
      local px, py, pz = table.unpack(GetGameplayCamCoords())
    
      SetTextScale(0.35, 0.35)
      SetTextFont(4)
      SetTextProportional(1)
      SetTextColour(255, 255, 255, 215)
      SetTextEntry("STRING")
      SetTextCentre(1)
      AddTextComponentString(text)
      DrawText(_x, _y)
      local factor = (string.len(text)) / 370
      DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
    end