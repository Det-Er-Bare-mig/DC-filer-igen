--[[
  _____  _ _           _____                                      _ _         
 |  __ \(_) |         / ____|                                    (_) |        
 | |  | |_| |_       | |     ___  _ __ ___  _ __ ___  _   _ _ __  _| |_ _   _ 
 | |  | | | __|      | |    / _ \| '_ ` _ \| '_ ` _ \| | | | '_ \| | __| | | |
 | |__| | | |_       | |___| (_) | | | | | | | | | | | |_| | | | | | |_| |_| |
 |_____/|_|\__|       \_____\___/|_| |_| |_|_| |_| |_|\__,_|_| |_|_|\__|\__, |
                                                                         __/ |
                                                                        |___/ 
        ------------------------CREDITS------------------------
        --   Copyright 2019 Nixdk#1234. All rights reserved --
        --                 Made for DitCommunity             --
        -------------------------------------------------------
]]-- 652.6044921875,2732.0322265625,41.99560546875

local Farm = {
  x = 2222.26, y = 5577.28, z = 53.83, -- 2222.26,5577.28,53.83
  x2 = 1774.7504882813, y2 = 4999.6752929688, z2 = 52.288726806641 -- 1774.7504882813,4999.6752929688,52.288726806641
}

local Farm2 = {
    x5 = 3561.4052734375, y5 = 3671.81640625, z5 = 28.12188911438, -- 3561.4052734375,3671.81640625,28.12188911438
    x6 = -1189.8294677734, y6 = 4443.6333007813, z6 = 31.128986358643, -- -1189.8294677734,4443.6333007813,31.128986358643
    x8 = 2432.0439453125, y8 = 4970.380859375, z8 = 42.34761428833, -- 2432.0439453125,4970.380859375,42.34761428833
    x10 = 652.6044921875, y10 = 2732.0322265625, z10 = 41.99560546875, --1089.6788330078,6509.0419921875,21.08641242981
    x11 = -190.56700134277, y11 = 6143.41015625, z11 = 36.929382324219, ---190.56700134277,6143.41015625,36.929382324219
    x12 = 1591.1697998047, y12 = 3591.1528320313, z12 = 38.766540527344  --1591.1697998047,3591.1528320313,38.766540527344
}

local Farm3 = {
    x2 = -1868.3781738281, y2 = 2177.0966796875, z2 = 113.31826019287, -- -1868.3781738281,y=2177.0966796875,z=113.31826019287
    x3 = 1089.6788330078, y3 = 6509.0419921875, z3 = 21.08641242981 --1089.6788330078,6509.0419921875,21.08641242981
}


Citizen.CreateThread(function()
  while true do
      Citizen.Wait(0)
      if GetDistanceBetweenCoords(Farm.x,Farm.y,Farm.z, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
          if IsPedActiveInScenario(PlayerPedId()) then
              DrawText3D(Farm.x, Farm.y, Farm.z, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
          else
              DrawText3D(Farm.x, Farm.y, Farm.z, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
              if IsControlJustPressed(0, 38) then
                  TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
              end
          end
      end
  end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm.x2,Farm.y2,Farm.z2, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm.x2, Farm.y2, Farm.z2, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm.x2, Farm.y2, Farm.z2, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
  end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm.x3,Farm.y3,Farm.z3, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm.x3, Farm.y3, Farm.z3, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm.x3, Farm.y3, Farm.z3, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm3.x2,Farm3.y2,Farm3.z2, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm3.x2, Farm3.y2, Farm3.z2, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm3.x2, Farm3.y2, Farm3.z2, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm3.x3,Farm3.y3,Farm3.z3, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm3.x3, Farm3.y3, Farm3.z3, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm3.x3, Farm3.y3, Farm3.z3, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x4,Farm2.y4,Farm2.z4, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x4, Farm.y4, Farm2.z4, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x4, Farm2.y4, Farm2.z4, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x5,Farm2.y5,Farm2.z5, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x5, Farm2.y5, Farm2.z5, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x5, Farm2.y5, Farm2.z5, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x6,Farm2.y6,Farm2.z6, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x6, Farm2.y6, Farm2.z6, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x6, Farm2.y6, Farm2.z6, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x7,Farm2.y7,Farm2.z7, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x7, Farm2.y7, Farm2.z7, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x7, Farm2.y7, Farm2.z7, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x8,Farm2.y8,Farm2.z8, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x8, Farm2.y8, Farm2.z8, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x8, Farm2.y8, Farm2.z8, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x9,Farm2.y9,Farm2.z9, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x9, Farm2.y9, Farm2.z9, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x9, Farm2.y9, Farm2.z9, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x10,Farm2.y10,Farm2.z10, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x10, Farm2.y10, Farm2.z10, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x10, Farm2.y10, Farm2.z10, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x11,Farm2.y11,Farm2.z11, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x11, Farm2.y11, Farm2.z11, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x11, Farm2.y11, Farm2.z11, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(Farm2.x12,Farm2.y12,Farm2.z12, GetEntityCoords(GetPlayerPed(-1))) < 6.0 then
            if IsPedActiveInScenario(PlayerPedId()) then
                DrawText3D(Farm2.x12, Farm2.y12, Farm2.z12, "Tryk [~b~Z~w~] for at ~r~stoppe ~w~høste animationen")
            else
                DrawText3D(Farm2.x12, Farm2.y12, Farm2.z12, "Tryk [~b~E~w~] for at ~g~starte ~w~høste animationen")
                if IsControlJustPressed(0, 38) then
                    TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_PARKING_METER', 0, true)
                end
            end
        end
    end
end)
-----------------------------------------------------------------

function DrawText3D(x,y,z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())

	SetTextScale(0.32, 0.32)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text)) / 450
	DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end


   --[[ SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
		local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 20,20,20,150)
end]]
