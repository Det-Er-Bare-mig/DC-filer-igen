Config = {}

Config.EnableBlips            = true
Config.VehicleFailure         = 5
Config.FuelPrice              = math.random(8, 20)
Config.Usage                  = 0.70
Config.EnableJerryCans        = true
Config.EnableBuyableJerryCans = true
Config.JerryCanPrice          = 100*Config.FuelPrice
Config.JerryCanMaxAmmo        = 500