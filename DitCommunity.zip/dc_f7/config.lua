-- Menu configuration, array of menus to display
menuConfigs = {
    ['menu'] = {
        enableMenu = function()
            return true
        end,
            data = {
                keybind = "F7",
                style = {
                    sizePx = 600,
                    slices = {
                        default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                        hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                        selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                    },
                    titles = {
                        default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                        hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                        selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                    },
                    icons = {
                        width = 64,
                        height = 64
                    }
                },
                wheels = {
                    {
                        navAngle = 270,
                        minRadiusPercent = 0.25,
                        maxRadiusPercent = 0.55,
                        labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                        commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                    },
                    {
                        navAngle = 288,
                        minRadiusPercent = 0.6,
                        maxRadiusPercent = 0.9,
                        labels = {"Pift", "Tys", "Sid", "Læn", "Damn", "Bange", "Hep", "Fuck", "Satans", "Salute", "Sidned", "Bitchno"},
                        commands = {"e pift", "e tys", "e sid", "e læn", "e damn", "e bange", "e hep", "e fuck", "e satans", "e salute", "e sidned", "e Bitchno"}
    
                    }
                }
            }
        }
    }
-- Submenu configuration
subMenuConfigs = {
    ['submenu1.1'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Farm", "Vagt", "Ligpåmaven", "Ligpåsiden", "Ligpåryggen", "Lænforover", "Bitchno", "Sarkastisk", "Langsomklap", "Peace", "Fingerknæk", "Luftkys", "Dj", "Gift"},
                    commands = {"e farm", "e vagt", "e ligpåmaven", "e ligpåsiden", "e ligpåryggen", "e lænforover", "e bitchno", "e sarkastisk", "e langsomklap", "e peace", "e fingerknæk", "e luftkys", "e dj", "e gift"}
                }
            }
        }
    },
    ['submenu1.2'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Kaffe", "Bor", "Vodka", "Hammer", "Kost", "Vask", "Udklipsholder", "Notesblok", "Pengekast", "Plant", "Tigger", "Trafik", "Paraply", "Pizza", "Stok", "Kuffert", "Kasse", "Falsk hest"},
                    commands = {"e kaffe", "e bor", "e vodka", "e hammer", "e kost", "e vask", "e udklipsholder", "e notesblok", "e makeitrain", "e plant", "e tigger", "e trafik", "paraply", "pizza", "stok", "kuffert", "box", "unicorn"}
                }
            }
        }
    },
    ['submenu1.3'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"imgsrc:https://i.imgur.com/pF999Wr.png","imgsrc:https://i.imgur.com/hZetaji.png", "imgsrc:https://i.imgur.com/2KT76lz.png", "imgsrc:https://i.imgur.com/gs2gUeN.png", "imgsrc:https://i.imgur.com/FF1KZxk.png", "imgsrc:https://i.imgur.com/Lv2XzDc.png"},
                    commands = {"hat","maske", "briller", "trøje", "bukser", "sko"}
                }
            }
        }
    },
    ['submenu1.4'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/beaming_face_with_smiling_eyes_256_2.gif", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/triumph_face_256_3.gif", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/exploding_head_256_1.gif", "imgsrc:https://i.pinimg.com/originals/80/17/c6/8017c6303e6150dc1d58915359dbfecb.gif", "imgsrc:https://i.pinimg.com/originals/db/20/93/db20933d7c8769ce016dcf99fc3c56ae.gif", "imgsrc:https://images.vexels.com/media/users/3/134792/isolated/preview/11021ac040438214430837e55f4225b7-3d-smile-emoticon-emoji-by-vexels.png"},
                    commands = {"ansigt glad", "ansigt sur", "ansigt overrasket", "ansigt gab", "ansigt fuld", "ansigt normal"}
                }
            }
        }
    },
    ['submenu1.5'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Dans1", "Dans2", "Dans3", "Dans4", "Dans5", "Dans6", "Dans7", "Dans8", "Dans9", "Dans10", "Dans11","Dans12", "Syredans"},
                    commands = {"e dans", "e dans2", "e dans3", "e dans4", "e dans5", "e dans6", "e dans7", "e dans8", "e dans9", "e dans10", "e dans11","e dans12", "e lesterdans"}
                }
            }
        }
    },
    ['submenu1.6'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Chinups", "Trip", "Yoga", "Flex", "Vægt", "Mavebøjninger", "Armbøjninger", "Gørsigklar"},
                    commands = {"e chinups", "e trip", "e yoga", "e flex", "e vægt", "e mavebøjninger", "e armbøjninger", "e gørsigklar"}
                }
            }
        }
    },
    ['submenu1.7'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Charme", "Flash", "Strip", "Strip2", "Strip3", "Modtag sex fra en", "Hav sex med en", "Modtag blowjob", "Giv blowjob", "Wank", "Luder", "Luder2", "Luder3", "Hyggefinger"},
                    commands = {"e charme", "e flash", "e strip", "e strip2", "e strip3", "e analgetter", "e analgiver", "e bjgetter", "e bjgiver", "e wank", "e luder", "e luder2", "e luder3", "e hyggefinger"}
                }
            }
        }
    },
    ['submenu1.8'] = {
        data = {
            keybind = "F7",
            style = {
                sizePx = 600,
                slices = {
                    default = { ['fill'] = '#000000', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.60 },
                    hover = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 },
                    selected = { ['fill'] = '#369bff', ['stroke'] = '#000000', ['stroke-width'] = 3, ['opacity'] = 0.80 }
                },
                titles = {
                    default = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    hover = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' },
                    selected = { ['fill'] = '#ffffff', ['stroke'] = 'none', ['font'] = 'Helvetica', ['font-size'] = 16, ['font-weight'] = 'bold' }
                },
                icons = {
                    width = 64,
                    height = 64
                }
            },
            wheels = {
                {
                    navAngle = 270,
                    minRadiusPercent = 0.25,
                    maxRadiusPercent = 0.55,
                    labels = {"imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/woman_shrugging_256_2.gif", "imgsrc:https://66.media.tumblr.com/5e85da6e1f96c001699fabea4f91280b/tumblr_o7lotwnlUH1ur7yfpo1_500.gif", "imgsrc:https://i.imgur.com/Sf1rUWJ.png", "imgsrc:https://d1j8pt39hxlh3d.cloudfront.net/uploads/zany_face_256_1.gif", "imgsrc:https://i.kym-cdn.com/photos/images/original/001/427/738/85a.gif", "imgsrc:https://media0.giphy.com/media/4Tgw6vkz7WbvZDFR8n/source.gif", "imgsrc:https://images.emojiterra.com/google/android-pie/512px/1f51e.png"},
                    commands = {"submenu1.1", "submenu1.2", "submenu1.3", "submenu1.4", "submenu1.5", "submenu1.6", "submenu1.7", "submenu1.8"}
                },
                {
                    navAngle = 288,
                    minRadiusPercent = 0.6,
                    maxRadiusPercent = 0.9,
                    labels = {"Charme", "Flash", "Strip", "Strip2", "Strip3", "Analgetter", "Analgiver", "Bjgetter", "Bjgiver", "Wank", "Luder", "Luder2", "Luder3", "Hyggefinger"},
                    commands = {"e charme", "e flash", "e strip", "e strip2", "e strip3", "e analgetter", "e analgiver", "e bjgetter", "e bjgiver", "e wank", "e luder", "e luder2", "e luder3", "e hyggefinger"}
                }
            }
        }
    }
}