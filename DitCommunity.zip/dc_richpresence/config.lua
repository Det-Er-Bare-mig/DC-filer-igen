Config = {}

Config.Title = "DitCommunity™"
Config.DiscordAppID = 520315045830328359
Config.MaxClients = "90"
Config.DiscordRichPresenceAssetName = "logo"
Config.ShowCharacterFullName = true 
Config.ShowUserID = true
Config.ShowPlayerCounter = true