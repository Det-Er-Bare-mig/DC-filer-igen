    local function drawTxt(x,y ,width,height,scale, text, r,g,b,a)

    SetTextFont(0)

    --SetTextProportional(0)

    SetTextScale(scale, scale)

    SetTextColour(r, g, b, a)

    --SetTextDropShadow(0, 0, 0, 0, 255)

    --SetTextEdge(0, 0, 0, 0, 255)

    --SetTextDropShadow()

    --SetTextOutline()

    SetTextEntry("STRING")

    AddTextComponentString(text)

    DrawText(x - width/2, y - height/2 + 0.002)

end



local onlinePlayers = 0



Citizen.CreateThread(function()

    while true do

        Citizen.Wait(0)

        drawTxt(0.7350, 0.497, 0.5,0.8,0.22, onlinePlayers.." i byen", 255, 255, 255, 255 )

    end

end)



Citizen.CreateThread(function()

    while true do



    onlinePlayers = 0

        for _,i in ipairs(GetActivePlayers()) do

                onlinePlayers = onlinePlayers+1

        end

      Wait(5000)

  end

end)

