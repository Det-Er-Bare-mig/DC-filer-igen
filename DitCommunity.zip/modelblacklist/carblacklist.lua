-- CONFIG --

-- Blacklisted vehicle models
carblacklist = {
	"rhino",
	"jet",
	"FireTruck",
	"Barracks",
	"Predator",
	"Barracks2",
	"hyrda",
	"volatol",
	"rhino",
    "jet",
    "hyrda",
    "lazer",
	"insurgent",
	"starling",
	"miljet",
	"nokota",
	"pyro",
	"cargoplane",
	"microlight",
	"buzzard2",
	"oppressor",
	"oppressor",
	"monster",
	"Liberator",
	"rogue",
	"savage",
	"Akula",
	"Cerberus",
	"Caracara",
	"Menacer",
	"Buzzard",
	"Squaddie",
	"titan",
	"Valkyrie",
	"Vulkan"
}

-- CODE --

Citizen.CreateThread(function()
	while true do
		Wait(1)

		playerPed = GetPlayerPed(-1)
		if playerPed then
			checkCar(GetVehiclePedIsIn(playerPed, false))

			x, y, z = table.unpack(GetEntityCoords(playerPed, true))
			for _, blacklistedCar in pairs(carblacklist) do
				checkCar(GetClosestVehicle(x, y, z, 100.0, GetHashKey(blacklistedCar), 70))
			end
		end
	end
end)

function checkCar(car)
	if car then
		carModel = GetEntityModel(car)
		carName = GetDisplayNameFromVehicleModel(carModel)

		if isCarBlacklisted(carModel) then
			_DeleteEntity(car)
			sendForbiddenMessage("[DC-AntiCheat] Du prøver at bruge et bugged køretøj, Logs er sendt til staff!")
		end
	end
end

function isCarBlacklisted(model)
	for _, blacklistedCar in pairs(carblacklist) do
		if model == GetHashKey(blacklistedCar) then
			return true
		end
	end

	return false
end