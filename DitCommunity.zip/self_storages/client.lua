local blip_data = {
    id = 478,
    color = 46,
}

function SetBlipName(blip, name)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(name)
    EndTextCommandSetBlipName(blip)
end

local function useOrigin()
    return true
end

    
RegisterNetEvent("omni:self_storage:add")
AddEventHandler("omni:self_storage:add", function(data)
    local uqid = data.id
    if data.area then
        uqid = uqid .. ":" .. data.area
    end
    locations[uqid] = {
        fee = data.fee, name = data.name, size = data.size, cost = 5000000000,
        id = data.id,
        hidden = data.hidden,
        storage_locations = {
            {x = data.pos.x, y = data.pos.y, z = data.pos.z},
        },
    }
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)
        local ped = GetPlayerPed(-1)
        local pos = GetEntityCoords(ped)
        local veh = GetVehiclePedIsIn(ped, true)
        for id, location in next, locations do
            for _,coords in next, location.storage_locations do
                if not coords.blip and not location.hidden then
                    coords.blip = AddBlipForCoord(coords.x, coords.y, coords.z)
                    SetBlipAsShortRange(coords.blip, true)
                    SetBlipSprite(coords.blip, blip_data.id)
                    SetBlipColour(coords.blip, blip_data.color)
                    SetBlipScale(coords.blip, 1.0)
                    SetBlipName(coords.blip, "Opbevaringsrum")
               end
                local dist = #(vector3(pos.x, pos.y, pos.z) - vector3(coords.x, coords.y, coords.z))
                if dist < 15.0 then
                    if dist > 3.0 then
                        --Højten på teksten "Opbevaringsrum" --
                        --DrawText3D("~y~Opbevaringsrum | ~g~Kr." .. location.fee.." ~y~gebyr~n~~w~" .. location.name, coords.x, coords.y, coords.z + 1.0, 1.3)
                        DrawText3D("Tryk ~b~[E]~w~ for at bruge opbevaringsrummet", coords.x, coords.y, coords.z - 0.25, 1.3)
                    else
                        --Højten på teksten "Opbevaringsrum" --
                        DrawText3D("Tryk ~b~[E]~w~ for at bruge opbevaringsrummet", coords.x, coords.y, coords.z - 0.25, 1.3)
                        if IsControlJustPressed(0, 38) and not IsPedInVehicle(ped, veh, true) then
                            TriggerServerEvent("omni:self_storage:open", location.id or id)
                        end
                    end
                    DrawMarker(27, coords.x, coords.y, coords.z - 1.0, 0, 0, 0, 0, 0, 0, 2.0, 2.0, 2.0, 0, 171, 255, 50, 0, 0, 0, 50)
                end
            end
        end
    end
end)
function DrawText3D(text, x, y, z, s, font, a)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
