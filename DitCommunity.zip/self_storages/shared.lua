locations = {
    ["Opb"] = {
        fee = 150, name = "Opbevaringsrum", size = 5000, cost = 1000000,
        storage_locations = {
            {x = 579.58239746094, y = -2805.2150878906, z = 6.1592713356018},
        }
    },
    ["Opb2"] = {
        fee = 150, name = "Opbevaringsrum", size = 5000, cost = 1000000,
        storage_locations = {
            {x = 503.39028930664, y = -1970.06, z = 24.837106704712},
        }
    },
    ["Opb3"] = {
        fee = 150, name = "Opbevaringsrum", size = 5000, cost = 1000000,
        storage_locations = {
            {x = -976.09478759766, y = -267.46166992188, z = 38.29829788208},
        }
    },
}

function ReadableNumber(num, places)
    local ret
    local placeValue = ("%%.%df"):format(places or 0)
    if not num then
        return 0
    elseif num >= 1000000000000 then
        ret = placeValue:format(num / 1000000000000) .. " Tril" -- trillion
    elseif num >= 1000000000 then
        ret = placeValue:format(num / 1000000000) .. " Bil" -- billion
    elseif num >= 1000000 then
        ret = placeValue:format(num / 1000000) .. " Mil" -- million
    elseif num >= 1000 then
        ret = placeValue:format(num / 1000) .. "k" -- thousand
    else
        ret = num -- hundreds
    end
    return ret
end