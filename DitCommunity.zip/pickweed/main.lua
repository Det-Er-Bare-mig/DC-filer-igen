local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}
local UI = { 

    x =  0.000 ,  -- Base Screen Coords   +    x
    y = -0.001 ,  -- Base Screen Coords   +   -y
  
  }
vRP = Proxy.getInterface("vRP")

vRPclient = Tunnel.getInterface("vRP", "pickweed")



Citizen.CreateThread(function()
		Citizen.Wait(10)
	ScriptLoaded()
end)


function ScriptLoaded()
	Citizen.Wait(1000)
	LoadMarkers()
end






cachedPlant = {}
closestPlant = {
    'bkr_prop_weed_lrg_01a',
    'bkr_prop_weed_lrg_01b',
    'bkr_prop_weed_med_01a',
    'bkr_prop_weed_med_01b',
    'bkr_prop_weed_01_small_01a',
    'bkr_prop_weed_01_small_01b',
    'bkr_prop_weed_01_small_01c'


}






Citizen.CreateThread(function()
    while true do
        Citizen.Wait(60000)
        cachedPlant = {}
    end
end)



Citizen.CreateThread(function()
    while true do
        
        local sleep = 1000
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        for i = 1, #closestPlant do
            local x = GetClosestObjectOfType(playerCoords, 2.0, GetHashKey(closestPlant[i]), false, false, false)
            local entity = nil
            if DoesEntityExist(x) then
                entity = x
                Plant    = GetEntityCoords(entity)
                sleep  = 5
                DrawText3D(Plant.x, Plant.y, Plant.z + 1.5, 'Tryk [~b~E~s~] for at høste ~b~planten~s~')  
                if IsControlJustReleased(0, 38) then
                    if not cachedPlant[entity] then
                        OpenPlant(entity)
                    else
                        TriggerEvent("pNotify:SendNotification",{text = "Planten er allerede høstet",type = "error",timeout = (5000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer=true})

                    end
                end
                break
            else
                sleep = 1000
            end
        end
        Citizen.Wait(sleep)
    end
end)



local Positions = {
	['Sell'] = { ['hint'] = 'Tryk [~b~E~s~] for at omdanne', ['x'] = 1035.978515625, ['y'] = -3205.7644042969, ['z'] = -38.17357635498 }
}

function LoadMarkers()


	Citizen.CreateThread(function()
		while true do
			local sleep = 500
			
			local plyCoords = GetEntityCoords(PlayerPedId())

			for index, value in pairs(Positions) do
				if value.hint ~= nil then

					local distance = GetDistanceBetweenCoords(plyCoords, value.x, value.y, value.z, true)

					if distance < 5.0 then
						sleep = 5
						 DrawM(value.hint, 27, value.x, value.y, value.z - 0.945, 255, 255, 255, 3.5, 15)

						if distance < 1.0 then
							if IsControlJustReleased(0, Keys['E']) then

									SellItems()
							end
						end
					end

				end
				
			end
			Citizen.Wait(sleep)
		end
	end)
end



function SellItems()
	exports['progressBars']:startUI(38000, "Tørrer blade...")
	TriggerEvent("dc-animation:startWithItem", "notesblok")
	FreezeEntityPosition((GetPlayerPed(-1)), true) -- Freeze Entity
	Citizen.Wait(38000)
	TriggerServerEvent('pickweed:omdan')
	FreezeEntityPosition((GetPlayerPed(-1)), false) -- Freeze Entity
	TriggerEvent("dc-animation:stopAnim", "notesblok")
end

function LoadAnimDict(dict)
    while (not HasAnimDictLoaded(dict)) do
        RequestAnimDict(dict)
        Citizen.Wait(10)
    end    
end

function LoadModel(model)
    while not HasModelLoaded(model) do
          RequestModel(model)
          Citizen.Wait(10)
    end
end

function DrawM(hint, type, x, y, z)
	DrawText3Ds(x, y, z + 1.0, hint)
	DrawMarker(type, x, y, z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.5, 1.5, 1.5, 255, 255, 255, 100, false, true, 2, false, false, false, false)
end

function DrawText3Ds(x,y,z, text)
	local onScreen,_x,_y=World3dToScreen2d(x,y,z)
	local px,py,pz=table.unpack(GetGameplayCamCoords())
	SetTextScale(0.35, 0.35)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text)) / 370
	DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
