function AddTextEntry(key, value)
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end
	
Citizen.CreateThread(function()
	AddTextEntry('0x001225AE', 'Drift')
	AddTextEntry('0x004757C5', 'Black Broker Cap')
	AddTextEntry('0x006C8145', 'Gold Kronos Ära')
	AddTextEntry('0x009BB720', 'Front Bumper Delete')
	AddTextEntry('0x00B9A4D0', 'Pineapple Mask')
	AddTextEntry('0x00B5041D', 'Black Waterproof')
	AddTextEntry('0x00E7BFD8', 'Commercial Bumper')
	AddTextEntry('0x00F70341', 'Apricot Bigness Waterproof')
	AddTextEntry('0x010CE633', 'Silver Fame or Shame Mics')
	AddTextEntry('0x0182276E', 'Ace of Diamonds')
	AddTextEntry('0x0199F6A8', 'Stickerbomb Trunk')
	AddTextEntry('0x01A0B15F', 'You\'re Awful Tee')
	AddTextEntry('0x01A1BCE2', 'Primary Aggressive Spoiler')
	AddTextEntry('0x01A2F482', 'Vintage Fulton')
	AddTextEntry('0x01B324D0', 'Angled Ram Pipes')
	AddTextEntry('0x01B21437', 'Primary/Carbon Race Hood')
	AddTextEntry('0x01BA70AA', 'Black SN High Roller Jacket')
	AddTextEntry('0x01CA2B92', 'Sea Green High Roller Dress')
	AddTextEntry('0x01D1CA55', 'Gray Blagueurs Parka')
	AddTextEntry('0x01E2B1B1', 'Secondary Bumper & Carbon')
	AddTextEntry('0x02492650', 'Smoothed Hood')
	AddTextEntry('0x025B78ED', 'Crisp High Roller Shirt')
	AddTextEntry('0x025C08F6', 'Splinter Deep Shades')
	AddTextEntry('0x029CB9B7', 'Fukaru Crowex')
	AddTextEntry('0x02C9B130', 'Burger Shot')
	AddTextEntry('0x02C424F1', 'Squash Squares Hoodie')
	AddTextEntry('0x02E3102B', 'Painted Wind Deflector')
	AddTextEntry('0x02F076C6', 'Black Fame or Shame Kronos')
	AddTextEntry('0x02F2B15E', 'Sprunk Light')
	AddTextEntry('0x02F5DAC1', 'Roll Cage')
	AddTextEntry('0x03288111', 'NEXT')
	AddTextEntry('0x034A2969', 'Adorned Knee Shorts')
	AddTextEntry('0x0362F281', 'Carbon Vented Hood')
	AddTextEntry('0x03633708', 'I\'ve Been Shamed Tee')
	AddTextEntry('0x03825C2F', 'Black Two Tone')
	AddTextEntry('0x03AA5F4A', 'Radial Boxed Exhausts')
	AddTextEntry('0x03C658A4', 'Black Aggressive Spoiler')
	AddTextEntry('0x03D0CEE0', 'Blue Loose Bow Tie')
	AddTextEntry('0x03E56AF7', 'White Dice Earrings')
	AddTextEntry('0x0420B987', 'Thick Sebastian Dix Tee')
	AddTextEntry('0x04227566', 'Broker Coin Sweater')
	AddTextEntry('0x046EDD5B', 'Red The Diamond Cap')
	AddTextEntry('0x0499B426', 'The High Roller')
	AddTextEntry('0x049A1853', 'Spade Ceaseless')
	AddTextEntry('0x04A1C0F0', 'Carbon Stripped Hood w/ Vents')
	AddTextEntry('0x04C0768E', 'Salmon High Roller Jacket')
	AddTextEntry('0x04E8ECB4', 'XL GT Spoiler')
	AddTextEntry('0x04E9F241', 'Black Fleur Cocktail Dress')
	AddTextEntry('0x04EE9721', 'Mission I Tee')
	AddTextEntry('0x04FC3D87', 'Smokey Peyote')
	AddTextEntry('0x05030A76', 'Black Kronos Ära')
	AddTextEntry('0x051C2E8F', 'Blue Ancient Large Shirt')
	AddTextEntry('0x0525B249', 'Motor Market Racing')
	AddTextEntry('0x0543F4EA', 'Trunk Luggage')
	AddTextEntry('0x0562F343', 'Secondary Window Plates')
	AddTextEntry('0x056AFA30', 'Sport Splitter')
	AddTextEntry('0x05B3FC8E', 'Black Enduring Watch')
	AddTextEntry('0x05B54FCF', 'Aggressive Spoiler')
	AddTextEntry('0x05C6A5DF', 'Secondary Grille Bed Rack')
	AddTextEntry('0x05DD324A', 'Blue LS Diamond Cap')
	AddTextEntry('0x05E3C736', 'SC Broker Fitted')
	AddTextEntry('0x0605515D', 'Sectioned Exhausts')
	AddTextEntry('0x0625CF5E', 'Carbon Vysser Grille')
	AddTextEntry('0x06293CD5', 'Pink LS Diamond Cap')
	AddTextEntry('0x06403152', 'Black High Roller Shirt')
	AddTextEntry('0x064FA30D', 'Racing Cage')
	AddTextEntry('0x06757776', 'Rear Bumper Delete')
	AddTextEntry('0x0675AB00', 'Pink Chips Earrings')
	AddTextEntry('0x06A46273', 'Dual Blue Stripes')
	AddTextEntry('0x06B75250', 'Bigness Rage Bomber')
	AddTextEntry('0x06DBE1B5', 'Carbon Exhausts')
	AddTextEntry('0x06EA170D', 'Yeti Heat Hoodie')
	AddTextEntry('0x06FF7F4C', 'Sectioned Exhaust')
	AddTextEntry('0x071C1F85', 'Secondary Mirrors')
	AddTextEntry('0x072902E9', 'Titanium Exhausts')
	AddTextEntry('0x072D90E7', 'Life\'s a Gamble')
	AddTextEntry('0x074C0FE8', 'If life is a party, this is the venue.')
	AddTextEntry('0x078E443A', 'Vents GT II')
	AddTextEntry('0x07A618AB', 'Race Exhaust')
	AddTextEntry('0x07B1E8E2', 'Turquoise Güffy Spray Puffer')
	AddTextEntry('0x07B6D675', 'Deck Enduring Watch')
	AddTextEntry('0x07BC41CC', 'Green FB Manor Slipper Loafers')
	AddTextEntry('0x07D880F2', 'Triple Painted Cover Exhaust')
	AddTextEntry('0x07DA32AE', 'Multi Pipe Set Up')
	AddTextEntry('0x07E200EE', 'Deck Enduring Watch')
	AddTextEntry('0x07F1F0A5', 'Cage & Race Seats')
	AddTextEntry('0x08251916', 'Wheel Crowex Époque')
	AddTextEntry('0x082663F6', 'Red Fame or Shame Kronos')
	AddTextEntry('0x0871B536', 'Yellow Chips Large Shirt')
	AddTextEntry('0x0873D9CF', 'Grille Delete')
	AddTextEntry('0x08C01334', 'Lucky 7s')
	AddTextEntry('0x08C957B8', 'Black Color Bomber')
	AddTextEntry('0x08C2903A', 'Pink Patterned Wide Pants')
	AddTextEntry('0x08D01857', 'Here at The Diamond, we understand the fine art of the slot machine. We recognize the split-second reflexes, the years of research and training, the rock-solid intuition and the towering IQ that make a true master. That\'s right. We\'ve been waiting for you.')
	AddTextEntry('0x08D3AED6', 'White SC Broker Wide Pants')
	AddTextEntry('0x09301221', 'Exposed Intercooler')
	AddTextEntry('0x094538C2', 'Weave High Roller Pants')
	AddTextEntry('0x09527DCA', 'White The Diamond Resort Tee')
	AddTextEntry('0x097E8D13', 'Black Color Bomber')
	AddTextEntry('0x09C458EF', 'Muscle Wedged Splitter')
	AddTextEntry('0x09D86EA9', 'Yellow Camo Blagueurs Parka')
	AddTextEntry('0x0A01CA00', 'What\'s that you say? You were hoping to make extravagant additions to the most opulent living space on the planet? Step right this way...')
	AddTextEntry('0x0A3B05A0', 'Primary Rollpan Bumper')
	AddTextEntry('0x0A5B14F4', 'Ash The Diamond Hoodie')
	AddTextEntry('0x0A52A5BA', 'Primary Sunstrip')
	AddTextEntry('0x0A77BA93', 'Red Dice Earrings')
	AddTextEntry('0x0A80EA3C', 'Too Much Free Time')
	AddTextEntry('0x0A56291E', 'This race takes place once every 5 minutes, and allows all players in session to bet on the same race.')
	AddTextEntry('0x0A710763', 'Secondary Rear Panel')
	AddTextEntry('0x0A770927', 'Carbon Drift Wing')
	AddTextEntry('0x0AF4D150', 'Gray Patterned Fitted')
	AddTextEntry('0x0B0FE8DF', 'Antenna')
	AddTextEntry('0x0B2C458F', 'Blue Fame or Shame Shades')
	AddTextEntry('0x0B4CAAEF', 'Race Carbon Bumper')
	AddTextEntry('0x0B7B332F', 'Brown Retro Sneakers')
	AddTextEntry('0x0B23C472', 'Pink Prairie Large Shirt')
	AddTextEntry('0x0B24DDDD', 'Chepalle')
	AddTextEntry('0x0B40FE5F', 'Dual Rounded Exhausts')
	AddTextEntry('0x0B44B532', 'Invade and Persuade RON Tee')
	AddTextEntry('0x0B347B5A', 'Pisswasser')
	AddTextEntry('0x0B521C75', 'White SC Broker Bomber')
	AddTextEntry('0x0B811B3E', 'Razzle Dazzle')
	AddTextEntry('0x0B946B22', 'Angled Exhausts')
	AddTextEntry('0x0B324893', 'Black Stripe')
	AddTextEntry('0x0BA9869A', 'America Loves You Tee')
	AddTextEntry('0x0BD55E44', 'Carbon Snorkel Hood')
	AddTextEntry('0x0C2CE13D', 'Carbon Bumper Splitter')
	AddTextEntry('0x0C3CC890', 'Digital Deep Shades')
	AddTextEntry('0x0C4BF569', 'Hexagon Blue')
	AddTextEntry('0x0C4D52BD', 'Black Vinewood Fitted')
	AddTextEntry('0x0C7C04B3', 'Oval Intake Bugcatcher')
	AddTextEntry('0x0C23C2B1', 'Primary Custom Skirt')
	AddTextEntry('0x0C26CFF0', 'Purple Broker Coin Bomber')
	AddTextEntry('0x0C48C6C0', 'Salmon Prairie Large Shirt')
	AddTextEntry('0x0C72D834', 'Invade and Persuade Gold Tee')
	AddTextEntry('0x0C81E50C', 'Modern Hood Latches')
	AddTextEntry('0x0C85DF95', 'Dual Filter Blower')
	AddTextEntry('0x0C991C98', 'Purple Waterproof')
	AddTextEntry('0x0C97022A', 'Carbon Roof')
	AddTextEntry('0x0CCA8DCF', 'Chic High Roller Shirt')
	AddTextEntry('0x0CCB5C37', 'Le Chien Jersey')
	AddTextEntry('0x0CFA2353', 'Dual Exhaust')
	AddTextEntry('0x0CFDB3B5', 'Painted Stock Hood')
	AddTextEntry('0x0D7E2411', 'Two Tone Fast Stripes')
	AddTextEntry('0x0D48BF50', 'Alpine Rack')
	AddTextEntry('0x0D67FFD1', 'Purple Color Jersey')
	AddTextEntry('0x0D88F248', 'Teal Broker Cap')
	AddTextEntry('0x0D778B9A', 'Blue Team Tracey Tee')
	AddTextEntry('0x0D4112F6', 'Purple Fade SN Parka')
	AddTextEntry('0x0D525306', 'PURCHASE MEMBERSHIP')
	AddTextEntry('0x0DA65311', 'Secondary Side Panel')
	AddTextEntry('0x0DE8F775', 'Racer Wing I')
	AddTextEntry('0x0DFF3F8E', 'Secondary Skirt')
	AddTextEntry('0x0E0253FD', 'RETRO ARCADE CABINET')
	AddTextEntry('0x0E0B478F', 'Black Stripes')
	AddTextEntry('0x0E6D64FD', 'White The Diamond Silk Robe')
	AddTextEntry('0x0E9A5B3D', 'Utility Bumper')
	AddTextEntry('0x0E9F4F3F', 'Red Stars Fame or Shame Robe')
	AddTextEntry('0x0E44E43B', 'Black Le Chien Parka')
	AddTextEntry('0x0E44EB6E', 'Ceramic Angled Headers')
	AddTextEntry('0x0E4506DD', 'Black SN Jersey')
	AddTextEntry('0x0E5004EE', 'Teal Broker Cap')
	AddTextEntry('0x0E5509CB', 'Broker Ornate Sweater')
	AddTextEntry('0x0E8244F6', 'Obey Stripe')
	AddTextEntry('0x0E724491', 'White Pulga Sweater')
	AddTextEntry('0x0EB807BE', 'Blue Sci-Fi Large Shirt')
	AddTextEntry('0x0ED92196', '777')
	AddTextEntry('0x0F4BE4DD', 'Patterned Blagueurs Large Shirt')
	AddTextEntry('0x0F6DC045', 'Short Ram Pipes / No Hood')
	AddTextEntry('0x0F6DCCF9', 'Blue Fame or Shame Logo Tee')
	AddTextEntry('0x0F83C956', 'Race Intercooler')
	AddTextEntry('0x0F266F01', 'Roulette Kronos Quad')
	AddTextEntry('0x0F216523', 'Carbon Street Hood')
	AddTextEntry('0x0FB50D0D', 'Orange LS Diamond Cap')
	AddTextEntry('0x0FBDC4C9', 'Secondary Ribbed Vents')
	AddTextEntry('0x0FD02FED', 'Queen of Clubs')
	AddTextEntry('0x0FD1D421', 'Vysser Stripes')
	AddTextEntry('0x0FE430CC', 'Cyan Baroque Cocktail Dress')
	AddTextEntry('0x1A7BF2D3', 'Gray Color Sweater')
	AddTextEntry('0x1A9FFBD9', 'Ridgeline Hood')
	AddTextEntry('0x1A49A04E', 'Triple Intake Bugcatcher')
	AddTextEntry('0x1A726313', 'Yellow Sunset Large Shirt')
	AddTextEntry('0x1AE79928', 'Black Stripes')
	AddTextEntry('0x1B070D40', 'Purple SC Broker Cap')
	AddTextEntry('0x1B0B3686', 'Gold Fifty Kronos Ära')
	AddTextEntry('0x1B5A52EC', 'Jack of Spades')
	AddTextEntry('0x1B8E598E', 'Classic Bullet')
	AddTextEntry('0x1B8EB6DE', 'Racing Splitter')
	AddTextEntry('0x1B88A180', 'Black Bigness Logo Jersey')
	AddTextEntry('0x1B667E60', 'Debonaire')
	AddTextEntry('0x1B972B68', 'Sharp High Roller Shirt')
	AddTextEntry('0x1B113743', 'Raid Rack')
	AddTextEntry('0x1BAEDF4F', 'The Urban Streets')
	AddTextEntry('0x1BB4C87E', 'Secondary Sunstrip')
	AddTextEntry('0x1BD65655', 'Choose Your Side Tee')
	AddTextEntry('0x1BDC28E2', 'Royal Enduring Watch')
	AddTextEntry('0x1BFAA043', 'Black Broker Cap')
	AddTextEntry('0x1C2BBE28', 'Black SC Broker Bomber')
	AddTextEntry('0x1C3A52FE', 'High Level Wing')
	AddTextEntry('0x1C4F5F2E', 'Green The Diamond Cap')
	AddTextEntry('0x1C5F76C7', 'Painted Utility Bumper')
	AddTextEntry('0x1C36A9AE', 'Octa Exhaust Set')
	AddTextEntry('0x1C63F08C', 'Primary Side Panel')
	AddTextEntry('0x1C959CBC', 'Vapid Large Grated Grille')
	AddTextEntry('0x1CDA14A3', 'Fame or Shame Logo Tee')
	AddTextEntry('0x1CEEBC69', 'Skull of Suits')
	AddTextEntry('0x1CF14EDF', 'CHOOSE YOUR STYLE')
	AddTextEntry('0x1D3B75DD', 'Pink Posies Fitted')
	AddTextEntry('0x1D5B9B52', 'Orange Fade Retro Sneakers')
	AddTextEntry('0x1D50ECA2', 'Red Fame or Shame Robe')
	AddTextEntry('0x1D9240F5', 'Red SC Broker Bomber')
	AddTextEntry('0x1DF8E76A', 'Logger Beer')
	AddTextEntry('0x1DF45B51', 'SC Broker Hoodie')
	AddTextEntry('0x1E3A1420', 'Gray Blagueurs Parka')
	AddTextEntry('0x1E5F47F7', 'YOUR PENTHOUSE AWAITS')
	AddTextEntry('0x1E6C6226', 'Classic w/ Vents')
	AddTextEntry('0x1E8F3157', 'Street Wing')
	AddTextEntry('0x1E9FC654', 'Chepalle')
	AddTextEntry('0x1E59DF88', 'Black SC Broker Knee Shorts')
	AddTextEntry('0x1E1770AC', 'Gold Abstraction')
	AddTextEntry('0x1E7507F5', 'Primary GT Spoiler')
	AddTextEntry('0x1EA0E016', 'White SC Broker Knee Shorts')
	AddTextEntry('0x1EB2BCB2', 'Vacation')
	AddTextEntry('0x1EBDDBF5', 'Primary Stock')
	AddTextEntry('0x1ECE8B15', 'Primary Race Splitter')
	AddTextEntry('0x1EEE938D', 'Race Spoiler')
	AddTextEntry('0x1EFE016E', 'Green Flying Bravo Cap')
	AddTextEntry('0x1F023422', 'Black Street Crimes Icons Tee')
	AddTextEntry('0x1F3EDA5F', 'Sec. Padded w/ Colored Seats')
	AddTextEntry('0x1F56F6A6', 'OFFICE')
	AddTextEntry('0x1F107D6F', 'Invade and Persuade Enemies Tee')
	AddTextEntry('0x1F353BDB', 'Primary Splitter')
	AddTextEntry('0x1F944FFB', 'Secondary/Carbon Race Hood')
	AddTextEntry('0x1F1164B2', 'Orange LS Diamond Cap')
	AddTextEntry('0x1F95616C', 'Lemon Mask')
	AddTextEntry('0x1FA4FAB8', 'Pink Patterned Fitted')
	AddTextEntry('0x1FDDD12F', 'Broker Cocktail Dress')
	AddTextEntry('0x1FFCAD2E', 'Check High Roller Jacket')
	AddTextEntry('0x2A0E4655', 'Tan Spade Kronos Ära')
	AddTextEntry('0x2A1F3A91', 'EXPERIENCE REVERENCE')
	AddTextEntry('0x2A3E6989', 'Inset Ducktail Spoiler')
	AddTextEntry('0x2AB4C44A', 'Sprigs High Roller Dress')
	AddTextEntry('0x2AB9C419', 'What\'s the difference between this and every other two-door, four-seat, six-figure coupe on the market, you ask? Well, dig down into the core stats and the answer is clear. More horses under the hood. More exhausts at the back. More road traffic fatalities, fewer convictions, and more angry bleets from teen environmentalists. The Drafter has it where it counts.')
	AddTextEntry('0x2AC33069', 'VIEW BET')
	AddTextEntry('0x2AD9266A', 'Suits Kronos Quad')
	AddTextEntry('0x2AEB7264', 'White Broker Wide Pants')
	AddTextEntry('0x2B0C4DCD', 'Gauntlet Classic')
	AddTextEntry('0x2B1D5DDD', 'Carbon Vented Roof')
	AddTextEntry('0x2B11AB5A', 'Competition Grilles')
	AddTextEntry('0x2B946BAC', 'Racing II')
	AddTextEntry('0x2B6847FA', 'Secondary Roll Bar Bumper')
	AddTextEntry('0x2BE28A3B', 'Colors Yeti Cap')
	AddTextEntry('0x2BED4028', 'Red SC Broker Cap')
	AddTextEntry('0x2C1F7B0F', 'Red Baroque Knee Shorts')
	AddTextEntry('0x2C98B0DD', 'Fall Blagueurs Parka')
	AddTextEntry('0x2C197C9C', 'Ace of Clubs')
	AddTextEntry('0x2C424B21', 'Primary Surround & Plating')
	AddTextEntry('0x2C56561D', 'Secondary Splitter')
	AddTextEntry('0x2CC52C4C', 'THIS LABEL NEEDS TO BE HERE !!!')
	AddTextEntry('0x2CC136D2', 'Baroque Kronos Tempo')
	AddTextEntry('0x2D3DC7B0', 'Brown SN High Roller Jacket')
	AddTextEntry('0x2D15CB55', 'Roulette Enduring Watch')
	AddTextEntry('0x2D51EB76', 'Full Carbon Race Hood')
	AddTextEntry('0x2D53DE8B', 'Get Lucky')
	AddTextEntry('0x2D58DD64', 'Yellow Waterproof')
	AddTextEntry('0x2D75A178', 'Oval Intake Bugcatcher')
	AddTextEntry('0x2D79E7CF', 'Pisswasser Beer')
	AddTextEntry('0x2D81FD75', 'Chrome Tooth')
	AddTextEntry('0x2D115C7F', 'Queen of Spades')
	AddTextEntry('0x2D8859C5', 'Blue Patterned Wide Pants')
	AddTextEntry('0x2DA53EA3', 'White Stripes')
	AddTextEntry('0x2DACA28B', 'Purple Loose Bow Tie')
	AddTextEntry('0x2DBA509A', 'RULES')
	AddTextEntry('0x2DBAE1B5', 'Rally Fogs')
	AddTextEntry('0x2DC75D54', 'Wild Leather Fur')
	AddTextEntry('0x2E8ADD53', 'White The Diamond Hoodie')
	AddTextEntry('0x2E52C512', 'White E Cocktail Dress')
	AddTextEntry('0x2E2707A7', 'Mute Deep Shades')
	AddTextEntry('0x2EB080F0', 'Carbon Skirt')
	AddTextEntry('0x2EC07C29', 'Claim What\'s Yours Tee')
	AddTextEntry('0x2ECBB5E9', 'Side Exit Exhaust')
	AddTextEntry('0x2F0125BF', 'Forest Camo Blagueurs Parka')
	AddTextEntry('0x2F5E4215', 'Germanic Stripes')
	AddTextEntry('0x2F9E115E', 'Yellow Stripe')
	AddTextEntry('0x2F9FD42B', 'Rear Arch Covers')
	AddTextEntry('0x2F790591', 'Black LS Diamond Cap')
	AddTextEntry('0x2FD7E99A', 'Red The Diamond Hoodie')
	AddTextEntry('0x3A4B7DCF', 'Gray Yeti LS 19 Hoodie')
	AddTextEntry('0x3A7D7F5F', 'Carbon Wind Deflector')
	AddTextEntry('0x3A7F903B', 'Gray Color Sweater')
	AddTextEntry('0x3A9E6226', 'Carbon Stock')
	AddTextEntry('0x3A49D7C0', 'Junk Alt')
	AddTextEntry('0x3A97F2A0', 'Carbon Splitter')
	AddTextEntry('0x3A611A4B', 'Tuner')
	AddTextEntry('0x3A919C90', 'Black Stripe')
	AddTextEntry('0x3A182091', 'Capped')
	AddTextEntry('0x3AB9118F', 'Prim. w/ Black Seats')
	AddTextEntry('0x3ADFE85C', 'Black Surround & Plating')
	AddTextEntry('0x3B0678BF', 'Lime Waterproof')
	AddTextEntry('0x3B1E7589', 'Road Trip')
	AddTextEntry('0x3B44EAC2', 'Drift Wing')
	AddTextEntry('0x3B469D18', 'White LS Diamond Cap')
	AddTextEntry('0x3B2935A0', 'Invade and Persuade Oil Tee')
	AddTextEntry('0x3BB9BDB8', 'Yellow Sci-Fi Large Shirt')
	AddTextEntry('0x3BBA9CB6', 'Primary Sports')
	AddTextEntry('0x3BBB6194', 'Secondary Performance Spoiler')
	AddTextEntry('0x3BFDE249', 'Yellow Sci-Fi Large Shirt')
	AddTextEntry('0x3C6BC094', 'Yellow Camo Blagueurs Parka')
	AddTextEntry('0x3C6E55CE', 'Fenders Delete')
	AddTextEntry('0x3C6FBF90', 'Ruby Blagueurs Parka')
	AddTextEntry('0x3C9E6A66', 'Primary Roll Bar Bumper')
	AddTextEntry('0x3C70F2F7', 'White Color Bomber')
	AddTextEntry('0x3C776A98', 'Green High Roller Waistcoat')
	AddTextEntry('0x3C859C57', 'Clean')
	AddTextEntry('0x3C987D14', 'Snake Eyes')
	AddTextEntry('0x3CF5411C', 'Yellow Loose Bow Tie')
	AddTextEntry('0x3D045508', 'Green Camo Blagueurs Parka')
	AddTextEntry('0x3D0AAC68', 'Blue FB Manor Slipper Loafers')
	AddTextEntry('0x3D0E4599', 'Woodland Yeti Puffer')
	AddTextEntry('0x3D4A6F2B', 'Big Bore Exhausts')
	AddTextEntry('0x3D31CEE0', 'Orange The Diamond Cap')
	AddTextEntry('0x3D37A10E', 'Red The Diamond Cap')
	AddTextEntry('0x3D58E66C', 'Secondary Vented Hood')
	AddTextEntry('0x3D61CFF9', 'Dual Red Stripes')
	AddTextEntry('0x3D81E9E4', 'White & Red High Roller Dress')
	AddTextEntry('0x3D310DB1', 'Patriot Beer')
	AddTextEntry('0x3D622C09', 'SN Tan Compass Tee')
	AddTextEntry('0x3D3303A2', 'Woodland Yeti LS 19 Hoodie')
	AddTextEntry('0x3D45193A', 'Street Crimes Logo Tee')
	AddTextEntry('0x3D412987', 'Oh No He Didn\'t! Tee')
	AddTextEntry('0x3DBBB2F9', 'White Broker Coin Bomber')
	AddTextEntry('0x3DBDD8BB', 'Silver Kronos Tempo')
	AddTextEntry('0x3DD72DD0', 'Kronos')
	AddTextEntry('0x3DDC2D8A', 'The Essence of Life')
	AddTextEntry('0x3DDDE95E', 'Purple The Diamond Cap')
	AddTextEntry('0x3E3D1F59', 'Thrax')
	AddTextEntry('0x3E6BFE9D', 'Snake Leather Fur')
	AddTextEntry('0x3E8BEA4C', 'Ornate High Roller Jacket')
	AddTextEntry('0x3E32E559', 'Stronzo')
	AddTextEntry('0x3E35CE13', 'Part of The Diamond Casino & Resort')
	AddTextEntry('0x3E68FEC4', 'Stripped Hood')
	AddTextEntry('0x3E669371', 'Chrome Grille Cover')
	AddTextEntry('0x3EF41723', 'Never again will you have to suppress your gag reflex as you rub shoulders with the general public in the cinema. In addition, you\'ll be free to enjoy Don\'t Cross the Line on the big screen with friends.')
	AddTextEntry('0x3F3B122D', 'Botanical High Roller Jacket')
	AddTextEntry('0x3F8EA554', 'Sand High Roller Pants')
	AddTextEntry('0x3F8F2FA4', 'Green Flying Bravo Cap')
	AddTextEntry('0x3F9A58AE', 'Maroon Broker Puffer')
	AddTextEntry('0x3F22ADD8', 'Grille Fogs & Light Covers')
	AddTextEntry('0x3F32DD10', 'EXPERIENCE INCONTINENCE')
	AddTextEntry('0x3F86FF7D', 'Brown Spade Kronos Ära')
	AddTextEntry('0x3F982A8B', 'Wind Deflectors')
	AddTextEntry('0x3FBE0682', 'Secondary Slat Skirt')
	AddTextEntry('0x4A061B21', 'PLAY WITH OTHERS')
	AddTextEntry('0x4A1A258A', 'PARTY PENTHOUSE')
	AddTextEntry('0x4A3B17F5', 'TIMELESS')
	AddTextEntry('0x4A25D8B3', 'GT Spoiler')
	AddTextEntry('0x4A107DC5', 'Chrome Piped Grille')
	AddTextEntry('0x4A283FA9', 'Sunrise Deep Shades')
	AddTextEntry('0x4A1668A9', 'Orange LS Diamond Cap')
	AddTextEntry('0x4A305258', 'Painted Heavy Duty Bumper')
	AddTextEntry('0x4A456372', 'Chrome Street Headers')
	AddTextEntry('0x4AA4D052', 'TBar Extended')
	AddTextEntry('0x4AA5C5AA', 'Dual Stock Exhausts')
	AddTextEntry('0x4AAE9EA3', 'Secondary Lifted Piped Step')
	AddTextEntry('0x4AEC3B19', 'Primary Sports w/ Vents')
	AddTextEntry('0x4AF5F686', 'Grayscale Retro Sneakers')
	AddTextEntry('0x4B084515', 'Red You\'re So Original! Tee')
	AddTextEntry('0x4B5D9AF8', 'Green Deep Shades')
	AddTextEntry('0x4B9BB6A7', 'Blagueurs Gray Box Hoodie')
	AddTextEntry('0x4B68F1C0', 'Red Monkey Business Tee')
	AddTextEntry('0x4B163E29', 'Teal Fade High Roller Dress')
	AddTextEntry('0x4BA3C88C', 'SN Purple Compass Tee')
	AddTextEntry('0x4BAEC92F', 'Atomic Tires')
	AddTextEntry('0x4BB0E617', 'Secondary Street Wing')
	AddTextEntry('0x4BE7A22B', 'Orange SN Bigness Hoodie')
	AddTextEntry('0x4C4C9A5E', 'Slate Perseus Leather Fur')
	AddTextEntry('0x4C4CD935', 'Red Chips Earrings')
	AddTextEntry('0x4C7A9B51', 'Queen of Diamonds')
	AddTextEntry('0x4C9F1A91', 'This is the greatest blank canvas money can buy.')
	AddTextEntry('0x4C62B4E2', 'Sec. w/ Black Seats')
	AddTextEntry('0x4C549CAA', 'Red Deep Shades')
	AddTextEntry('0x4D8A79BF', 'EXPERIENCE RESIDENCE')
	AddTextEntry('0x4D24DA13', 'Ignorance is Bliss')
	AddTextEntry('0x4D30A207', 'Secondary Paint')
	AddTextEntry('0x4D71D3D0', 'There was a time when no respectable motorist would admit to owning a trike. It was a kink you worked out on your own, once everyone else was in bed, behind sound-proofed garage doors. And then one day the Rampant Rocket launched, and everything changed. Once that supercharger found its way between your legs, it was impossible to be discreet, and impossible to feel ashamed. This is what liberation looks like.')
	AddTextEntry('0x4D96FA2D', 'Secondary Sunstrip')
	AddTextEntry('0x4D97AC84', 'Clean Skirt w/ Exit')
	AddTextEntry('0x4D96179F', 'Broker Detail Sweater')
	AddTextEntry('0x4D824603', 'LOCKED UNTIL LOUNGE IS PURCHASED')
	AddTextEntry('0x4DB4A26F', 'Primary Slat Skirt')
	AddTextEntry('0x4DC69027', 'Four Pointed Exhausts')
	AddTextEntry('0x4DD34FA3', 'Low GT Wing')
	AddTextEntry('0x4E096AC4', 'Drag Wing')
	AddTextEntry('0x4E0D2F69', 'No.56 Meinmacht')
	AddTextEntry('0x4E3C7942', 'The High Roller')
	AddTextEntry('0x4E4C1B8E', 'Racer 29')
	AddTextEntry('0x4E37E66C', 'Spade Crowex Rond')
	AddTextEntry('0x4E46C5D9', 'IMPERIAL')
	AddTextEntry('0x4E61E3CA', 'Black Enduring Watch')
	AddTextEntry('0x4E95F4F9', 'Carbon Grille')
	AddTextEntry('0x4E110DCB', 'Black High Roller Waistcoat')
	AddTextEntry('0x4E270F3C', 'SN Teal Compass Tee')
	AddTextEntry('0x4E7093AA', 'Bigness Rage Bomber')
	AddTextEntry('0x4E713046', 'Purple Fade SN Parka')
	AddTextEntry('0x4ED5B908', 'THE ONLY MEMBERSHIP YOU WILL EVER NEED')
	AddTextEntry('0x4EE74355', 'Emerus')
	AddTextEntry('0x4F1E8D21', 'Blue High Roller Dress')
	AddTextEntry('0x4F3C6FC6', 'BUY FROM')
	AddTextEntry('0x4F5FA224', 'Black Güffy Waterproof')
	AddTextEntry('0x4F68C6CE', 'Prolaps Golf')
	AddTextEntry('0x4F613B4F', 'Black P Wide Pants')
	AddTextEntry('0x4F9945BD', 'Red The Diamond Cap')
	AddTextEntry('0x4F326515', 'Lilac Blagueurs Parka')
	AddTextEntry('0x4FFE6B07', 'GT Spoiler')
	AddTextEntry('0x5A032DA0', 'Sebastian Dix Jersey')
	AddTextEntry('0x5A1C8C99', 'Lifted Piped Step')
	AddTextEntry('0x5A2B5E15', 'Carbon Hood')
	AddTextEntry('0x5A8E6979', 'Secondary Painted V8')
	AddTextEntry('0x5A599DA2', 'Meinmacht')
	AddTextEntry('0x5A771D80', 'Woodland Camo Waterproof')
	AddTextEntry('0x5A2525F3', 'Tartan High Roller Waistcoat')
	AddTextEntry('0x5AA07C72', 'Orange Loose Bow Tie')
	AddTextEntry('0x5AA2AB2A', 'Side Exit Exhausts')
	AddTextEntry('0x5AA85CC9', 'Rimm Paint')
	AddTextEntry('0x5ABB7EAE', 'Carbon Bumper')
	AddTextEntry('0x5AC739CB', 'Green Urban Deep Shades')
	AddTextEntry('0x5AEE3D5A', 'Carbon Body Kit')
	AddTextEntry('0x5AF20CBB', 'Primary Rear Bumper')
	AddTextEntry('0x5B1DBA1E', 'Wheel of Suits')
	AddTextEntry('0x5B3DFB95', 'Primary Stock')
	AddTextEntry('0x5B6DE5E0', 'Team Tracey Tee')
	AddTextEntry('0x5B61A3FB', 'Tartan High Roller Jacket')
	AddTextEntry('0x5BBC4043', 'Roulette Crowex Époque')
	AddTextEntry('0x5BC6DB1C', 'Primary Race Skirt')
	AddTextEntry('0x5BE5DB17', 'Secondary Intake w/ Vents')
	AddTextEntry('0x5BFEDB49', 'Streamline II')
	AddTextEntry('0x5C0CB96C', 'This is for the kind of player who only needs to make one bet: all-in.')
	AddTextEntry('0x5C3C01AF', 'Carbon Race Bumper')
	AddTextEntry('0x5C41E3DC', 'Houndstooth Deep Shades')
	AddTextEntry('0x5C68A813', 'Blue I\'ve Been Shamed Tee')
	AddTextEntry('0x5C68FEF6', 'White Color Bomber')
	AddTextEntry('0x5C3910CF', 'Tuner Exhaust')
	AddTextEntry('0x5C4697EC', 'Carbon Lip')
	AddTextEntry('0x5C6452F8', 'Twin Rear Vents')
	AddTextEntry('0x5C75341F', 'Val De Grace')
	AddTextEntry('0x5CABC9F9', 'Dual Exhausts')
	AddTextEntry('0x5CB6C3B1', 'SC Broker Logo Hoodie')
	AddTextEntry('0x5CB9DF16', 'White Dice Earrings')
	AddTextEntry('0x5CC30837', 'Carbon Ducktail')
	AddTextEntry('0x5CEF59DF', 'Primary Roof Scoop')
	AddTextEntry('0x5CF13C3E', 'Queen of Clubs')
	AddTextEntry('0x5CFE4867', 'Rear Carbon Lip')
	AddTextEntry('0x5D1BB92D', 'Flames')
	AddTextEntry('0x5DBAD7FE', 'Teal Perseus Wide Pants')
	AddTextEntry('0x5DF10580', 'Yellow FB Manor Slipper Loafers')
	AddTextEntry('0x5E2DD995', 'Spades Earrings')
	AddTextEntry('0x5E6F4BE0', 'Black Ceaseless')
	AddTextEntry('0x5E11C05E', 'Road Kill')
	AddTextEntry('0x5E867DA8', 'Pink Chips Earrings')
	AddTextEntry('0x5E7070DD', 'Sports Wing')
	AddTextEntry('0x5E96771D', 'Blade')
	AddTextEntry('0x5EB239EB', 'Dummy label.')
	AddTextEntry('0x5ED14EF7', 'Long Vent w/ Exit')
	AddTextEntry('0x5EDD8E98', 'Gold Roulette Kronos Tempo')
	AddTextEntry('0x5EFF6F60', 'Vented Arches')
	AddTextEntry('0x5F0D7A92', 'There is a new word in pioneering automotive design: intuition. Taking your seat in an Emerus is not like getting into a car. It\'s like discovering a new and perfectly natural extension to your own body, which just happens to be made of 800 angry horses. So, when it tears you mercilessly limb from limb, you\'ll have no one but yourself to blame.')
	AddTextEntry('0x5F73F15D', 'Woodland Yeti Cap')
	AddTextEntry('0x5F79EA3C', 'Blue Fame or Shame Shades')
	AddTextEntry('0x5F9818A9', 'Green FB Puffer')
	AddTextEntry('0x5FC51358', 'Street Crimes Yokels Tee')
	AddTextEntry('0x5FCCC224', 'Photo Finish')
	AddTextEntry('0x5FD694DF', 'Primary Performance Grilles')
	AddTextEntry('0x5FF13976', 'Silver Kronos Quad')
	AddTextEntry('0x6A0E0E24', 'OPTIONAL EXTRAS')
	AddTextEntry('0x6A9E8535', 'Mauve Fade Retro Sneakers')
	AddTextEntry('0x6AAF14AB', 'Invade and Persuade Jets Tee')
	AddTextEntry('0x6ACAA995', 'Secondary Exhausts')
	AddTextEntry('0x6ADF3E0B', 'Green Flying Bravo Cap')
	AddTextEntry('0x6B04FFC8', 'Stripped Primary Hood')
	AddTextEntry('0x6B1BEB38', 'Primary Painted Stock')
	AddTextEntry('0x6B2DC5AD', 'The Diamond Classic Tee')
	AddTextEntry('0x6B9BB927', 'ULTRAMODERN ARCADE CABINET')
	AddTextEntry('0x6B12A40F', 'PLACE BET')
	AddTextEntry('0x6BA264FF', 'Ace of Clubs')
	AddTextEntry('0x6BC87F34', 'Teal Camo SN Sweater')
	AddTextEntry('0x6BDC66BA', 'Silver Ceaseless')
	AddTextEntry('0x6BF8352F', 'Black Kronos Tempo')
	AddTextEntry('0x6BF88331', 'Blue High Roller Waistcoat')
	AddTextEntry('0x6CAC2A35', 'Baroque Kronos Tempo')
	AddTextEntry('0x6CB90FA3', 'Spade Ceaseless')
	AddTextEntry('0x6CC03CD4', 'Rimm Paint Color Range')
	AddTextEntry('0x6CCAFFCC', 'Blue Floral High Roller Pants')
	AddTextEntry('0x6CE3FE19', 'Black Chips Large Shirt')
	AddTextEntry('0x6D023667', 'Primary Crossed Grille')
	AddTextEntry('0x6D06B1D9', 'Titanium Split Boxed Exhaust')
	AddTextEntry('0x6D22EB9A', 'Deep Vent w/ Exit')
	AddTextEntry('0x6D75AC68', 'Blue Pocket Jacket')
	AddTextEntry('0x6D786F83', 'This is more than just a finishing touch. It\'s the signature you leave on the greatest work of art you will ever produce.')
	AddTextEntry('0x6D22889D', 'Secondary Color Mudguards')
	AddTextEntry('0x6D94656C', 'Broker Ornate Hoodie')
	AddTextEntry('0x6D549489', 'Primary Cage')
	AddTextEntry('0x6DA504A4', 'Black Pocket Jacket')
	AddTextEntry('0x6DAB7EA2', 'Streamline')
	AddTextEntry('0x6DB3C2BB', 'Lucky Seven Mask')
	AddTextEntry('0x6DB9D158', 'Titanium Tipped Exhausts')
	AddTextEntry('0x6DC51FDD', 'BEGIN')
	AddTextEntry('0x6DCC73B0', 'PURCHASE PENDING')
	AddTextEntry('0x6E2D7FE5', 'Carbon Sports Skirt')
	AddTextEntry('0x6E4BA5CE', 'Carbon GT Bumper')
	AddTextEntry('0x6E6DB44C', 'MAIN EVENT')
	AddTextEntry('0x6E8DA4F7', 'Issi Sport')
	AddTextEntry('0x6E407FCC', 'Lower Intake Plastic w/ Vents')
	AddTextEntry('0x6E9577FD', 'Rally Spec Hood')
	AddTextEntry('0x6E191314', 'Tuner Hood')
	AddTextEntry('0x6EC95C88', 'Flares')
	AddTextEntry('0x6ED14CE4', 'You\'re So Original! Tee')
	AddTextEntry('0x6EDA19CB', 'HOW TO FIND US')
	AddTextEntry('0x6F039A67', 'Zion Classic')
	AddTextEntry('0x6F71689E', 'COLOR')
	AddTextEntry('0x6F950875', 'INTRICATE')
	AddTextEntry('0x6FB3D630', 'Teal Color Bomber')
	AddTextEntry('0x6FECC86D', 'Blue Floral Cocktail Dress')
	AddTextEntry('0x7A4E7DDE', 'Titanium Exhaust')
	AddTextEntry('0x7A4F884D', 'Yellow Floral High Roller Jacket')
	AddTextEntry('0x7A95AB5C', 'Black Ceaseless')
	AddTextEntry('0x7A515CAC', 'Yellow FB Puffer')
	AddTextEntry('0x7A84902E', 'Prim. Street Wing W/ Trunk Lip')
	AddTextEntry('0x7AAED235', 'White Stripe')
	AddTextEntry('0x7AB1BD84', 'Black SC Silk Robe')
	AddTextEntry('0x7AD30C1A', 'Street Cage')
	AddTextEntry('0x7AEA29D4', 'Race Wing')
	AddTextEntry('0x7AEE7C92', 'Horse racing is the sport of kings, and Inside Track is the only way to experience it - the drama, the majesty, the excitement, the perfectly simulated aroma of freshly cut turf and hot manure - all without leaving the comfort of a bespoke, air-conditioned suite.')
	AddTextEntry('0x7B1CCBE8', 'Secondary Big Wing')
	AddTextEntry('0x7B2BFF6F', 'Black Eagle Camo')
	AddTextEntry('0x7B5B6964', 'Carbon Piped Grille')
	AddTextEntry('0x7B6C85FE', 'Fender Chrome Square Mirrors')
	AddTextEntry('0x7B85ECF0', 'Anodized Exhausts')
	AddTextEntry('0x7B255EA3', 'White Broker Cap')
	AddTextEntry('0x7B49141D', 'Primary Big Wing')
	AddTextEntry('0x7BAE84A7', 'Invade and Persuade Boxart Tee')
	AddTextEntry('0x7BAEAF44', 'PRIVATE DEALER')
	AddTextEntry('0x7BB93F26', 'Pink Vines Parka')
	AddTextEntry('0x7BC048FD', 'Navy Pocket Jacket')
	AddTextEntry('0x7BCCF140', 'Diffuser')
	AddTextEntry('0x7BCF4F49', 'Orange Camo Blagueurs Parka')
	AddTextEntry('0x7BF1A13D', 'Ash Pocket Jacket')
	AddTextEntry('0x7BF69289', 'Race Wing')
	AddTextEntry('0x7C6BBEFF', 'Black Broker Ornate Bomber')
	AddTextEntry('0x7C11E1DE', 'STARTS WHEN BET IS PLACED')
	AddTextEntry('0x7C57CC7D', 'Claim What\'s Yours Tee')
	AddTextEntry('0x7C197A2C', 'Vented Hood w/ Vents')
	AddTextEntry('0x7C590263', 'Carbon Top Spoiler')
	AddTextEntry('0x7CBD0033', 'Painted Roof Scoop')
	AddTextEntry('0x7CCB16F3', 'THIS LABEL NEEDS TO BE HERE !!!')
	AddTextEntry('0x7CDC83D6', 'ProLaps')
	AddTextEntry('0x7D0597C9', 'Carbon Arches')
	AddTextEntry('0x7D5D978C', 'Yellow Sci-Fi Wide Pants')
	AddTextEntry('0x7D5DCCF7', 'Primary Trim')
	AddTextEntry('0x7D7B661E', 'Blue The Diamond Resort LS Tee')
	AddTextEntry('0x7D438CE0', 'Purchase and modify your own workshop and vehicles to ensure you smash the competition in Arena Wars.')
	AddTextEntry('0x7E3CCB9F', 'Herringbone Aviators')
	AddTextEntry('0x7E3D26A5', 'Primary Full Cage')
	AddTextEntry('0x7E74FD34', 'The Royals')
	AddTextEntry('0x7E585387', 'Secondary Rear Bumper')
	AddTextEntry('0x7EAF834E', 'Black Bigness Bomber')
	AddTextEntry('0x7EB0552C', 'Titanium Large Boxed Exhaust')
	AddTextEntry('0x7EC97605', 'Green Fade SN Parka')
	AddTextEntry('0x7ECD20E5', 'Primary Middle Intake')
	AddTextEntry('0x7ED62DF0', 'America Loves You Tee')
	AddTextEntry('0x7EE3E5F8', 'No, you didn\'t misread anything. This is a Lampadati. And an SUV. At the same time. Why? Who can say. But if someone tells you they crossbred a thoroughbred race horse with a hippo, do you question their motives? No, you buy it, take a selfie with it, throw it in storage, and start bragging to your friends.')
	AddTextEntry('0x7EF5A573', 'Horizon Aviators')
	AddTextEntry('0x7F024CEB', 'Ceramic Headers')
	AddTextEntry('0x7F469E95', 'Primary Race Roof Scoop')
	AddTextEntry('0x7F1218B0', 'Plastic Lip Spoiler')
	AddTextEntry('0x7FBF69CF', 'Purple Painted Large Shirt')
	AddTextEntry('0x7FCCB31E', 'Cherries Mask')
	AddTextEntry('0x7FCEC8D4', 'Primary Race Bumper')
	AddTextEntry('0x7FD88029', 'White P Wide Pants')
	AddTextEntry('0x7FE3BBDE', 'THE TABLE GAMES')
	AddTextEntry('0x7FEDED35', 'Primary Color Skirts')
	AddTextEntry('0x7FFB70A4', 'Oh No He Didn\'t! Tee')
	AddTextEntry('0x8A0A7BF4', 'Dual Titanium Tipped Exhausts')
	AddTextEntry('0x8A3ED094', 'THE PENTHOUSES')
	AddTextEntry('0x8A66C723', 'Red FB Manor Slipper Loafers')
	AddTextEntry('0x8A67B747', 'Radiator')
	AddTextEntry('0x8AC17FF0', 'White FB Manor Jersey')
	AddTextEntry('0x8AC94913', 'Drag Predator')
	AddTextEntry('0x8ADC3119', 'Impotent Rage')
	AddTextEntry('0x8AECB269', 'Blue Perseus Wide Pants')
	AddTextEntry('0x8B0C97CF', 'Banknote Rose')
	AddTextEntry('0x8B0F685A', 'Secondary Trim')
	AddTextEntry('0x8B8C9B53', 'Rusty Shark')
	AddTextEntry('0x8B9BC7A0', 'Two Tone Deep Shades')
	AddTextEntry('0x8B9D0B99', 'Cyan Bigness Waterproof')
	AddTextEntry('0x8B48E80E', 'Latte Pocket Jacket')
	AddTextEntry('0x8B64AAF0', 'Racing Splitter')
	AddTextEntry('0x8B68C699', 'Red Retro Sneakers')
	AddTextEntry('0x8B89C527', 'Fame or Shame Logo Tee')
	AddTextEntry('0x8B165B81', 'Boxed Exhausts')
	AddTextEntry('0x8B264DCD', 'Black Bigness Bomber')
	AddTextEntry('0x8B27058F', 'I\'ve Been Shamed Tee')
	AddTextEntry('0x8B513373', 'Blue Sci-Fi Wide Pants')
	AddTextEntry('0x8BA1A5B1', 'Rear Carbon Canards')
	AddTextEntry('0x8BA6E673', 'Gold Tint Aviators')
	AddTextEntry('0x8BE55132', 'WE ARE SORRY')
	AddTextEntry('0x8BF1BE15', 'Knit High Roller Pants')
	AddTextEntry('0x8BFFDC80', 'Blue Prairie Large Shirt')
	AddTextEntry('0x8C3C90EB', 'Peach Fade SN Parka')
	AddTextEntry('0x8C4CEFED', 'Vinyl Roof Setup')
	AddTextEntry('0x8C64D0B0', 'SPA')
	AddTextEntry('0x8C629CEC', 'Secondary Mirror')
	AddTextEntry('0x8C8832CC', 'Sleek Vented')
	AddTextEntry('0x8CD334C7', 'Prim. Race Wing W/ Trunk Lip')
	AddTextEntry('0x8D095953', 'White Street Crimes Icons Tee')
	AddTextEntry('0x8D2B0481', 'Secondary Stock Spoiler')
	AddTextEntry('0x8D9A4680', 'White Fame or Shame Shades')
	AddTextEntry('0x8D41F15A', 'Carbon Rear Bumper')
	AddTextEntry('0x8D460EC4', 'White High Roller Shirt')
	AddTextEntry('0x8D539D76', 'Primary Roof')
	AddTextEntry('0x8D976EFC', 'Street Crimes Punks Tee')
	AddTextEntry('0x8D8489EC', 'Black High Roller Dress')
	AddTextEntry('0x8D73880E', 'Gray Blagueurs Waves Sweater')
	AddTextEntry('0x8D917054', 'Secondary Sectioned Grilles')
	AddTextEntry('0x8DAB1F84', 'Mission IV Tee')
	AddTextEntry('0x8DC505DD', 'Primary Sports Spoiler')
	AddTextEntry('0x8DE52CE3', 'Carbon Shark Grille')
	AddTextEntry('0x8E02C35F', 'Primary Diffuser')
	AddTextEntry('0x8E1A9B80', 'Mini Roof Rack')
	AddTextEntry('0x8E3E0D67', 'Silver Fifty Kronos Pulse')
	AddTextEntry('0x8E564BE1', 'White Fame or Shame Shades')
	AddTextEntry('0x8E365330', 'Black Perseus Fitted')
	AddTextEntry('0x8EE83824', 'Black Roll Bars')
	AddTextEntry('0x8F1E0645', 'Turquoise Güffy Spray Puffer')
	AddTextEntry('0x8F96F2E6', 'Carbon Drift Skirts')
	AddTextEntry('0x8F2033CD', 'Primary Lifted Ram Bar')
	AddTextEntry('0x8F6550CD', 'Red SC Broker Silk Robe')
	AddTextEntry('0x8F789901', 'Purple Broker Ornate Bomber')
	AddTextEntry('0x9A1EFA65', 'Purple SC Broker Bomber')
	AddTextEntry('0x9A34F02E', 'Primary Flared Fenders')
	AddTextEntry('0x9A44A5C7', 'Green Visor')
	AddTextEntry('0x9A46E690', 'Black SC Silk Robe')
	AddTextEntry('0x9A67D806', 'Single Vent Plastic')
	AddTextEntry('0x9A791D55', 'Primary Window Plates')
	AddTextEntry('0x9A4983B8', 'Horizon Aviators')
	AddTextEntry('0x9A352770', 'PATTERNS')
	AddTextEntry('0x9AA6FDD7', 'Secondary Open Grille')
	AddTextEntry('0x9AA79913', 'Black SASS Wrist Piece')
	AddTextEntry('0x9ACD39E1', 'Carbon Mirror')
	AddTextEntry('0x9ADB9BA1', 'CURRENT BALANCE')
	AddTextEntry('0x9AE24F84', 'Painted Drift Intake')
	AddTextEntry('0x9AF5A1DE', 'Yellow Paint Cocktail Dress')
	AddTextEntry('0x9B097229', 'PARKING')
	AddTextEntry('0x9B9F9FD2', 'Black Tiled Cocktail Dress')
	AddTextEntry('0x9B43A0B2', 'Black Stock Spoiler')
	AddTextEntry('0x9B67D009', 'Your private Spa comes with a round-the-clock personal stylist and a hot tub infused with extract of jojoba and a dissociative anesthetic.')
	AddTextEntry('0x9B8054BF', 'Split Grille')
	AddTextEntry('0x9B48325A', 'Carbon Race Skirt')
	AddTextEntry('0x9B916653', 'Zebra Deep Shades')
	AddTextEntry('0x9BA875B8', 'Bullet Rear')
	AddTextEntry('0x9BC0A4DA', 'Carbon Skirts')
	AddTextEntry('0x9BE0A052', 'Magenta Bigness Waterproof')
	AddTextEntry('0x9C4FA98A', 'Silver Roulette Kronos Pulse')
	AddTextEntry('0x9C8FD3AB', 'Stock Car Spoiler')
	AddTextEntry('0x9C22151B', 'Jackal Racing')
	AddTextEntry('0x9C528058', 'Tan Le Chien Parka')
	AddTextEntry('0x9CB823ED', 'SET WAYPOINT')
	AddTextEntry('0x9CBD12C5', 'PREVIOUS')
	AddTextEntry('0x9CC1CAB6', 'Primary Mirrors')
	AddTextEntry('0x9D6E7E4D', 'White Broker Cap')
	AddTextEntry('0x9D8E90F5', 'White SC Broker Cap')
	AddTextEntry('0x9D8F22FD', 'Dual Exhausts')
	AddTextEntry('0x9D64B4D9', 'Black Broker Ornate Bomber')
	AddTextEntry('0x9DBA8682', 'Black Street Spoiler')
	AddTextEntry('0x9DBDEB43', 'Two Tone Retro Sneakers')
	AddTextEntry('0x9DC0E301', 'RON')
	AddTextEntry('0x9DE16DEF', 'Excelsior')
	AddTextEntry('0x9E00EF8E', 'Junkyard Special')
	AddTextEntry('0x9E2CFDA7', 'Blue Pulga Sweater')
	AddTextEntry('0x9E2F1DB1', 'Suits Crowex Époque')
	AddTextEntry('0x9E3A67B4', 'Mono High Roller Waistcoat')
	AddTextEntry('0x9E6B6430', 'Secondary Diffuser')
	AddTextEntry('0x9E9ED795', 'Plastic Flatbed Sport Bar')
	AddTextEntry('0x9E46A638', 'Annis Grille')
	AddTextEntry('0x9E67D15A', 'Back in the 50\'s, drag racing was a more straightforward affair. You took a beautiful post-war convertible, gave it a serious engine upgrade and a nosebleed stance, and took it onto the streets. Sure, the weight transfer didn\'t count for much when the front end picked up more air resistance than an open parachute, and the survival rate over 150mph was pretty low. But that\'s the price you pay for historical accuracy.')
	AddTextEntry('0x9E68E215', 'Truffade Logo')
	AddTextEntry('0x9E191F16', 'Drag Spoiler')
	AddTextEntry('0x9E562D8F', 'Green Fame or Shame Kronos')
	AddTextEntry('0x9E623C0F', 'Large Roof Rack')
	AddTextEntry('0x9E665FA3', 'Broker Knee Shorts')
	AddTextEntry('0x9E682C57', 'Green Joker')
	AddTextEntry('0x9E70533C', 'BETTING')
	AddTextEntry('0x9ECC0174', 'White SC Broker Cap')
	AddTextEntry('0x9ECCF45D', 'Teal Perseus Fitted')
	AddTextEntry('0x9EE48454', 'Twin Intake Hood')
	AddTextEntry('0x9F085935', 'Carb. Street Wing W/ Trunk Lip')
	AddTextEntry('0x9F2D7641', 'GARAGE')
	AddTextEntry('0x9F5F3FAA', 'Big Bore Exhaust')
	AddTextEntry('0x9F6ED5A2', 'Neo')
	AddTextEntry('0x9F97A3FA', 'Rimmers')
	AddTextEntry('0x9F372D51', 'Gold High Roller Dress')
	AddTextEntry('0x9F724BC2', 'Premier Electronics')
	AddTextEntry('0x9F21327A', 'Classic High Roller Shirt')
	AddTextEntry('0x9F62373A', 'White SC Broker Parka')
	AddTextEntry('0x9FA7FBC4', 'Roll Cage')
	AddTextEntry('0x9FAA0095', 'SN Lazerforce Sweater')
	AddTextEntry('0x9FAE1488', 'Redwood Stockcar')
	AddTextEntry('0x9FD543EA', 'Aqua Deep Shades')
	AddTextEntry('0x9FDD0EA0', 'Custom Side Pipes')
	AddTextEntry('0x9FE02CE7', 'Squash Comic Sweater')
	AddTextEntry('0x10A9A346', 'Carbon Hood')
	AddTextEntry('0x10A171B4', 'HOME')
	AddTextEntry('0x10B2506A', 'Fame or Shame Stars Tee')
	AddTextEntry('0x10E7223A', 'Silver Kronos Ära')
	AddTextEntry('0x10E51374', 'Camo High Roller Waistcoat')
	AddTextEntry('0x10EA9F46', 'Plastic Splitter')
	AddTextEntry('0x11A5D38D', 'Fame or Shame No Evil Tee')
	AddTextEntry('0x11AEEFD0', 'White Fame or Shame Robe')
	AddTextEntry('0x11B4A33E', 'White SC Broker Wide Pants')
	AddTextEntry('0x11C18DF2', 'White Bigness Logo Jersey')
	AddTextEntry('0x11F7E854', 'Sports Spoiler')
	AddTextEntry('0x11F12E23', 'Blagueurs Gray Box Hoodie')
	AddTextEntry('0x11FCF0E2', 'Secondary Competition Kit')
	AddTextEntry('0x12A92B92', 'Primary Bumper & Rally Fogs')
	AddTextEntry('0x12ACDB7D', 'Bull Bar')
	AddTextEntry('0x12C0406A', 'Enus Racing')
	AddTextEntry('0x12E92EA2', 'Gold Crowex Époque')
	AddTextEntry('0x12F10E79', 'Neon Waterproof')
	AddTextEntry('0x12FD0E05', 'Maroon Broker Puffer')
	AddTextEntry('0x14A4BCF9', 'Patterned High Roller Jacket')
	AddTextEntry('0x14AD5B39', 'Jakey\'s Lager')
	AddTextEntry('0x14D7452A', 'Red Cards High Roller Jacket')
	AddTextEntry('0x14EE1EA1', 'Black Kronos Ära')
	AddTextEntry('0x15AD02AB', 'Primary Roof Setup')
	AddTextEntry('0x15BBB4B0', 'Blagueurs Camo Box Hoodie')
	AddTextEntry('0x15BC08A7', 'Street Crimes Color Gangs Tee')
	AddTextEntry('0x15C0609E', 'Purple Painted Knee Shorts')
	AddTextEntry('0x15D65016', 'Ace of Hearts')
	AddTextEntry('0x15E465BA', 'Power Ram')
	AddTextEntry('0x16B43634', 'Suits Crowex Époque')
	AddTextEntry('0x16BF53B6', 'Black Floral High Roller Pants')
	AddTextEntry('0x16C47898', 'Black GT Spoiler')
	AddTextEntry('0x16DDBE8D', 'Stickerbomb Fenders')
	AddTextEntry('0x17A7831E', 'Silver SASS Wrist Piece')
	AddTextEntry('0x17BC298E', 'Red Floral Bomber')
	AddTextEntry('0x17C41C72', 'Shark Nose')
	AddTextEntry('0x17C71E6F', 'Black Floral High Roller Dress')
	AddTextEntry('0x17EFDEEA', 'Black Chips Large Shirt')
	AddTextEntry('0x17F0D01B', 'Secondary Race Skirt')
	AddTextEntry('0x18AE57FC', 'White The Diamond Cap')
	AddTextEntry('0x18B1DA81', 'Cards High Roller Dress')
	AddTextEntry('0x18BA8316', 'Power Bulge Hood')
	AddTextEntry('0x18D79D7C', 'White SN Paint Cocktail Dress')
	AddTextEntry('0x18D686E4', 'Secondary Performance Grilles')
	AddTextEntry('0x18D77838', 'Carbon Bulkhead Hood')
	AddTextEntry('0x18F0B557', 'Carbon Roof Box')
	AddTextEntry('0x18F8641F', 'White Stripe')
	AddTextEntry('0x18FF20DF', 'Geo High Roller Dress')
	AddTextEntry('0x19AC24A5', 'Aluminum Infinity Exhaust')
	AddTextEntry('0x19B9A49D', 'Black Roll Bar Bumper')
	AddTextEntry('0x19C9E8B1', 'Racer MK I')
	AddTextEntry('0x19CD74DD', 'Grayscale Retro Sneakers')
	AddTextEntry('0x19CF6DC1', 'Pink Vinewood Fitted')
	AddTextEntry('0x19D13257', 'Orange Patterned Wide Pants')
	AddTextEntry('0x19D95683', 'Blue Baroque Knee Shorts')
	AddTextEntry('0x20AB6615', 'Junk Trunk')
	AddTextEntry('0x20E01A3F', 'Drift Wing')
	AddTextEntry('0x20EDB385', 'Sand High Roller Waistcoat')
	AddTextEntry('0x20F82D15', 'Red The Diamond LS Tee')
	AddTextEntry('0x20FB31F5', 'Camo Livery')
	AddTextEntry('0x21A92C46', 'Xero Gas')
	AddTextEntry('0x21B85FFE', 'Purple Lazerforce Wide Pants')
	AddTextEntry('0x21EDEB61', 'Dot Fade Aviators')
	AddTextEntry('0x21EE4456', 'Red Broker Wide Pants')
	AddTextEntry('0x22BBBA3C', 'Gold Fifty Kronos Ära')
	AddTextEntry('0x22F2EE82', 'Faux-Rust')
	AddTextEntry('0x22F7BF4F', 'Impotent Rage Eye Mask')
	AddTextEntry('0x23AD3440', 'Carbon Intake Scoop')
	AddTextEntry('0x23B18154', 'TBar')
	AddTextEntry('0x23F347BB', 'Black Broker Wide Pants')
	AddTextEntry('0x23FF0ECB', 'Tuner Exhaust')
	AddTextEntry('0x24A7C99B', 'Gambling Royalty')
	AddTextEntry('0x24C1AA86', 'EVENT STARTS IN')
	AddTextEntry('0x24E63E29', 'Orange Camo Waterproof')
	AddTextEntry('0x24F7B936', 'Blue America Loves You Tee')
	AddTextEntry('0x25AA894D', 'Secondary Racing Bars')
	AddTextEntry('0x25B1336D', 'Black Broker Puffer')
	AddTextEntry('0x25FB2BC2', 'Black The Diamond Resort Tee')
	AddTextEntry('0x26B88E0D', 'Black Chips Earrings')
	AddTextEntry('0x26B36850', 'Abstract Flag')
	AddTextEntry('0x26C009F6', 'Mk3 Racing Cage')
	AddTextEntry('0x26E3A18A', 'Street Crimes Action Tee')
	AddTextEntry('0x26EAE2DE', 'Primary Low Level Spoiler')
	AddTextEntry('0x26EC7D0F', 'Houndstooth Deep Shades')
	AddTextEntry('0x27AD20FB', 'Vented Hood')
	AddTextEntry('0x27CF63F4', 'GT Carbon Bumper')
	AddTextEntry('0x28A1F2FD', 'Secondary Hood')
	AddTextEntry('0x28A5F7D7', 'White The Diamond Cap')
	AddTextEntry('0x28A9A4FC', 'Blue Fame or Shame Kronos')
	AddTextEntry('0x28CB64E6', 'Atomic Sponsor')
	AddTextEntry('0x28EAB80F', '8F Drafter')
	AddTextEntry('0x28FC7B16', 'Craps High Roller Dress')
	AddTextEntry('0x29EA27A3', 'Gold SASS Wrist Piece')
	AddTextEntry('0x29F2D506', 'Light Bar')
	AddTextEntry('0x30D8CAA5', 'Sprunk')
	AddTextEntry('0x30D7375E', 'Carbon Lip Spoiler')
	AddTextEntry('0x30DC9BDB', 'Blue Opulent Fitted')
	AddTextEntry('0x30DE6AC2', 'TOTAL')
	AddTextEntry('0x30E5843C', 'The King')
	AddTextEntry('0x30F17101', 'Gold Ceaseless')
	AddTextEntry('0x31AC00D4', 'Primary Street Spoiler')
	AddTextEntry('0x31BD1A3B', 'Blue Perseus Fitted')
	AddTextEntry('0x31D31CB0', 'This is not accommodation. This is a symphony of aesthetic bliss and relentless indulgence, and you are the composer, the conductor and the audience. Take it away, maestro.')
	AddTextEntry('0x31D59B93', 'MASTER PENTHOUSE')
	AddTextEntry('0x31D63D2A', 'Leopard Güffy Spray Puffer')
	AddTextEntry('0x31D7716A', 'Ace of Hearts')
	AddTextEntry('0x31E89624', 'Green FB Slipper Loafers')
	AddTextEntry('0x32CC6918', 'SHARP')
	AddTextEntry('0x32F9800B', 'Rear Vents')
	AddTextEntry('0x33B97835', 'Secondary Color Hood')
	AddTextEntry('0x33BD692E', 'Cash is King')
	AddTextEntry('0x33D277F1', 'Queen of Hearts')
	AddTextEntry('0x33D2890E', 'Angled Ram Pipes / No Hood')
	AddTextEntry('0x33F7C7C3', 'Black The Diamond Resort LS Tee')
	AddTextEntry('0x34C13BBB', 'Carbon Trim')
	AddTextEntry('0x35F027F8', 'LUCKY WHEEL')
	AddTextEntry('0x36A167E0', 'Rampant Rocket')
	AddTextEntry('0x36C4CD55', 'Red The Diamond Resort Tee')
	AddTextEntry('0x36C81372', 'Secondary Bull Bar III')
	AddTextEntry('0x37AF264D', 'Carbon Performance Hood')
	AddTextEntry('0x37BC71D5', 'Queen of Hearts')
	AddTextEntry('0x37E9D978', 'Chrome Slatted Grille')
	AddTextEntry('0x37ED2DD2', 'Primary Racing Bars')
	AddTextEntry('0x37F29766', 'Electric Blue Tint Aviators')
	AddTextEntry('0x38A83C5B', 'Secondary GT Spoiler')
	AddTextEntry('0x38A316E9', 'Tan Dice Earrings')
	AddTextEntry('0x38E3E272', 'No Talent Required Tee')
	AddTextEntry('0x38FD312B', 'Secondary Color Sunstrip')
	AddTextEntry('0x39C1B805', 'Salmon Prairie Large Shirt')
	AddTextEntry('0x39F3BC34', 'Big Ol\' Wiener')
	AddTextEntry('0x40AC78B0', 'Hotshot')
	AddTextEntry('0x41B1AB48', 'Aqua Fade High Roller Dress')
	AddTextEntry('0x41B99451', 'Carbon Hood')
	AddTextEntry('0x41BC022C', 'Gray Blagueurs Wide Pants')
	AddTextEntry('0x41C1B587', 'Black Fame or Shame Robe')
	AddTextEntry('0x42A7EDF1', 'Drift Skirts')
	AddTextEntry('0x42A36D94', 'Purple SC Broker Cap')
	AddTextEntry('0x42A46FB7', 'Black Bigness Jersey')
	AddTextEntry('0x42D85973', 'Street Crimes Hoods Tee')
	AddTextEntry('0x42E5DD77', 'Green Blagueurs Parka')
	AddTextEntry('0x42E594F1', 'Painted Square Mirrors')
	AddTextEntry('0x43A5185B', 'Black Painted Knee Shorts')
	AddTextEntry('0x43B17287', 'Black The Diamond LS Tee')
	AddTextEntry('0x43D1B10A', 'Blue Pocket Jacket')
	AddTextEntry('0x43EABE96', 'Blue P Fitted')
	AddTextEntry('0x43ECC18F', 'Primary Street Spoiler')
	AddTextEntry('0x43FEDDE0', 'PLAY WITH YOURSELF')
	AddTextEntry('0x44AEC145', 'LOUNGE AREA')
	AddTextEntry('0x44C51AE0', 'DESIGN YOUR OWN')
	AddTextEntry('0x44DA60E6', 'Teal SC Broker Cap')
	AddTextEntry('0x44DB03CB', 'Teal Broker Ornate Bomber')
	AddTextEntry('0x44E8B13E', 'Flow Racing')
	AddTextEntry('0x45C41178', 'Red Broker Coin Bomber')
	AddTextEntry('0x45E68440', 'Blue SN Parka')
	AddTextEntry('0x45F59CEE', 'Purple Baroque Cocktail Dress')
	AddTextEntry('0x46A0B1F3', 'Weekend Vacation')
	AddTextEntry('0x46B51199', 'Invade and Persuade Tour Tee')
	AddTextEntry('0x46C3F118', 'Vapid Cutout Large Grated Grille')
	AddTextEntry('0x46C92452', 'Dual Light Covers')
	AddTextEntry('0x46DF0A8E', 'LOST')
	AddTextEntry('0x46FC6B0F', 'Invade and Persuade Enemies Tee')
	AddTextEntry('0x46FE3E3D', 'The Diamond Vintage Tee')
	AddTextEntry('0x47A61602', 'The only regret you\'ll ever have at The Diamond Casino & Resort is the moment you leave. But why accept even that imperfection? With one of our state of the art, fully customizable, seven-star Penthouses, you can finally say goodbye to the outside world for good.')
	AddTextEntry('0x47C4936C', 'Royal Flush')
	AddTextEntry('0x47CC924B', 'Black Güffy Waterproof')
	AddTextEntry('0x47CFFF24', 'Red Joker')
	AddTextEntry('0x47D8B510', 'You arrived in your driverless car, you\'re wearing next year\'s line from Didier Sachs, but the only thing on your mind is beating your high score.')
	AddTextEntry('0x48A5AD7E', 'Jack of Diamonds')
	AddTextEntry('0x48CD9919', 'Secondary Body Kit')
	AddTextEntry('0x48E7D6E9', 'Bolted Stock')
	AddTextEntry('0x49A043C6', 'Red Flying Bravo Cap')
	AddTextEntry('0x49B367B9', 'Carbon Triple Intake Kit')
	AddTextEntry('0x49BED2AE', 'Primary Color Sunstrip')
	AddTextEntry('0x49E54AB9', 'Street Hood')
	AddTextEntry('0x50A5FD16', 'Forget unitary construction. Put your monocoque back in your pants. The rolling chassis is back, and it\'s making sweet, naphtha-kerosene-drenched love to the hottest body in the world. Don\'t worry if you don\'t understand any of that, just take the corners hard and you feel the future. Trust us.')
	AddTextEntry('0x50D3D3FA', 'Red FB Slipper Loafers')
	AddTextEntry('0x50D7D0E1', 'Striped Deep Shades')
	AddTextEntry('0x51A7B9E5', 'Secondary Bull Bar II')
	AddTextEntry('0x51B78219', 'REEXPERIENCE ADOLESCENCE')
	AddTextEntry('0x51BBF29A', 'Magenta Tint Aviators')
	AddTextEntry('0x52A1EE21', 'Dual Side Exhausts')
	AddTextEntry('0x52A5D510', 'Brown Retro Sneakers')
	AddTextEntry('0x52A3968B', 'Chrome Quadrant Exhaust')
	AddTextEntry('0x52B3862F', 'Roll Cage')
	AddTextEntry('0x53AE6CFD', 'SUMMARY')
	AddTextEntry('0x53F959D9', 'Painted Roof Strip')
	AddTextEntry('0x54A0F4F1', 'Nightmare')
	AddTextEntry('0x54B1DB85', 'Escalera')
	AddTextEntry('0x54C8ADCC', 'Hawaiian Snow Rally')
	AddTextEntry('0x54C3633C', 'Carbon Street Spoiler')
	AddTextEntry('0x55A2F438', 'Black Grille')
	AddTextEntry('0x55B43F1F', 'Weave High Roller Jacket')
	AddTextEntry('0x55C6DD91', 'White The Diamond Silk Robe')
	AddTextEntry('0x55F18E80', 'Street Spoiler')
	AddTextEntry('0x56A9651A', 'Carbon Vented Side Panel')
	AddTextEntry('0x56B8A1D1', 'Contrast Camo Waterproof')
	AddTextEntry('0x56B2758A', 'Red Fame or Shame Robe')
	AddTextEntry('0x56CAD1E7', 'Dice Large Shirt')
	AddTextEntry('0x56D3C579', 'Primary Louvers')
	AddTextEntry('0x56D5BBD1', 'FREE')
	AddTextEntry('0x57CCE5BC', 'Bull Bar II')
	AddTextEntry('0x57F3C13D', 'CRASH PAD')
	AddTextEntry('0x57F86DE8', 'Heavy Duty Bumper')
	AddTextEntry('0x58B4E15E', 'Purple Fade Retro Sneakers')
	AddTextEntry('0x58B7EF5D', 'Lucky Seven Mask')
	AddTextEntry('0x58C40DEB', 'Secondary Crossed Grille')
	AddTextEntry('0x58D1C6A4', 'Tuner')
	AddTextEntry('0x58EACCFB', 'Carbon Wing')
	AddTextEntry('0x58F14A9E', 'Carbon Big Lip Spoiler')
	AddTextEntry('0x58F385E7', 'Primary Exhausts')
	AddTextEntry('0x59A85E1F', 'Lemon Mask')
	AddTextEntry('0x59D8EA72', 'Black P Fitted')
	AddTextEntry('0x59FAE47B', 'Teal Broker Cap')
	AddTextEntry('0x60C77B2C', 'Primary GT Spoiler')
	AddTextEntry('0x60CA32D8', 'Quad Stack Exhaust')
	AddTextEntry('0x61BEBF40', 'Primary Race Skirt')
	AddTextEntry('0x61CEC2E9', 'Extended Roof Rack')
	AddTextEntry('0x61CF1E99', 'Purple Vines Parka')
	AddTextEntry('0x61EB2705', 'Gray Dice Earrings')
	AddTextEntry('0x61F3F609', 'Exsorbed')
	AddTextEntry('0x62A57F6C', 'Blue Flying Bravo Fitted')
	AddTextEntry('0x62C6A8ED', 'LTD')
	AddTextEntry('0x62C8FBC3', 'Roulette Ceaseless')
	AddTextEntry('0x63B72A0B', 'Tuner Spoiler')
	AddTextEntry('0x63BC797C', 'Black The Diamond Silk Robe')
	AddTextEntry('0x63F7CF95', 'Primary Paint')
	AddTextEntry('0x63F6893B', 'Purple Camo SN Sweater')
	AddTextEntry('0x63FEE5BC', 'Secondary Arches')
	AddTextEntry('0x64A6B6A7', 'Secondary Color Skirts')
	AddTextEntry('0x64CD7403', 'Secondary Ridged Skirt')
	AddTextEntry('0x64E234F0', 'White The Diamond LS Tee')
	AddTextEntry('0x64FBF9BC', 'Green Retro Sneakers')
	AddTextEntry('0x66C47FB6', 'Jackal')
	AddTextEntry('0x67AFAA4D', 'Blue Fame or Shame Logo Tee')
	AddTextEntry('0x67B1539F', 'Pink Urban Deep Shades')
	AddTextEntry('0x67D9E953', 'BET AGAIN')
	AddTextEntry('0x67E126CE', 'White Rim Tint Aviators')
	AddTextEntry('0x67F29671', 'Carbon Twin Intake Hood')
	AddTextEntry('0x67FCF59C', 'Gray Dice Earrings')
	AddTextEntry('0x68A40548', 'Endurance Wing')
	AddTextEntry('0x68AE5321', 'SC Broker Leather Fur')
	AddTextEntry('0x68BF0965', 'MEDIA ROOM')
	AddTextEntry('0x68D025D6', 'Colors Yeti Puffer')
	AddTextEntry('0x68D6B180', 'White The Diamond LS Tee')
	AddTextEntry('0x68D9F795', 'Primary Bull Bar III')
	AddTextEntry('0x68E55D23', 'The S80RR was designed to do two things. First, to be the predominant endurance racer of its era. Second, to make so few concessions to the physical comfort and psychological wellbeing of the driver that getting as far as the end of your driveway risks multiple organ failure, an irrecoverable nervous breakdown, and absolutely no regrets whatsoever.')
	AddTextEntry('0x68FF1A1F', 'Red SC Broker Silk Robe')
	AddTextEntry('0x70AB5592', 'Secondary Street Wing')
	AddTextEntry('0x71B6ECFF', 'Ash The Diamond Hoodie')
	AddTextEntry('0x71E28915', 'Carbon Vents')
	AddTextEntry('0x71EF62D4', 'Cross & Hatch')
	AddTextEntry('0x71F2E45E', 'Black P Wide Pants')
	AddTextEntry('0x71F41530', 'SN Pink Compass Tee')
	AddTextEntry('0x71FB3C53', 'Big Bore Exhaust')
	AddTextEntry('0x72A347E3', 'Quadded Aero Spoiler')
	AddTextEntry('0x72DD691F', 'Yellow Waterproof')
	AddTextEntry('0x72FC0982', 'Secondary Sports Skirt')
	AddTextEntry('0x72FDAA7C', 'Yellow Sunset Large Shirt')
	AddTextEntry('0x73AEBC3C', 'In this world, there\'s muscle, and then there\'s muscle. Like, you technically have muscles. And then there\'s that guy you went to school with. The one who posts Snapmatic selfies that look like someone spray-tanned a T-bone steak. Well, the Bravado Gauntlet just ate that guy, washed him down with a supercharged protein shake, and threw its arm round his mom at the drive-in. This is muscle. Anything else is just flab.')
	AddTextEntry('0x73C9A408', 'Mk2 Racing Cage')
	AddTextEntry('0x73EB6722', 'Taxi')
	AddTextEntry('0x73F67289', 'Big Enough')
	AddTextEntry('0x74AEBD27', 'Black SASS Wrist Piece')
	AddTextEntry('0x74F95443', 'Pink Painted Large Shirt')
	AddTextEntry('0x75BBF5D3', 'Blue SN Bigness Hoodie')
	AddTextEntry('0x75BBF6BB', 'Visors')
	AddTextEntry('0x76FC6A6B', 'Broker Ornate Sweater')
	AddTextEntry('0x77B835B8', 'Blue Floral Large Shirt')
	AddTextEntry('0x77D9122A', 'Classic')
	AddTextEntry('0x77E8F350', 'VIBRANT')
	AddTextEntry('0x78E635A5', 'Woodland Yeti Cap')
	AddTextEntry('0x79A88C8B', 'Why go to a night club, when a night club can come to you? The most exclusive venue in town is the one where you\'re in charge of the guest list. Two exclusive arcade games come as standard, with a choice of two styles.')
	AddTextEntry('0x79C40C3F', 'Big Lip Spoiler')
	AddTextEntry('0x81A88DF1', 'Doing Busy Work')
	AddTextEntry('0x81B9B4D4', 'Stripped Down Trunk')
	AddTextEntry('0x81CD2A24', 'Orange LS Diamond Cap')
	AddTextEntry('0x81D4880F', 'Twin Carbon Exhaust')
	AddTextEntry('0x81E10D2F', 'Carbon Race Splitter')
	AddTextEntry('0x81E39A23', 'MAIN EVENT')
	AddTextEntry('0x81E1577B', 'Secondary Drift Skirts')
	AddTextEntry('0x81F0781C', 'Race Wing')
	AddTextEntry('0x82B31F22', 'Sleek Carbon')
	AddTextEntry('0x83C5810E', 'Fifty Kronos Quad')
	AddTextEntry('0x83E05EBE', 'Black SASS Bracelet')
	AddTextEntry('0x83E8CC38', 'The Works Spoiler')
	AddTextEntry('0x83F2D8B6', 'Gold Kronos Tempo')
	AddTextEntry('0x83F8A3D5', 'Sec. w/ Colored Seats')
	AddTextEntry('0x83FB5C76', 'Purple The Diamond Cap')
	AddTextEntry('0x83FD98F8', 'Triple Intake Bugcatcher')
	AddTextEntry('0x84B1FDFD', 'Titanium Radial Exhausts')
	AddTextEntry('0x84B7F8C1', 'Big Dix Tee')
	AddTextEntry('0x84BED113', 'Racing Numbers')
	AddTextEntry('0x84ED727B', 'Performance Skirts')
	AddTextEntry('0x84F81D3A', 'Impotent Rage')
	AddTextEntry('0x84FDF723', 'Squash Squares Sweater')
	AddTextEntry('0x85CCE7F4', 'Chrome Crossed Grille')
	AddTextEntry('0x85D19A28', 'Gray Blagueurs Wide Pants')
	AddTextEntry('0x86B970FE', 'Primary Racing Skirt')
	AddTextEntry('0x86D58505', 'White 445')
	AddTextEntry('0x87DDCAA0', 'Secondary Bolted Fenders')
	AddTextEntry('0x87E8D46F', 'Pineapple Mask')
	AddTextEntry('0x87FD2ACC', 'Stripped Hood')
	AddTextEntry('0x88A4BC89', 'Opulent High Roller Waistcoat')
	AddTextEntry('0x88ABC66F', 'Adorned Knee Shorts')
	AddTextEntry('0x88C185BF', 'Highland High Roller Shirt')
	AddTextEntry('0x88CE4CB4', 'Magnum Extended')
	AddTextEntry('0x88D0352A', 'Primary Sports Skirt')
	AddTextEntry('0x88DAFA0E', 'Pink LS Diamond Cap')
	AddTextEntry('0x88FEAC55', 'Black Grille Bed Rack')
	AddTextEntry('0x89AF30D9', 'Carbon Street Spoiler')
	AddTextEntry('0x89B2AFA0', 'Mono Retro Sneakers')
	AddTextEntry('0x89E2AA68', 'Dual Headlight Intakes')
	AddTextEntry('0x89FD0FC4', 'Primary Street Skirt')
	AddTextEntry('0x90A26810', 'Epic Bean Can')
	AddTextEntry('0x90A55292', 'Bigness Print Tee')
	AddTextEntry('0x90B5D1F0', 'Purple SC Broker Cap')
	AddTextEntry('0x90CAF07C', 'Primary Light Cage')
	AddTextEntry('0x90E8AF1B', 'Invade and Persuade Invader Tee')
	AddTextEntry('0x90E41B65', 'Black Bigness Logo Jersey')
	AddTextEntry('0x90F268D1', 'It takes a special kind of visionary to sit behind the wheel of a hypercar while it flirts outrageously with the sound barrier and seriously ask the question "Hey, wouldn\'t it be cool if we could put the top down?" But then the folks at Pegassi are nothing if not visionary, and nothing if not special.')
	AddTextEntry('0x91BA1421', 'Red You\'re So Original! Tee')
	AddTextEntry('0x91DF6CF5', 'Primary GT Bumper')
	AddTextEntry('0x91EFC662', 'NEWLY OPENED')
	AddTextEntry('0x91F1D924', 'eCola')
	AddTextEntry('0x91F7A7D1', 'Suits')
	AddTextEntry('0x92B32C1B', 'On the corner of Vinewood Park Drive and Mirror Park Blvd, beneath the Tataviam Mountains to the east and the Vinewood sign to the west, at the intersection of ecstasy and self-abandonment.')
	AddTextEntry('0x92C2AB47', 'No Bumper & Drift Intercooler')
	AddTextEntry('0x92DD408C', 'Performance Hood')
	AddTextEntry('0x92F24D87', 'Red Pulga Sweater')
	AddTextEntry('0x92F96A59', 'Race Spoiler')
	AddTextEntry('0x92F5024E', 'Novak')
	AddTextEntry('0x92FCC234', 'Two Tone Retro Sneakers')
	AddTextEntry('0x93AFCEDF', 'Hinterland')
	AddTextEntry('0x93B6C390', 'Purple Fade Retro Sneakers')
	AddTextEntry('0x93B68FFE', 'Cyan Bigness Waterproof')
	AddTextEntry('0x93BDD683', 'Red Fame or Shame Stars Tee')
	AddTextEntry('0x93CB342E', 'Carbon Arches')
	AddTextEntry('0x93D403E3', 'True Patriot')
	AddTextEntry('0x94B68138', 'Titanium Boxed Exhaust')
	AddTextEntry('0x94C0365E', 'Waifu Wheels')
	AddTextEntry('0x94C4B12E', 'Primary Vented Roof')
	AddTextEntry('0x94C1847D', 'Cubic Le Chien Parka')
	AddTextEntry('0x94E0492B', 'Squash 19 Hoodie')
	AddTextEntry('0x94E82353', 'Roulette Kronos Quad')
	AddTextEntry('0x95A9E553', 'Bullet')
	AddTextEntry('0x95B0C89A', 'Clubs Earrings')
	AddTextEntry('0x95D3D1DD', 'Swirl High Roller Pants')
	AddTextEntry('0x95DFCA6E', 'Street Crimes Boxart Tee')
	AddTextEntry('0x95EB011B', 'Carbon Touring Diffuser')
	AddTextEntry('0x96C24132', 'White High Roller Jacket')
	AddTextEntry('0x96CFD593', 'Navy High Roller Dress')
	AddTextEntry('0x96D1D254', 'Large Roof Rack')
	AddTextEntry('0x96D7F5FF', 'Late Night Promotions')
	AddTextEntry('0x96E05CD2', 'Clubs Earrings')
	AddTextEntry('0x96F28190', 'Gold Kronos Pulse')
	AddTextEntry('0x97BE19E0', 'Primary Performance Spoiler')
	AddTextEntry('0x97DCAB8E', 'Dice Crowex Rond')
	AddTextEntry('0x98A09B95', 'Blue Floral Large Shirt')
	AddTextEntry('0x98B84CAB', 'Teal Color Sweater')
	AddTextEntry('0x98C48556', 'Invade and Persuade RON Tee')
	AddTextEntry('0x98ECB3D2', 'Hood w/ Primary Vents')
	AddTextEntry('0x99BB618A', 'Red Monkey Business Tee')
	AddTextEntry('0x99FDE913', 'Snake Knee Shorts')
	AddTextEntry('0x100D5A58', 'Light Cage')
	AddTextEntry('0x114FDE94', 'THE DIAMOND STANDARD')
	AddTextEntry('0x121BC5F5', 'Secondary Smoothed Hood')
	AddTextEntry('0x125EDD64', 'Stock Primary Fenders')
	AddTextEntry('0x127E90D5', 'Dynasty')
	AddTextEntry('0x128A4E7C', 'Navy Pocket Jacket')
	AddTextEntry('0x128C325C', 'Mission II Tee')
	AddTextEntry('0x129CA7D9', 'Can\'t Win Them All')
	AddTextEntry('0x130DF071', 'BUY NOW')
	AddTextEntry('0x134D6CC0', 'Purple Broker Ornate Bomber')
	AddTextEntry('0x141C1792', 'Custom Splitter')
	AddTextEntry('0x153CBBC6', 'Carbon Mirrors')
	AddTextEntry('0x158FB584', 'Plastic Wind Deflector')
	AddTextEntry('0x160F4993', 'Primary Race Spoiler')
	AddTextEntry('0x183D44EC', 'This is a race that players can play alone on the Inside Track computer. These races can be launched back-to-back with no wait timer between them.')
	AddTextEntry('0x183FC3CF', 'Lube and 69')
	AddTextEntry('0x188C4625', 'Low Level Spoiler')
	AddTextEntry('0x191F82F7', 'Fifty Kronos Quad')
	AddTextEntry('0x195D1D0C', 'Orange Floral Large Shirt')
	AddTextEntry('0x197B1FDC', 'Intake Scoop')
	AddTextEntry('0x197F20A1', 'Green The Diamond Cap')
	AddTextEntry('0x203FC3E5', 'Blue Bigness Waterproof')
	AddTextEntry('0x208D77DC', 'Beige Flying Bravo Fitted')
	AddTextEntry('0x209ACA05', 'Black Crowex Époque')
	AddTextEntry('0x211B7D40', 'Roadster Extended')
	AddTextEntry('0x213E6CCB', 'Monster Intercooler')
	AddTextEntry('0x215DAB52', 'Gray Camo Waterproof')
	AddTextEntry('0x215E1739', 'Green The Diamond Cap')
	AddTextEntry('0x216E16D9', 'Dual Quad Exhausts')
	AddTextEntry('0x233C4FD7', 'Shell Tip Exhaust')
	AddTextEntry('0x241A3286', 'Pink Floral Large Shirt')
	AddTextEntry('0x250E7C0C', 'Plain Grille')
	AddTextEntry('0x253D9963', 'Ceramic Short Headers')
	AddTextEntry('0x255FBE71', 'SINGLE EVENT')
	AddTextEntry('0x260B41A6', 'Exposed Twin Turbo Hood')
	AddTextEntry('0x267AB9DF', 'Carbon Shark Nose')
	AddTextEntry('0x275AA606', 'Secondary Roof Setup')
	AddTextEntry('0x276DAC0A', 'Invade and Persuade Hero Tee')
	AddTextEntry('0x278CD852', 'Colors Yeti LS 19 Hoodie')
	AddTextEntry('0x279D5CF6', 'Ace of Spades')
	AddTextEntry('0x279E107E', 'Ash Retro Sneakers')
	AddTextEntry('0x302CCAC8', 'White Bigness Jersey')
	AddTextEntry('0x303D87F4', 'Pegasus')
	AddTextEntry('0x312AA2F1', 'Yellow Chips Earrings')
	AddTextEntry('0x312FA5D1', 'Red Flying Bravo Cap')
	AddTextEntry('0x315ED5F9', 'Grille Delete')
	AddTextEntry('0x320AED2A', 'Rear Vapid Angle Stripes')
	AddTextEntry('0x320E125B', 'Carbon Splitter')
	AddTextEntry('0x322C5602', 'Red High Roller Waistcoat')
	AddTextEntry('0x324BCEE5', 'White Blagueurs Large Shirt')
	AddTextEntry('0x326FB5BD', 'Black Kronos Tempo')
	AddTextEntry('0x328FD044', 'Black LS Diamond Tee')
	AddTextEntry('0x333C966E', 'Blue Fade Retro Sneakers')
	AddTextEntry('0x339BB134', 'Gold Crowex Rond')
	AddTextEntry('0x341B66EB', 'Gray Patterned Wide Pants')
	AddTextEntry('0x357B8DCF', 'White Baroque Knee Shorts')
	AddTextEntry('0x359B3A1E', 'Chrome Long Headers')
	AddTextEntry('0x371BBB7D', 'GT Spoiler')
	AddTextEntry('0x372EB795', 'Secondary GT Bumper')
	AddTextEntry('0x382DCDAB', 'Gold Fifty Kronos Tempo')
	AddTextEntry('0x392D9A58', 'Green Stripe High Roller Dress')
	AddTextEntry('0x399A1C80', 'CLASSICAL')
	AddTextEntry('0x403B1B49', 'Hood Ducts')
	AddTextEntry('0x403D5158', 'Gold Fifty Kronos Tempo')
	AddTextEntry('0x405ACAB2', 'Black Crowex Rond')
	AddTextEntry('0x411D270B', 'Dapper High Roller Shirt')
	AddTextEntry('0x417E8B7B', 'Secondary Piped Step')
	AddTextEntry('0x418D19DA', 'Plated Front')
	AddTextEntry('0x423BC0ED', 'Mk1 Racing Cage')
	AddTextEntry('0x424CCE34', 'Yellow FB Slipper Loafers')
	AddTextEntry('0x425FC831', 'Teal SC Broker Cap')
	AddTextEntry('0x429C650C', 'Red The Diamond LS Tee')
	AddTextEntry('0x433A78F5', 'Carbon Rear Panel')
	AddTextEntry('0x442AFD1A', 'Silver Kronos Ära')
	AddTextEntry('0x442D5440', 'PAYOUTS')
	AddTextEntry('0x450DBA10', 'Mono Retro Sneakers')
	AddTextEntry('0x464E5369', 'Dual Tip Exhaust')
	AddTextEntry('0x472F4FAD', 'Red LC Diamond Sweater')
	AddTextEntry('0x474FB643', 'SN Lazerforce Sweater')
	AddTextEntry('0x482BBE81', 'Pink Sunset Large Shirt')
	AddTextEntry('0x482D2DD6', 'Carbon Competition Spoiler')
	AddTextEntry('0x482D58A7', 'Poppin\' Cherries!')
	AddTextEntry('0x487EDA35', 'Secondary Bumper')
	AddTextEntry('0x488A5FFC', 'Ceramic Long Headers')
	AddTextEntry('0x490D38A5', 'Black LS Diamond Cap')
	AddTextEntry('0x492C3259', 'Race Roof Scoop')
	AddTextEntry('0x493D43DC', 'Bridged Trunk')
	AddTextEntry('0x499B4E9C', 'Blue Patterned Fitted')
	AddTextEntry('0x505C585E', 'White SC Broker Bomber')
	AddTextEntry('0x509C305E', 'Round Chrome Mirrors')
	AddTextEntry('0x513D3DA0', 'Sec. Street Wing W/ Trunk Lip')
	AddTextEntry('0x520DEA60', 'Green Sci-Fi Large Shirt')
	AddTextEntry('0x536E0337', 'Crossed Grille')
	AddTextEntry('0x540F0B7E', 'Sessanta Nove Alt')
	AddTextEntry('0x541CDFBB', 'Red Broker Coin Bomber')
	AddTextEntry('0x544ED419', 'Cherenkov Lime')
	AddTextEntry('0x546D8EEE', 'Paragon R (Armored)')
	AddTextEntry('0x549C6CAA', 'Black SC Broker Cap')
	AddTextEntry('0x553BDAB8', 'Red The Diamond Classic Tee')
	AddTextEntry('0x561E50FA', 'Stack O\' Crap')
	AddTextEntry('0x561FED8E', 'Teal Camo SN Sweater')
	AddTextEntry('0x563A3606', 'White The Diamond Hoodie')
	AddTextEntry('0x565D7837', 'Organic Perseus Puffer')
	AddTextEntry('0x567BAF82', 'One-armed Bandit')
	AddTextEntry('0x569A7940', 'Classic Hood Latches')
	AddTextEntry('0x571F55AB', 'Xero Gas')
	AddTextEntry('0x575A8E88', 'Black The Diamond LS Tee')
	AddTextEntry('0x575ECADA', 'Padded w/ Black Seats')
	AddTextEntry('0x576F7F30', 'Secondary Performance Skirts')
	AddTextEntry('0x579BB5ED', 'There are some things in life that money can\'t buy. But don\'t fret. We throw them in for free with every purchase from our in-house Store.')
	AddTextEntry('0x587DCD88', 'White P Wide Pants')
	AddTextEntry('0x592FCB5E', 'Secondary Stock')
	AddTextEntry('0x596AFB22', 'Impotent Rage')
	AddTextEntry('0x604A082A', 'Annis Racing')
	AddTextEntry('0x624ED323', 'Blue Patterned Wide Pants')
	AddTextEntry('0x625DAF1C', 'Primary Ducktail')
	AddTextEntry('0x626CDE14', 'We all have that one friend. And with this expansion, they\'ll have somewhere to crash that isn\'t your bidet, and with access to their personal wardrobe they won\'t have to keep borrowing your clothes.')
	AddTextEntry('0x633CAA11', 'Large Grated Grille')
	AddTextEntry('0x634EE32A', 'Blue P Wide Pants')
	AddTextEntry('0x636AE451', 'Carbon Race Spoiler')
	AddTextEntry('0x641D2335', 'Pink Vines Parka')
	AddTextEntry('0x658FDB6F', 'Queen of Spades')
	AddTextEntry('0x663BD714', 'Hashtag Hype Train')
	AddTextEntry('0x666F828B', 'Primary Skirt')
	AddTextEntry('0x669F9118', 'Colors Yeti Cap')
	AddTextEntry('0x672E27D5', 'Purple FB Puffer')
	AddTextEntry('0x676CBF3D', 'Secondary Race Roof Scoop')
	AddTextEntry('0x679D12AB', 'Pink LS Diamond Cap')
	AddTextEntry('0x688A3E3C', 'Black LC Diamond Sweater')
	AddTextEntry('0x689C017C', 'Blue America Loves You Tee')
	AddTextEntry('0x705D4BE2', 'Black The Diamond Resort LS Tee')
	AddTextEntry('0x706A650F', 'Nordic Racer')
	AddTextEntry('0x707AAFDC', 'Secondary Light Cage')
	AddTextEntry('0x711F4DF4', 'Large Filter Blower')
	AddTextEntry('0x721CF114', 'Dusche Rally')
	AddTextEntry('0x722EDDF1', 'Gold Kronos Quad')
	AddTextEntry('0x724D65AD', 'Performance Grille')
	AddTextEntry('0x725D009E', 'Sec. Padded w/ Black Seats')
	AddTextEntry('0x732D98B1', 'Yellow FB Manor Slipper Loafers')
	AddTextEntry('0x734C5E50', 'Gauntlet Hellfire')
	AddTextEntry('0x737F8C43', 'Secondary Vents')
	AddTextEntry('0x741A8EBF', 'Green The Diamond Cap')
	AddTextEntry('0x743CC4DC', 'Primary Classic Grille')
	AddTextEntry('0x745FC81E', 'Low Profile Carbon Skirt')
	AddTextEntry('0x748E46D8', 'You\'ve heard the rumors. You want to believe them, and there\'s only one way to find out. Abandon your preconceptions. Let go of your inhibitions, your doubts, your sense of proportion, your credit rating. The rumors didn\'t begin to do it justice. Welcome to The Diamond.')
	AddTextEntry('0x750A9571', 'Black Fame or Shame Shades')
	AddTextEntry('0x755BEE9A', 'Lady Luck')
	AddTextEntry('0x760FF20F', 'Purple Broker Coin Bomber')
	AddTextEntry('0x761AF428', 'Strawberry Mask')
	AddTextEntry('0x761EC349', 'Black Rim Tint Aviators')
	AddTextEntry('0x765B016F', 'Carbon Grinder Grille')
	AddTextEntry('0x770FD88D', 'Black Blagueurs Jersey')
	AddTextEntry('0x777A0B2F', 'Blue Fade Retro Sneakers')
	AddTextEntry('0x783A4F1E', 'EXPERIENCE EMINENCE')
	AddTextEntry('0x783B8B5F', 'Yeti Camo')
	AddTextEntry('0x786FCE1E', 'Gold Kronos Tempo')
	AddTextEntry('0x788AB57C', 'Big Wing')
	AddTextEntry('0x789E4235', 'SC Broker Leather Fur')
	AddTextEntry('0x792B436C', 'Carbon Aggressive Spoiler')
	AddTextEntry('0x793A223C', 'Violet Retro Sneakers')
	AddTextEntry('0x804EB1E5', 'Blue D Casino Tee')
	AddTextEntry('0x805FE35C', 'GT Spoiler')
	AddTextEntry('0x812B32DB', 'Red SC Broker Cap')
	AddTextEntry('0x814EABE8', 'ART DECO')
	AddTextEntry('0x816D2A5A', 'Lucky Plucker')
	AddTextEntry('0x821E609F', 'Plastic Classic Grille')
	AddTextEntry('0x837A55A5', 'Primary Ducktail')
	AddTextEntry('0x837D1C87', 'Secondary Lifted Ram Bar')
	AddTextEntry('0x845F2175', 'Small Lip Spoiler')
	AddTextEntry('0x851C0FFA', 'Stickerbomb Splitter')
	AddTextEntry('0x852E72DE', 'Black Bigness Waterproof')
	AddTextEntry('0x860A92B2', 'Vysser')
	AddTextEntry('0x865FC04C', 'Cocktail Kitty')
	AddTextEntry('0x869BEBE1', 'EXPERIENCE OVERCONFIDENCE')
	AddTextEntry('0x872C1B36', 'Barracho Beer')
	AddTextEntry('0x886ED22B', 'White Pulga Sweater')
	AddTextEntry('0x890F2143', 'Fender Painted Square Mirrors')
	AddTextEntry('0x896EDA91', 'Purple Vines Parka')
	AddTextEntry('0x900D0BD3', 'Carbon Hood')
	AddTextEntry('0x907A6649', 'Split Boxed Exhausts')
	AddTextEntry('0x914BC7DF', 'Secondary Sports w/ Vents')
	AddTextEntry('0x916A5F49', 'Roll Cage w/ Carbon Seats')
	AddTextEntry('0x923B896A', 'Crowex')
	AddTextEntry('0x937F5FA3', 'Stock Secondary Fenders')
	AddTextEntry('0x962D6F60', 'Purple Joker')
	AddTextEntry('0x972FA14C', 'SN Tan Compass Tee')
	AddTextEntry('0x976C4257', 'Purple Baroque Parka')
	AddTextEntry('0x987FA53A', 'Secondary Low Level Wing')
	AddTextEntry('0x990FA8EB', 'Pink Rage Bomber')
	AddTextEntry('0x994B26D2', 'Blue High Roller Shirt')
	AddTextEntry('0x1009CC75', 'Open')
	AddTextEntry('0x1077A3A2', 'Purple Waterproof')
	AddTextEntry('0x1244C72E', 'Adorned Hoodie')
	AddTextEntry('0x1261F238', 'Primary Sports Splitter')
	AddTextEntry('0x1299CA99', 'PLACE BET ON CONSOLE')
	AddTextEntry('0x1323C9D7', 'Secondary Race Skirt')
	AddTextEntry('0x1332F3CE', 'Primary GT Splitter')
	AddTextEntry('0x1363EF15', 'Das Ist Dusche')
	AddTextEntry('0x1392EE64', 'Gray Loose Bow Tie')
	AddTextEntry('0x1527BD9F', 'White Stripes')
	AddTextEntry('0x1737C947', 'Black SASS Bracelet')
	AddTextEntry('0x1783A188', 'Primary Rear Panel')
	AddTextEntry('0x1902EEB6', 'Carbon GT Aero Skirt')
	AddTextEntry('0x2096F4BC', 'Keeping it Simple')
	AddTextEntry('0x2104D128', 'Roulette Ceaseless')
	AddTextEntry('0x2180E758', 'Craps Large Shirt')
	AddTextEntry('0x2234B3BF', 'Ridged Splitter')
	AddTextEntry('0x2243A80C', 'Carbon Street Skirt')
	AddTextEntry('0x2297BABF', 'No Words Needed...')
	AddTextEntry('0x2466CB59', 'Vice')
	AddTextEntry('0x2471B64B', 'Jack of Diamonds')
	AddTextEntry('0x2533DF70', 'Secondary Low Level Spoiler')
	AddTextEntry('0x2640EDEB', 'Oval Intake Bugcatcher')
	AddTextEntry('0x2644BDC9', 'Vintage Pekhat')
	AddTextEntry('0x2660F361', 'Black The Diamond Cap')
	AddTextEntry('0x2677C1B4', 'Gold Kronos Ära')
	AddTextEntry('0x2706FE4F', 'You\'re So Original! Tee')
	AddTextEntry('0x2744F62A', 'Red LC Diamond Sweater')
	AddTextEntry('0x2768C01E', 'Infinity Exhaust')
	AddTextEntry('0x2831D0D3', 'Tan Spade Kronos Ära')
	AddTextEntry('0x2911C65C', 'Carbon GT Wing')
	AddTextEntry('0x2916EE4B', 'Cage w/ Black Seats')
	AddTextEntry('0x2955A9DD', 'Red SC Broker Cap')
	AddTextEntry('0x3017E0A9', 'Purple Lazerforce Wide Pants')
	AddTextEntry('0x3041FFEC', 'Broker Ornate Hoodie')
	AddTextEntry('0x3071D3CE', 'Thick Sebastian Dix Tee')
	AddTextEntry('0x3088D096', 'Blue Joker')
	AddTextEntry('0x3162D5A4', 'Painted Custom Diffuser')
	AddTextEntry('0x3190C6A6', 'Carbon Racing Skirt')
	AddTextEntry('0x3356AED3', 'Black Fame or Shame Robe')
	AddTextEntry('0x3428F774', 'Chrome Square Mirrors')
	AddTextEntry('0x3433F96B', 'Pink Baroque Cocktail Dress')
	AddTextEntry('0x3565E9A2', 'Racer 21')
	AddTextEntry('0x3566EEA9', 'Till Death Do Us Part')
	AddTextEntry('0x3596C7FE', 'Black Stripe')
	AddTextEntry('0x3694C45B', 'Black SC Broker Cap')
	AddTextEntry('0x3763A3DC', 'Black Baroque Knee Shorts')
	AddTextEntry('0x3791BC49', 'Tuner Spoiler')
	AddTextEntry('0x3837E2A8', 'Brown Spade Kronos Ära')
	AddTextEntry('0x3848B341', 'Purple Color Jersey')
	AddTextEntry('0x3889F00A', 'Oye Taxi')
	AddTextEntry('0x4122D996', 'Vinyl Roof')
	AddTextEntry('0x4186F44E', 'Dual Channel Aperture Exhaust')
	AddTextEntry('0x4194C80A', 'White Rage Bomber')
	AddTextEntry('0x4220E79A', 'Sessanta Nove')
	AddTextEntry('0x4387CD9C', 'Bravado Filter Blower')
	AddTextEntry('0x4451E122', 'Mid Level Wing')
	AddTextEntry('0x4468AC60', 'Carbon Race Skirt')
	AddTextEntry('0x4506D052', 'White Blagueurs Large Shirt')
	AddTextEntry('0x4553E64A', 'Arched Roof Wing')
	AddTextEntry('0x4596C1EE', 'White P Fitted')
	AddTextEntry('0x4598D357', 'Red Stars Fame or Shame Robe')
	AddTextEntry('0x4865D809', 'Green Loose Bow Tie')
	AddTextEntry('0x4869B84C', 'Flint Tools Anteater')
	AddTextEntry('0x4889BA5F', 'TRADITIONAL')
	AddTextEntry('0x4965F569', 'Sports Spoiler')
	AddTextEntry('0x4987F2DB', 'White The Diamond Resort Tee')
	AddTextEntry('0x5004ACE4', 'Chepalle Tires')
	AddTextEntry('0x5072DAD6', 'Roadster')
	AddTextEntry('0x5130BD42', 'Clean Green')
	AddTextEntry('0x5183CE60', 'Zebra Deep Shades')
	AddTextEntry('0x5190DF39', 'THE SLOTS')
	AddTextEntry('0x5215FCFC', 'Brown Pattern Loose Bow Tie')
	AddTextEntry('0x5243BF5A', 'Sports Hood')
	AddTextEntry('0x5243CDA4', 'Cash High Roller Dress')
	AddTextEntry('0x5262F86E', 'Black Fame or Shame Kronos')
	AddTextEntry('0x5315BCCF', 'Black Grille Cover')
	AddTextEntry('0x5325CCEA', 'Orange The Diamond Cap')
	AddTextEntry('0x5337C578', 'CHOOSE YOUR PALETTE')
	AddTextEntry('0x5391D18C', 'Primary Ridged Skirt')
	AddTextEntry('0x5444FE39', 'Primary Big Wing')
	AddTextEntry('0x5474EE33', 'Custom Carbon Grille')
	AddTextEntry('0x5493FCEA', 'Street Crimes Boxart Tee')
	AddTextEntry('0x5604A1F3', 'COLORS')
	AddTextEntry('0x5604B487', 'Primary Piped Step')
	AddTextEntry('0x5672B785', 'Secondary Race Splitter')
	AddTextEntry('0x5762B2F4', 'Invade and Persuade Logo Tee')
	AddTextEntry('0x5785A1AB', 'Secondary Surround & Plating')
	AddTextEntry('0x5796AE79', 'Touring')
	AddTextEntry('0x5833C727', 'Light Cover and Intake')
	AddTextEntry('0x5853F7E5', 'Red Loose Bow Tie')
	AddTextEntry('0x5876ED63', 'Mk4 Racing Cage')
	AddTextEntry('0x6002CD4C', 'Invade and Persuade Suck Tee')
	AddTextEntry('0x6182D654', 'Globe Ranger')
	AddTextEntry('0x6191EB20', 'Racing The Edge')
	AddTextEntry('0x6418CFE6', 'THE PENTHOUSES')
	AddTextEntry('0x6432BC9E', 'Neat High Roller Shirt')
	AddTextEntry('0x6449EA50', 'Hood Removal')
	AddTextEntry('0x6559D076', 'Primary Front Bumper')
	AddTextEntry('0x6570F022', 'Carbon Sports w/ Vents')
	AddTextEntry('0x6630B6CF', 'Sebastian Dix Jersey')
	AddTextEntry('0x6659F356', 'Purple The Diamond Cap')
	AddTextEntry('0x6684BDB7', 'Team Tracey Tee')
	AddTextEntry('0x6759E438', 'Window Plates')
	AddTextEntry('0x6824AEF3', 'EXPERIENCE EXPERIENCES')
	AddTextEntry('0x6846B897', 'Purple FB Puffer')
	AddTextEntry('0x6861E895', 'Black Louvers')
	AddTextEntry('0x6937CEE2', 'SC Broker Logo Sweater')
	AddTextEntry('0x6939D863', 'Teal Broker Coin Bomber')
	AddTextEntry('0x7042D133', 'Red No Talent Required Tee')
	AddTextEntry('0x7109B5E1', 'Street Crimes Bikers Tee')
	AddTextEntry('0x7178F6A8', 'Crimson High Roller Jacket')
	AddTextEntry('0x7390E9F1', 'Secondary Roof')
	AddTextEntry('0x7713A5D2', 'Vented Hood w/ Vents')
	AddTextEntry('0x7840D40D', 'Secondary Racing Skirt')
	AddTextEntry('0x7893FFAD', 'Gray Patterned Wide Pants')
	AddTextEntry('0x7953A4D4', 'Narc')
	AddTextEntry('0x7969F710', 'Digital Deep Shades')
	AddTextEntry('0x7990DB6E', 'Red Flying Bravo Cap')
	AddTextEntry('0x8368A201', 'Raceway Hero')
	AddTextEntry('0x8468F1C4', 'Meinmacht Painted')
	AddTextEntry('0x8599DDE5', 'Secondary Roof Spoiler')
	AddTextEntry('0x8600BB09', 'No Talent Required Tee')
	AddTextEntry('0x8853C6D8', 'Silver Ceaseless')
	AddTextEntry('0x8855FAD7', 'Primary Stock Spoiler')
	AddTextEntry('0x8951DCC1', 'CONGRATULATIONS')
	AddTextEntry('0x8956D115', 'Power Ram Rear')
	AddTextEntry('0x9011A990', 'Primary Race Splitter')
	AddTextEntry('0x9098FC2C', 'Yellow Vines Parka')
	AddTextEntry('0x9106D8EF', 'Carbon Race Hood')
	AddTextEntry('0x9172BF17', 'Jack of Clubs')
	AddTextEntry('0x9184F3DA', 'Silver Kronos Tempo')
	AddTextEntry('0x9230CDBB', 'Gray Pocket Jacket')
	AddTextEntry('0x9445AA41', 'Queen of Roses')
	AddTextEntry('0x9472CD24', 'Peyote Gasser')
	AddTextEntry('0x9596A6DD', 'Painted Accent')
	AddTextEntry('0x9646F10E', 'Pink Sunset Large Shirt')
	AddTextEntry('0x9688AD89', 'White Broker Wide Pants')
	AddTextEntry('0x9945B5EF', 'Lime Waterproof')
	AddTextEntry('0x9952F732', 'Auto Exotic')
	AddTextEntry('0x10247D8A', 'Twin Turbo')
	AddTextEntry('0x10315A19', 'Carbon Race Spoiler')
	AddTextEntry('0x10706ADA', 'Dice Crowex Rond')
	AddTextEntry('0x12434C0C', 'Orange Fade Tint Aviators')
	AddTextEntry('0x13795C10', 'Broker Knee Shorts')
	AddTextEntry('0x14818C30', 'Junk')
	AddTextEntry('0x16822D50', 'Play Your Ace')
	AddTextEntry('0x17879E65', 'Street Splitter')
	AddTextEntry('0x19278AA1', 'Titanium Side Exit Exhaust')
	AddTextEntry('0x19698FEA', 'Invade and Persuade Jets Tee')
	AddTextEntry('0x20334C06', 'It sounds so simple in theory. Why shouldn\'t the cutting edge of hypercar design dovetail seamlessly with the bleeding edge of competition-ready, open-wheel racing tech? Well, forget the theory. Sit in the driver\'s seat. Take a breath, pucker up, and shoot a tentative glance in the direction of the throttle. Did you feel that? Have you noticed that you are suddenly a mile and a half into the next time zone, and your face is inside out? Yeah. That\'s why.')
	AddTextEntry('0x24715C9A', 'Black Floral High Roller Jacket')
	AddTextEntry('0x26592F4E', 'Today\'s muscle cars might look shredded, but we all know the gains aren\'t real. Deep down they\'re all juiced-up phoneys with nothing but a short temper and a tiny exhaust. If you want some all-natural brawn, you need go old school. The big block under the Impaler\'s hood trains by chopping wood, benching peaceniks, and deriding the weak - and there\'s just no faking that.')
	AddTextEntry('0x29816DDA', 'Gold SASS Bracelet')
	AddTextEntry('0x30628FCA', 'Blue Oh No He Didn\'t! Tee')
	AddTextEntry('0x31948ACD', 'Black Pulga Sweater')
	AddTextEntry('0x32010F4B', 'Red Fame or Shame Shades')
	AddTextEntry('0x32608AF8', 'Green High Roller Pants')
	AddTextEntry('0x33233A43', 'Gold Big Bore Exhausts')
	AddTextEntry('0x33630B97', 'Orderly High Roller Shirt')
	AddTextEntry('0x35166A01', 'Blue Lazerforce Wide Pants')
	AddTextEntry('0x35169F42', 'White Baroque Knee Shorts')
	AddTextEntry('0x35349AAA', 'Blue I\'ve Been Shamed Tee')
	AddTextEntry('0x36913C45', 'Blue Argyle Aviators')
	AddTextEntry('0x37147F83', 'HIGH ROLLER')
	AddTextEntry('0x38505FE7', 'Red The Diamond Classic Tee')
	AddTextEntry('0x40985E5F', 'Invade and Persuade Oil Tee')
	AddTextEntry('0x42722BCA', 'Secondary Ram Plate')
	AddTextEntry('0x42948F85', 'Purple SN Bigness Hoodie')
	AddTextEntry('0x43711D78', 'Primary Bull Bar II')
	AddTextEntry('0x45663A91', 'Blue Retro Sneakers')
	AddTextEntry('0x45988A07', 'Racer 05')
	AddTextEntry('0x45988E96', 'Purple Güffy Waterproof')
	AddTextEntry('0x46029C55', 'Queen of Diamonds')
	AddTextEntry('0x47900EF4', 'Teal SC Broker Wide Pants')
	AddTextEntry('0x51133B61', 'Home just doesn\'t feel like home unless you have ten hypercars in a well-guarded basement.')
	AddTextEntry('0x51676DDD', 'Primary Street Spoiler')
	AddTextEntry('0x53157D7B', 'Primary Roof')
	AddTextEntry('0x54054FEF', 'Cream High Roller Dress')
	AddTextEntry('0x54269C89', 'Secondary Race Wing')
	AddTextEntry('0x54333C8E', 'Street Splitter')
	AddTextEntry('0x54532E96', 'White Broker Coin Bomber')
	AddTextEntry('0x58243A8C', 'SC Broker Hoodie')
	AddTextEntry('0x60310FC2', 'FLOOR PLAN')
	AddTextEntry('0x67282B28', 'Red Stripe')
	AddTextEntry('0x69156E47', 'Prim. Padded w/ Black Seats')
	AddTextEntry('0x69545BC0', 'Atomic Sponsor')
	AddTextEntry('0x71750A44', 'Secondary Fins')
	AddTextEntry('0x72972DDD', 'Stock Primary Fenders')
	AddTextEntry('0x73165A8C', 'Neon Waterproof')
	AddTextEntry('0x74090C63', 'Green Sunset Large Shirt')
	AddTextEntry('0x74880C5B', 'Secondary Middle Intake')
	AddTextEntry('0x76958F43', 'Rear Window Louvers')
	AddTextEntry('0x78105F04', 'Gold Fade High Roller Dress')
	AddTextEntry('0x81356AFC', 'Orange Camo Waterproof')
	AddTextEntry('0x83552BEE', 'Secondary Hood')
	AddTextEntry('0x86143E7E', 'Blue FB Slipper Loafers')
	AddTextEntry('0x86798EA1', 'The Table')
	AddTextEntry('0x89960BA2', 'Green Vines Parka')
	AddTextEntry('0x92638A0E', 'Secondary Roof Scoop')
	AddTextEntry('0x93067E8A', 'Ducktail')
	AddTextEntry('0x94193E8E', 'BET LIMIT')
	AddTextEntry('0x94337B18', 'Window Louvers')
	AddTextEntry('0x95029CF2', 'SC Broker Logo Tee')
	AddTextEntry('0x95971CDA', 'Sharp High Roller Waistcoat')
	AddTextEntry('0x98695C2E', 'Striped Deep Shades')
	AddTextEntry('0x99559DD2', 'Black D Casino Tee')
	AddTextEntry('0x165440FE', 'GT Bumper')
	AddTextEntry('0x171516CC', 'Extended Skirts')
	AddTextEntry('0x214155E3', 'Green Fade SN Parka')
	AddTextEntry('0x226180DB', 'INSIDE TRACK')
	AddTextEntry('0x226430B6', 'Colors Yeti Cap')
	AddTextEntry('0x239398D9', 'Extended Secondary Skirts')
	AddTextEntry('0x244776CE', 'Secondary Splitter')
	AddTextEntry('0x293903B7', 'SC Broker Logo Tee')
	AddTextEntry('0x294891DF', 'Invade and Persuade Hero Tee')
	AddTextEntry('0x306043F0', 'Tan Dice Earrings')
	AddTextEntry('0x333880FA', 'Secondary Lip Spoiler')
	AddTextEntry('0x341304B3', 'Black E Wide Pants')
	AddTextEntry('0x356419FA', 'Mute Deep Shades')
	AddTextEntry('0x360757DB', 'Cyan SN Paint Cocktail Dress')
	AddTextEntry('0x363515D1', 'Burgundy Pocket Jacket')
	AddTextEntry('0x369845AF', 'Sports Wing')
	AddTextEntry('0x403963F7', 'Primary Street Skirt')
	AddTextEntry('0x463633ED', 'Magenta Tint Aviators')
	AddTextEntry('0x503497C3', 'PATTERN')
	AddTextEntry('0x513047E9', 'Primary Painted Street')
	AddTextEntry('0x534017CE', 'Exposed Carbon Grille')
	AddTextEntry('0x538697F9', 'Gold Kronos Pulse')
	AddTextEntry('0x549250C8', 'Purple Camo SN Sweater')
	AddTextEntry('0x554994F4', 'Secondary Ducktail')
	AddTextEntry('0x557162CA', 'EXTRA BEDROOM')
	AddTextEntry('0x559200D3', 'Street Spoiler')
	AddTextEntry('0x578131B4', 'Purple Güffy Waterproof')
	AddTextEntry('0x581481A6', 'Burgundy Pocket Jacket')
	AddTextEntry('0x647155BD', 'Estancia Cigars')
	AddTextEntry('0x667463A8', 'Single Light Cover')
	AddTextEntry('0x694316ED', 'Carbon Spoiler')
	AddTextEntry('0x709783EA', 'Woodland Yeti LS 19 Hoodie')
	AddTextEntry('0x742518CF', 'Black Broker Cap')
	AddTextEntry('0x762190A7', 'Ace of Spades')
	AddTextEntry('0x774808E8', 'Plastic Bed Rack')
	AddTextEntry('0x793961B4', 'Fame or Shame No Evil Tee')
	AddTextEntry('0x825888F1', 'White Deep Shades')
	AddTextEntry('0x835605A1', 'Speedy')
	AddTextEntry('0x837951A2', 'Valiant Vapid')
	AddTextEntry('0x848030F4', 'Blue Floral High Roller Dress')
	AddTextEntry('0x852741F9', 'Carbon Vented Hood w/ Vents')
	AddTextEntry('0x870415AD', 'Secondary Vented Roof')
	AddTextEntry('0x893606A7', 'Low Level Wing')
	AddTextEntry('0x935983E6', 'King of Hearts')
	AddTextEntry('0x1341064E', 'Black LS Diamond Tee')
	AddTextEntry('0x1783835A', 'Triple Intake Kit')
	AddTextEntry('0x2389110F', 'Silver Crowex Rond')
	AddTextEntry('0x2635931C', 'Green Blagueurs Parka')
	AddTextEntry('0x2643157D', 'Primary Open Grille')
	AddTextEntry('0x2683445E', 'Rigid Rocket')
	AddTextEntry('0x2993618D', 'You might be wondering, does the world really need another high-caliber sports saloon? But remember, there are some things the human race can never get enough of - like sex, or violence. And this isn\'t just any sex or violence: the Jugular is really kinky sex, and really gratuitous violence. Has that answered your question?')
	AddTextEntry('0x3202676A', 'Licquorice Waterproof')
	AddTextEntry('0x3313982B', 'Stars Fame or Shame Robe')
	AddTextEntry('0x3965123A', 'SC Broker Logo Hoodie')
	AddTextEntry('0x4163720D', 'The Diamond Vintage Tee')
	AddTextEntry('0x4226549E', 'Carbon Performance Skirts')
	AddTextEntry('0x4751883D', 'Grey Dix Jersey')
	AddTextEntry('0x4866052C', 'Woodland Camo Waterproof')
	AddTextEntry('0x5037781A', 'Ruby Blagueurs Parka')
	AddTextEntry('0x5149691F', 'Exposed Engine Setup')
	AddTextEntry('0x5561387D', 'Ace of Diamonds')
	AddTextEntry('0x5600940B', 'Green FB Puffer')
	AddTextEntry('0x5780528B', 'Primary GT Skirt')
	AddTextEntry('0x6114914F', 'Electric Blue Tint Aviators')
	AddTextEntry('0x6178203F', 'Gold Roulette Kronos Tempo')
	AddTextEntry('0x6341695A', 'Black Baroque Knee Shorts')
	AddTextEntry('0x6445311C', 'Contrast Camo Waterproof')
	AddTextEntry('0x7723117D', 'Primary Vented Scoop')
	AddTextEntry('0x8057019A', 'Race Exhaust')
	AddTextEntry('0x8658273C', 'Carbon Lip Spoiler')
	AddTextEntry('0x8860594A', 'Black Open Grille')
	AddTextEntry('0x9011317A', 'Competition Set Up')
	AddTextEntry('0x9204421F', 'Yellow Chips Earrings')
	AddTextEntry('0x9962632D', 'Black Deep Shades')
	AddTextEntry('0x10112270', 'Leopard Bigness Waterproof')
	AddTextEntry('0x12503614', 'Tan Rose Cocktail Dress')
	AddTextEntry('0x12657948', 'Black LS Diamond Cap')
	AddTextEntry('0x14433122', 'Carbon Hard Top')
	AddTextEntry('0x16563012', 'Black Waterproof')
	AddTextEntry('0x17320557', 'Silver SASS Bracelet')
	AddTextEntry('0x19932763', 'Primary Rear Bumper')
	AddTextEntry('0x19985802', 'Mustard High Roller Shirt')
	AddTextEntry('0x20634706', 'Primary Bumper & Race Fogs')
	AddTextEntry('0x20758553', 'Competition Spoiler')
	AddTextEntry('0x21312236', 'Blue The Diamond Resort LS Tee')
	AddTextEntry('0x21704997', 'Racing Kit')
	AddTextEntry('0x24698499', 'Secondary Flared Fenders')
	AddTextEntry('0x27159678', 'Estancia Tobacco')
	AddTextEntry('0x28588044', 'Grille Fogs')
	AddTextEntry('0x30380756', 'Primary Ram Plate')
	AddTextEntry('0x31721741', 'Painted V8')
	AddTextEntry('0x31752439', 'Red Camo SN Sweater')
	AddTextEntry('0x36652668', 'Carbon GT Spoiler')
	AddTextEntry('0x39434138', 'GT Wing')
	AddTextEntry('0x39755385', 'Ash Retro Sneakers')
	AddTextEntry('0x42850945', 'Geometric Camo')
	AddTextEntry('0x42993464', 'Sunrise Deep Shades')
	AddTextEntry('0x44016531', 'Invade and Persuade Gold Tee')
	AddTextEntry('0x49300845', 'Box Exhausts')
	AddTextEntry('0x53083496', 'Orange Patterned Wide Pants')
	AddTextEntry('0x54721352', 'Mustard FB Manor Jersey')
	AddTextEntry('0x54731994', 'Red Fame or Shame Stars Tee')
	AddTextEntry('0x57198269', 'Gray Yeti Puffer')
	AddTextEntry('0x60463755', 'Blue Color Bomber')
	AddTextEntry('0x60777894', 'Black SC Broker Bomber')
	AddTextEntry('0x62494875', 'Jackpot')
	AddTextEntry('0x64296485', 'Jack of Hearts')
	AddTextEntry('0x65615178', 'Some people say that fortune favors the brave. Here at The Diamond, we\'d rather say that destiny favors those with a full Diamond Membership. Spin the wheel once a day, and you\'re guaranteed a prize and a massive dose of self-importance every time.')
	AddTextEntry('0x65679117', 'Orange Floral Large Shirt')
	AddTextEntry('0x66125680', 'Squash Squares Hoodie')
	AddTextEntry('0x66223835', 'White SC Broker Cap')
	AddTextEntry('0x68390275', 'Gold SC Silk Robe')
	AddTextEntry('0x69278157', 'Red No Talent Required Tee')
	AddTextEntry('0x74445475', 'Woodland Yeti Cap')
	AddTextEntry('0x76783486', 'Jackal Racing')
	AddTextEntry('0x77428957', 'Hexa Vented Hood')
	AddTextEntry('0x77945708', 'Quad Exhausts')
	AddTextEntry('0x81114593', 'Black Broker Cap')
	AddTextEntry('0x83007061', 'Carbon Ducktail')
	AddTextEntry('0x83657873', 'Knit High Roller Waistcoat')
	AddTextEntry('0x83938839', 'Vysser Grille')
	AddTextEntry('0x84268422', 'Royalty Crowex Rond')
	AddTextEntry('0x84346356', 'Red You\'re Awful Tee')
	AddTextEntry('0x85226142', 'Gold SASS Bracelet')
	AddTextEntry('0x85752999', 'Street Crimes Action Tee')
	AddTextEntry('0x87425822', 'Red FB Manor Slipper Loafers')
	AddTextEntry('0x90591397', 'Blue D Casino Tee')
	AddTextEntry('0x91560777', 'De Koch')
	AddTextEntry('0x91628008', 'Intersected Turbo')
	AddTextEntry('0x92672140', 'Broker Coin Sweater')
	AddTextEntry('0x94287949', 'Snake Leather Fur')
	AddTextEntry('0x95075924', 'Hearts Earrings')
	AddTextEntry('0x96096243', 'Gold Ceaseless')
	AddTextEntry('0xA001A4F6', 'Black Stripe')
	AddTextEntry('0xA00E04AC', 'Pink Prairie Large Shirt')
	AddTextEntry('0xA0114D64', 'Invade and Persuade Tour Tee')
	AddTextEntry('0xA0128849', 'Black The Diamond Silk Robe')
	AddTextEntry('0xA02BDDE2', 'Primary Competition Spoiler')
	AddTextEntry('0xA034A953', 'White Stripe')
	AddTextEntry('0xA0592396', 'Aero Spoiler')
	AddTextEntry('0xA06C954C', 'White LS Diamond Cap')
	AddTextEntry('0xA06F5F5A', 'Bolted Stock w/ Over Riders')
	AddTextEntry('0xA097B889', 'Black Bravado')
	AddTextEntry('0xA0A45D2C', 'Cage w/ Colored Seats')
	AddTextEntry('0xA0AC68E0', 'Blue Argyle Aviators')
	AddTextEntry('0xA0B3E90A', 'Yellow Pulga Sweater')
	AddTextEntry('0xA0E288A7', 'Race Hood')
	AddTextEntry('0xA0E43627', 'Magenta Bigness Waterproof')
	AddTextEntry('0xA1BF5EF4', 'Suits High Roller Jacket')
	AddTextEntry('0xA1C02B89', 'Pink Fade Güffy Spray Puffer')
	AddTextEntry('0xA1C88AD1', 'White Loose Bow Tie')
	AddTextEntry('0xA1D79289', 'Chrome Short Headers')
	AddTextEntry('0xA1F5CAA0', 'We understand. It\'s not just a car. It\'s a part of you. And if you\'re a member with us, we\'ll take that part of you and store it safe and sound, where it belongs: in a maximum security, subterranean storage unit.')
	AddTextEntry('0xA2A370A2', 'Mono Deep Shades')
	AddTextEntry('0xA2B0190D', 'Black Street Crimes Icons Tee')
	AddTextEntry('0xA3C54E48', 'WINNER')
	AddTextEntry('0xA3E4F114', 'ART NOUVEAU')
	AddTextEntry('0xA4B0E433', 'Inset Hood')
	AddTextEntry('0xA4D4C8E0', 'This is technically a pickup truck, in the same way that a machete could technically be used in self-defense. And if you so much as mention its six-wheel, machine-gun-toting big brother, the Caracara is going to defend itself all over your mangled corpse. You have been warned.')
	AddTextEntry('0xA5ACCDE2', 'Red Güffy Waterproof')
	AddTextEntry('0xA5B3A7C9', 'Secondary Classic Grille')
	AddTextEntry('0xA5B4FA7F', 'Diamonds Earrings')
	AddTextEntry('0xA5C1EFD4', 'Blue Sunset Large Shirt')
	AddTextEntry('0xA5D5CD73', 'Garland Leather Fur')
	AddTextEntry('0xA5EDB46E', 'White Tiled Cocktail Dress')
	AddTextEntry('0xA5F1E6CB', 'Sessanta Nove')
	AddTextEntry('0xA5FA8A5C', 'TBar Rear')
	AddTextEntry('0xA6A15971', 'Big Bore Exhaust')
	AddTextEntry('0xA6A98732', 'Secondary Cage')
	AddTextEntry('0xA6B6BF19', 'Brown SN High Roller Waistcoat')
	AddTextEntry('0xA6EB7F1E', 'Bigness Leopard Tee')
	AddTextEntry('0xA6F5366C', 'Dummy label.')
	AddTextEntry('0xA7AFDC0D', '3RD')
	AddTextEntry('0xA7CEEA1C', 'Grapes Mask')
	AddTextEntry('0xA7E0520C', 'Green FB Waterproof')
	AddTextEntry('0xA7E4CEBE', 'Surge')
	AddTextEntry('0xA7FB59A7', 'Carbon Stock Spoiler')
	AddTextEntry('0xA8B8F8D5', 'Tricolor')
	AddTextEntry('0xA9A41CE1', 'Green FB Manor Slipper Loafers')
	AddTextEntry('0xA9B11AF7', 'Dusche Gold')
	AddTextEntry('0xA9C6C478', 'Silver Kronos Pulse')
	AddTextEntry('0xA9D8E523', 'Black Baroque Cocktail Dress')
	AddTextEntry('0xA9DD8D5B', 'Carbon Spoiler')
	AddTextEntry('0xA9EEF168', 'Carbon Low Mount Spoiler')
	AddTextEntry('0xA17C1EC2', 'SERVERS DOWN')
	AddTextEntry('0xA35D607A', 'Drift Intake')
	AddTextEntry('0xA45C64DB', 'Mauve Fade Retro Sneakers')
	AddTextEntry('0xA45DF6F5', 'Primary Splitter')
	AddTextEntry('0xA45EBD18', 'Black Bigness Waterproof')
	AddTextEntry('0xA46D4952', 'Black E Wide Pants')
	AddTextEntry('0xA61B90C4', 'Dual Filter Blower')
	AddTextEntry('0xA62DCE54', 'Carbon Hood w/ Vents')
	AddTextEntry('0xA67E4EB2', 'Skull & Aces')
	AddTextEntry('0xA72E2FE6', 'RENOVATE YOUR PENTHOUSE')
	AddTextEntry('0xA79AA66D', 'Pink LS Diamond Cap')
	AddTextEntry('0xA81A16E7', 'Fall Blagueurs Parka')
	AddTextEntry('0xA83B2919', 'Beige Loose Bow Tie')
	AddTextEntry('0xA84E3AF0', 'Green Sci-Fi Large Shirt')
	AddTextEntry('0xA86C770A', 'Brown SN High Roller Pants')
	AddTextEntry('0xA88BF90B', 'Brown Stripe High Roller Dress')
	AddTextEntry('0xA89DD24D', 'Roadster Grille')
	AddTextEntry('0xA189BB85', 'Grayscale SN Parka')
	AddTextEntry('0xA242B76A', 'Bigness Print Tee')
	AddTextEntry('0xA306EC43', 'Camo High Roller Pants')
	AddTextEntry('0xA315BFC8', 'White Bigness Logo Jersey')
	AddTextEntry('0xA361E2FE', 'Red Retro Sneakers')
	AddTextEntry('0xA477F7B6', 'Primary Half Cage')
	AddTextEntry('0xA619F1C3', 'Primary Painted Drift')
	AddTextEntry('0xA726C7D0', 'Black Kronos Quad')
	AddTextEntry('0xA816C721', 'Ink Inc.')
	AddTextEntry('0xA859EB0B', 'Black Sport Bar')
	AddTextEntry('0xA938D69F', 'Mission I Tee')
	AddTextEntry('0xA948B1CF', 'Race Carbon Skirt')
	AddTextEntry('0xA974BD4D', 'Secondary Street Spoiler')
	AddTextEntry('0xA977F626', 'Secondary Vented Scoop')
	AddTextEntry('0xA2334A55', 'Black Broker Coin Bomber')
	AddTextEntry('0xA5273FDC', 'Stickerbomb Hood')
	AddTextEntry('0xA6644E1D', 'Blue FB Waterproof')
	AddTextEntry('0xA7625F9E', 'SITE UNDER CONSTRUCTION')
	AddTextEntry('0xA7815E27', 'Fender Round Chrome Mirrors')
	AddTextEntry('0xA8200B4B', 'Power Ram Extended')
	AddTextEntry('0xA9991DD8', 'CANCEL')
	AddTextEntry('0xA59271AE', 'Black The Diamond Cap')
	AddTextEntry('0xA91327FE', 'Woodland Yeti Cap')
	AddTextEntry('0xA651209B', 'Carbon Roof')
	AddTextEntry('0xA1170855', 'Teal Broker Ornate Bomber')
	AddTextEntry('0xA4741809', 'Orange Fade Tint Aviators')
	AddTextEntry('0xA6442782', 'Red Le Chien Parka')
	AddTextEntry('0xA7075248', 'Steam Punk')
	AddTextEntry('0xAA0527D7', 'Street Crimes Logo Tee')
	AddTextEntry('0xAA08A5F1', 'Carbon Performance Grille')
	AddTextEntry('0xAA8A19F7', 'Teal Color Bomber')
	AddTextEntry('0xAA8EB1F4', 'Redwood Racing')
	AddTextEntry('0xAA3572E6', 'Bolted Stock')
	AddTextEntry('0xAA335848', 'In the Pocket')
	AddTextEntry('0xAABD1E5B', 'Secondary Bumper Splitter')
	AddTextEntry('0xAAC04A19', 'Side Mounted Exhausts')
	AddTextEntry('0xAAC1F2A1', 'Horn OK Please')
	AddTextEntry('0xAAD64C78', 'White Rage Bomber')
	AddTextEntry('0xAAD525B0', 'Primary Ram Bar')
	AddTextEntry('0xAAD53453', 'EXPERIENCE SUBSERVIENCE')
	AddTextEntry('0xAB02717A', 'Blue Cards High Roller Jacket')
	AddTextEntry('0xAB6143E9', 'SC Broker Logo Sweater')
	AddTextEntry('0xABB4FE07', 'White LS Diamond Cap')
	AddTextEntry('0xABDCB90C', 'Wheel Crowex Époque')
	AddTextEntry('0xAC024C63', 'Red Bigness Waterproof')
	AddTextEntry('0xAC1BC91A', 'Blue Fame or Shame Kronos')
	AddTextEntry('0xAC5D3C7E', 'Gold SASS Wrist Piece')
	AddTextEntry('0xAC7CC519', 'RESULTS')
	AddTextEntry('0xAC96FAED', 'Large Filter / No Hood')
	AddTextEntry('0xAC956CD8', 'Purple Floral High Roller Jacket')
	AddTextEntry('0xAC992E77', 'Carbon Race Diffuser')
	AddTextEntry('0xAC399297', 'Gray Vinewood Fitted')
	AddTextEntry('0xACB4C8F0', 'Purple Joker')
	AddTextEntry('0xACC94C77', 'SC Broker Print Tee')
	AddTextEntry('0xACC374AB', 'Carb. Wing W/ Trunk Lip')
	AddTextEntry('0xACCB0DED', 'Dutch Motor Market')
	AddTextEntry('0xACD50A32', 'Teal SC Broker Cap')
	AddTextEntry('0xACEF0067', 'Purple The Diamond Cap')
	AddTextEntry('0xACF1DACF', 'Titanium Oval Tip')
	AddTextEntry('0xACF2D382', 'Black Blagueurs Jersey')
	AddTextEntry('0xACF6C2D7', 'Black Stripe')
	AddTextEntry('0xACF12C8F', 'PAYOUT')
	AddTextEntry('0xAD1BD3D0', 'Mustard FB Manor Jersey')
	AddTextEntry('0xAD2E7396', 'The bespoke additions to the Penthouse of your hot, wet dreams begin here. Your Lounge Area features a bar and dining facilities as standard, and enables you to add five other expansions to your suite.')
	AddTextEntry('0xAD3B9BC4', 'Yellow Pulga Sweater')
	AddTextEntry('0xAD4C4B45', 'Fame or Shame Stars Tee')
	AddTextEntry('0xAD4F2129', 'Carbon Ridgeline Hood')
	AddTextEntry('0xAD788F6C', 'Red Abstraction')
	AddTextEntry('0xADF93572', 'Pink Fade Güffy Spray Puffer')
	AddTextEntry('0xAE1BCFAD', 'Rusty Trunk')
	AddTextEntry('0xAE5FF522', 'ADVERTISEMENT')
	AddTextEntry('0xAE8A31E6', 'What is a car for, if it\'s not for getting from A to B? And what\'s the point of A and B, if they\'re not a quarter of a mile apart on a flat surface in a straight line? These are the questions Bravado asked themselves, and the Hellfire was the answer. Give it what it needs, and this thing will immolate just about everything else on four wheels. Turn that funny-looking wheel in the middle of the dash even a little bit, and you\'re as good as dead.')
	AddTextEntry('0xAE63EA09', 'Invade and Persuade Logo Tee')
	AddTextEntry('0xAE160EA4', 'Gray Yeti Cap')
	AddTextEntry('0xAE3830E3', 'Black The Diamond Cap')
	AddTextEntry('0xAEB0C681', 'Neon 52')
	AddTextEntry('0xAED05DE0', 'Orange The Diamond Hoodie')
	AddTextEntry('0xAEEFC5BE', 'Tri Titanium Tipped Exhausts')
	AddTextEntry('0xAEFA4685', 'Red Bigness Waterproof')
	AddTextEntry('0xAF0F8E8B', 'Red Deep Shades')
	AddTextEntry('0xAF8B6D9B', 'Black SC Broker Wide Pants')
	AddTextEntry('0xAF966F3C', 'Caracara 4x4')
	AddTextEntry('0xAFB789DE', 'Ridged Skirt')
	AddTextEntry('0xAFC4613E', '8-Ball Rose')
	AddTextEntry('0xAFD7C0DE', 'Silver Crowex Époque')
	AddTextEntry('0xAFE74A3B', 'Grey Dix Jersey')
	AddTextEntry('0xAFE13273', 'Primary Roof Spoiler')
	AddTextEntry('0xAFED584C', 'Black Baroque Parka')
	AddTextEntry('0xB0026FD3', 'Primary Wide Spoiler')
	AddTextEntry('0xB007A74F', 'Black Loose Bow Tie')
	AddTextEntry('0xB031E4A3', 'Two Tone Deep Shades')
	AddTextEntry('0xB0617D52', 'Black Perseus Wide Pants')
	AddTextEntry('0xB0961647', 'White SC Broker Knee Shorts')
	AddTextEntry('0xB09AF791', 'HORSE ODDS')
	AddTextEntry('0xB0A0F7E4', 'Mesh Grille Cover')
	AddTextEntry('0xB0ADEE64', 'Once upon a time, an off-roader was designed to cope with mud, rocks, marshes and hills. The Hellion, on the other hand, has been exquisitely calibrated to go up a 35% sand dune on just the right side of bursting into flames. Which will make all the difference in rush hour.')
	AddTextEntry('0xB0C3DDF9', 'SC Broker Sweater')
	AddTextEntry('0xB0F498B8', 'Red Flying Bravo Fitted')
	AddTextEntry('0xB0FEA5D9', 'Gray Yeti Cap')
	AddTextEntry('0xB1AF3BBD', 'Slat Skirt')
	AddTextEntry('0xB1B50EE4', 'Republican Space Rangers')
	AddTextEntry('0xB1E88442', 'King of Diamonds')
	AddTextEntry('0xB1EEFE69', 'Drag Spoiler')
	AddTextEntry('0xB2A52C2C', 'Carbon Race Hood')
	AddTextEntry('0xB2AE133B', 'EXPERIENCE OPULENCE')
	AddTextEntry('0xB2FEA74A', 'Red Pulga Sweater')
	AddTextEntry('0xB3E91CE9', 'Blue Baroque Knee Shorts')
	AddTextEntry('0xB3EECCD0', 'Yellow Accents')
	AddTextEntry('0xB4B793BF', 'Exposed Intercooler')
	AddTextEntry('0xB4EC2B19', 'Black Pulga Sweater')
	AddTextEntry('0xB4FA338D', 'Blue FB Manor Slipper Loafers')
	AddTextEntry('0xB5D01A62', 'Secondary Half Cage')
	AddTextEntry('0xB5D842E8', 'White Broker Cap')
	AddTextEntry('0xB5F17527', 'Primary Lifted Piped Step')
	AddTextEntry('0xB6A7129D', 'Carbon w/ Primary Stripe')
	AddTextEntry('0xB6AEE927', 'Carbon Street Skirt')
	AddTextEntry('0xB6C861CC', 'Pink High Roller Shirt')
	AddTextEntry('0xB7A3087F', 'The only sin is understatement. If you need a winning formula, or just a winning hairdo, the 80\'s have got you covered. This is one for the purists.')
	AddTextEntry('0xB7D56095', 'Black Kronos Pulse')
	AddTextEntry('0xB8BB36CA', 'Twin Boxed Exhausts')
	AddTextEntry('0xB8CFD048', 'EXPERIENCE TUMESCENCE')
	AddTextEntry('0xB8DEBCCA', 'Carbon Street Spoiler')
	AddTextEntry('0xB8E9BAB4', 'Primary Bumper Splitter')
	AddTextEntry('0xB9C4FD3A', 'Alt Stock Spoiler')
	AddTextEntry('0xB9DAE498', 'Spade Kronos Pulse')
	AddTextEntry('0xB9EDCC7E', 'Mocha Loose Bow Tie')
	AddTextEntry('0xB10DCC46', 'Carbon Stock Spoiler')
	AddTextEntry('0xB14B9CD6', 'Competition Kit')
	AddTextEntry('0xB15DFDDC', 'Carb. Race Wing W/ Trunk Lip')
	AddTextEntry('0xB16E55C9', 'SN Purple Compass Tee')
	AddTextEntry('0xB17C2678', 'Teal Broker Cap')
	AddTextEntry('0xB30EADD0', 'Cubic Le Chien Parka')
	AddTextEntry('0xB31C1B53', 'Dart')
	AddTextEntry('0xB31E37BC', 'Chocolate Pocket Jacket')
	AddTextEntry('0xB32C68E1', 'Red FB Waterproof')
	AddTextEntry('0xB34A35B5', 'Walnut Aviators')
	AddTextEntry('0xB41D0512', 'Pink Vinewood Wide Pants')
	AddTextEntry('0xB44D3992', 'Floral Leather Fur')
	AddTextEntry('0xB52B1B9D', 'SC Broker Print Tee')
	AddTextEntry('0xB55F9AD7', 'Green Deep Shades')
	AddTextEntry('0xB61F1E8F', 'Secondary Roof')
	AddTextEntry('0xB64AFBBA', 'Fender Chrome Classic Mirrors')
	AddTextEntry('0xB64B95FC', 'Latte Pocket Jacket')
	AddTextEntry('0xB80A8186', 'White Baroque Cocktail Dress')
	AddTextEntry('0xB82C4823', 'Twin Boxed Exhaust')
	AddTextEntry('0xB84AB3AE', 'Blue Joker')
	AddTextEntry('0xB85F5CB2', 'Gray Yeti Cap')
	AddTextEntry('0xB111A84A', 'White Broker Ornate Bomber')
	AddTextEntry('0xB267CF22', 'Black Sports Spoiler')
	AddTextEntry('0xB388CF1A', 'Leopard Güffy Spray Puffer')
	AddTextEntry('0xB415E980', 'Green FB Waterproof')
	AddTextEntry('0xB541CE47', 'Silver SASS Wrist Piece')
	AddTextEntry('0xB756E223', 'Carbon Trunk')
	AddTextEntry('0xB761B765', 'Stock Secondary Fenders')
	AddTextEntry('0xB786C9FA', 'You\'re Awful Tee')
	AddTextEntry('0xB800BF26', 'Purple Vine Aviators')
	AddTextEntry('0xB888DEB2', 'Black LS Diamond Cap')
	AddTextEntry('0xB923F681', 'Keeping It Real')
	AddTextEntry('0xB951FF81', 'Ubermacht')
	AddTextEntry('0xB954A639', 'Flames of Freedom')
	AddTextEntry('0xB2532CCA', 'Stars Fame or Shame Robe')
	AddTextEntry('0xB2950D1D', 'Cracked 8F')
	AddTextEntry('0xB4911AF6', 'Ocelot Stripe')
	AddTextEntry('0xB6043B17', 'Secondary Skirts')
	AddTextEntry('0xB7752E40', 'Secondary Color Skirt')
	AddTextEntry('0xB7972E86', 'Rimm Paint')
	AddTextEntry('0xB8452EF1', 'Roadster Rear')
	AddTextEntry('0xB8752D00', 'THE SHOP')
	AddTextEntry('0xB10567F9', 'White Bigness Bomber')
	AddTextEntry('0xB17055BD', 'Carbon Custom Diffuser')
	AddTextEntry('0xB38254C1', 'Black The Diamond Cap')
	AddTextEntry('0xB58692AF', 'Red Camo SN Sweater')
	AddTextEntry('0xB83410EF', 'PHOTO FINISH')
	AddTextEntry('0xB183934A', 'The Diamond Classic Tee')
	AddTextEntry('0xB237399A', 'Black Racer Stripes')
	AddTextEntry('0xB309680B', 'Carbon Vented Hood')
	AddTextEntry('0xB724532A', 'Bumper Extension')
	AddTextEntry('0xB2788231', 'Hearts Earrings')
	AddTextEntry('0xB3855666', 'Carbon Race Splitter')
	AddTextEntry('0xB8682348', 'White SC Broker Cap')
	AddTextEntry('0xBA01AE27', 'Teal Posies Fitted')
	AddTextEntry('0xBA4FE8FE', 'Mustard Bigness Waterproof')
	AddTextEntry('0xBA9ADDC8', 'Pink Floral Cocktail Dress')
	AddTextEntry('0xBA22F691', 'Blue FB Waterproof')
	AddTextEntry('0xBA51A3AB', 'Red Ancient Large Shirt')
	AddTextEntry('0xBA823D53', 'Modern Media')
	AddTextEntry('0xBA14142F', 'Carbon Roof Scoop')
	AddTextEntry('0xBAA33B8D', 'Purple Painted Large Shirt')
	AddTextEntry('0xBAD41DC3', 'Green High Roller Dress')
	AddTextEntry('0xBAE776E0', 'Custom Chrome Grille')
	AddTextEntry('0xBAEAFA03', 'Mission II Tee')
	AddTextEntry('0xBB087688', 'Teal Perseus Wide Pants')
	AddTextEntry('0xBB393B02', 'Brown Prairie Large Shirt')
	AddTextEntry('0xBB6292A8', 'Padded Cage w/ Colored Seats')
	AddTextEntry('0xBBA6CB82', 'Woodland Yeti Puffer')
	AddTextEntry('0xBBA49CD4', 'Primary Painted Stock')
	AddTextEntry('0xBBB32BE1', 'Black Stripes')
	AddTextEntry('0xBBBD6064', 'Lampadati Racing')
	AddTextEntry('0xBBD72328', 'Power Metal')
	AddTextEntry('0xBBE91B5B', 'Secondary GT Skirt')
	AddTextEntry('0xBBFB0186', 'Bodywork Mounted Spoiler')
	AddTextEntry('0xBC014C75', 'White The Diamond Cap')
	AddTextEntry('0xBC68E5F8', 'Black Blagueurs Waves Sweater')
	AddTextEntry('0xBC98C2CE', 'Red FB Slipper Loafers')
	AddTextEntry('0xBC193D9A', 'Twin Wedged Splitter')
	AddTextEntry('0xBC2351C6', 'Black Broker Puffer')
	AddTextEntry('0xBC839637', 'Blue Lazerforce Wide Pants')
	AddTextEntry('0xBCACE3AC', 'Carbon Sports Spoiler')
	AddTextEntry('0xBCB932F6', 'Secondary Painted Skirt')
	AddTextEntry('0xBCCD2A06', 'White Deep Shades')
	AddTextEntry('0xBCD88D2B', 'Green Vines Parka')
	AddTextEntry('0xBCDB083E', 'Pink Patterned Wide Pants')
	AddTextEntry('0xBCE3C731', 'Carbon GT Splitter')
	AddTextEntry('0xBCFEEE96', 'Radial Exhausts')
	AddTextEntry('0xBD056583', 'Vysser are the kind of small, artisanal manufacturer who are prepared to think outside the box. The design blueprints for the Neo drew their inspiration from the aerodynamics of a diving falcon, the composure of a ballet dancer, the curve of a suggestively raised eyebrow, and the assertiveness of a cluster bomb. This is the kind of pedigree you need.')
	AddTextEntry('0xBD074F3A', 'Weekend Warrior')
	AddTextEntry('0xBD1F4A44', 'Secondary Ram Bar')
	AddTextEntry('0xBD3409A8', 'Fender Painted Round Mirrors')
	AddTextEntry('0xBD5415E2', 'Navy Color Sweater')
	AddTextEntry('0xBD30832E', 'Silver Crowex Époque')
	AddTextEntry('0xBD84241B', 'Queens High Roller Dress')
	AddTextEntry('0xBDA11DFC', 'Blagueurs Camo Box Hoodie')
	AddTextEntry('0xBDB7969E', 'Bravado Racing')
	AddTextEntry('0xBDDF0B70', 'Carbon Wide Spoiler')
	AddTextEntry('0xBDF59EE6', 'Decem Exhausts')
	AddTextEntry('0xBE024D19', 'Aggressive Spoiler')
	AddTextEntry('0xBE0301C7', 'Race Fogs')
	AddTextEntry('0xBE4C9E58', 'Short Ram Pipes')
	AddTextEntry('0xBE6A7946', 'Gray Blagueurs Waves Sweater')
	AddTextEntry('0xBE6C9B83', 'Street Crimes Yokels Tee')
	AddTextEntry('0xBE8FDA48', 'Street Crimes Red Gangs Tee')
	AddTextEntry('0xBE765A1F', 'King of Diamonds')
	AddTextEntry('0xBE4996E6', 'Secondary Bed Bar Rack')
	AddTextEntry('0xBE29063E', 'Gray The Diamond Hoodie')
	AddTextEntry('0xBEAF55E2', 'Gauntlet Vents')
	AddTextEntry('0xBEC8F941', 'Secondary Painted Accent')
	AddTextEntry('0xBEC1771F', 'Black SN Jersey')
	AddTextEntry('0xBECD6ED8', 'Classic Visor')
	AddTextEntry('0xBEDEA0B8', 'Street Set Up')
	AddTextEntry('0xBEEA776D', 'White FB Manor Jersey')
	AddTextEntry('0xBF07AD1B', 'Blue Sunset Large Shirt')
	AddTextEntry('0xBF2AAEDD', 'Black SC Broker Cap')
	AddTextEntry('0xBF3C1963', 'Spitting Fire')
	AddTextEntry('0xBF9FD03B', 'Wild Leather Fur')
	AddTextEntry('0xBF11C53C', 'Gold Enduring Watch')
	AddTextEntry('0xBF25EEF8', 'Blue Oh No He Didn\'t! Tee')
	AddTextEntry('0xBF94DC00', 'Race Livery')
	AddTextEntry('0xBF595BF5', 'V8')
	AddTextEntry('0xBF1012A1', 'Open II')
	AddTextEntry('0xBF4312CD', 'Street Vented Carbon Bumper')
	AddTextEntry('0xBFBE0209', 'The Jolly Joker')
	AddTextEntry('0xBFC3C5AE', 'Red Broker Ornate Bomber')
	AddTextEntry('0xBFE84765', 'AKAN Records')
	AddTextEntry('0xC018D6AA', '1ST')
	AddTextEntry('0xC0249975', 'Primary Bull Bar')
	AddTextEntry('0xC02FC4E4', 'Black Rim Tint Aviators')
	AddTextEntry('0xC03720DF', 'King of Spades')
	AddTextEntry('0xC0539EBD', 'Red Chips Earrings')
	AddTextEntry('0xC05C2E97', 'EXPERIENCE DECADENCE')
	AddTextEntry('0xC07A48A7', 'Red Le Chien Parka')
	AddTextEntry('0xC0816255', 'Roulette Crowex Époque')
	AddTextEntry('0xC0893318', 'White SC Broker Silk Robe')
	AddTextEntry('0xC08E119B', 'Cherries Mask')
	AddTextEntry('0xC09EE037', 'Primary Sunstrip')
	AddTextEntry('0xC0F5D36B', 'White Pocket Jacket')
	AddTextEntry('0xC1BC9FB3', 'Green Retro Sneakers')
	AddTextEntry('0xC1BE5474', 'Garland Leather Fur')
	AddTextEntry('0xC1CB7DA6', 'Red Broker Ornate Bomber')
	AddTextEntry('0xC1CEEF56', 'Secondary Color Hood')
	AddTextEntry('0xC1E2A09D', 'Black Vinewood Wide Pants')
	AddTextEntry('0xC1EC2E47', 'Custom Skirt')
	AddTextEntry('0xC1EED7DC', 'Flame Touched Exhausts')
	AddTextEntry('0xC2AD6054', 'Tan Le Chien Parka')
	AddTextEntry('0xC2C2A42F', 'Street Crimes Punks Tee')
	AddTextEntry('0xC2CB376A', 'Terroil Two-Tone')
	AddTextEntry('0xC2CF6FC9', 'Sports Spoiler')
	AddTextEntry('0xC2F22159', 'Black Cards High Roller Jacket')
	AddTextEntry('0xC3A10714', 'Yellow Sci-Fi Wide Pants')
	AddTextEntry('0xC3AD649D', 'Exposed Air Filters')
	AddTextEntry('0xC3D413BA', 'Twin Angled Titanium Exhaust')
	AddTextEntry('0xC4B6F72A', 'White The Diamond Cap')
	AddTextEntry('0xC4E0F254', 'Sand Tiled Cocktail Dress')
	AddTextEntry('0xC5B47E55', 'SN Pink Compass Tee')
	AddTextEntry('0xC6B7B8D9', 'White Stripes')
	AddTextEntry('0xC6BCEB34', 'An oasis of calm, wrapped in layers of sensuous delight, dusted with our patented mixture of nuance and sophistication, lovingly arranged on a bed of raw entitlement - all placed delicately into the lap of luxury. This is where you belong.')
	AddTextEntry('0xC6C0D1E7', 'Truffade Spoiler')
	AddTextEntry('0xC6EA61A1', 'Choose Your Side Tee')
	AddTextEntry('0xC6F6B378', 'Street')
	AddTextEntry('0xC7B3804D', 'Red Fame or Shame Kronos')
	AddTextEntry('0xC7C1BFC6', 'Big Dix Tee')
	AddTextEntry('0xC7E55211', 'Locust')
	AddTextEntry('0xC7F9F7FC', 'Teal Broker Puffer')
	AddTextEntry('0xC8B40B77', 'Teal SC Broker Bomber')
	AddTextEntry('0xC8B56515', 'Silver Kronos Pulse')
	AddTextEntry('0xC8D4121F', 'Black Perseus Wide Pants')
	AddTextEntry('0xC8E3B386', 'Dual Filter / No Hood')
	AddTextEntry('0xC9C65844', 'BEGIN')
	AddTextEntry('0xC19D682D', 'Black Stripe w/ Black Vents')
	AddTextEntry('0xC23DB390', 'Spades Earrings')
	AddTextEntry('0xC25E4323', 'Blade Rear')
	AddTextEntry('0xC27B15BA', 'Primary Vented Hood')
	AddTextEntry('0xC31DF3DC', 'White LS Diamond Cap')
	AddTextEntry('0xC37C4D83', 'Deep Inset Hood')
	AddTextEntry('0xC41FC61C', 'Navy Color Sweater')
	AddTextEntry('0xC46F8C7E', 'Red Güffy Waterproof')
	AddTextEntry('0xC55D4A0A', 'Invade and Persuade Green Tee')
	AddTextEntry('0xC77A1CA4', 'Twin Turbo w/ Air Filters')
	AddTextEntry('0xC84FC4F6', 'Alt Track Day')
	AddTextEntry('0xC96D7B6B', 'Mustard Bigness Waterproof')
	AddTextEntry('0xC433DD98', 'Primary Sectioned Grilles')
	AddTextEntry('0xC441CDD7', 'Radial Exhausts')
	AddTextEntry('0xC526B1D4', 'Gold Tint Aviators')
	AddTextEntry('0xC558BFCC', 'Vents GT I')
	AddTextEntry('0xC611D311', 'Carbon Cowl Hood')
	AddTextEntry('0xC646D626', 'Green FB Slipper Loafers')
	AddTextEntry('0xC777EE2D', 'Street Carbon Skirt')
	AddTextEntry('0xC785B921', 'Secondary Full Cage')
	AddTextEntry('0xC987D45F', 'Gray Pattern Retro Sneakers')
	AddTextEntry('0xC1255D44', 'Black Le Chien Parka')
	AddTextEntry('0xC2573EED', 'Ram Bar')
	AddTextEntry('0xC3348F7F', 'Half Painted Stripe')
	AddTextEntry('0xC4590A79', 'Contrast Camo Leather Fur')
	AddTextEntry('0xC6555F67', 'Roof Luggage')
	AddTextEntry('0xC7093E2A', 'Aqua Deep Shades')
	AddTextEntry('0xC26039DB', 'Black SC Broker Knee Shorts')
	AddTextEntry('0xC61692E5', 'Tuner Kit')
	AddTextEntry('0xC69826EB', 'Triple Intake')
	AddTextEntry('0xC91525D7', 'Blue Floral High Roller Jacket')
	AddTextEntry('0xC143847F', 'Hood w/ Extra Vents')
	AddTextEntry('0xC188181A', 'Primary Super Spoiler')
	AddTextEntry('0xC374588F', 'Scooped Hood')
	AddTextEntry('0xC410607F', 'Piped Step')
	AddTextEntry('0xC738952D', 'Don\'t be fooled. Roulette, blackjack, Three Card Poker - at The Diamond, these aren\'t games. Every card dealt, every spin of the wheel, every polished quip, every gasp of the crowd, every delusion of grandeur: this is art.')
	AddTextEntry('0xC985492B', 'Ram Plate')
	AddTextEntry('0xC1266606', 'Painted Vortex Generators')
	AddTextEntry('0xC3079971', 'Grayscale SN Parka')
	AddTextEntry('0xC3118662', 'Blue The Diamond Hoodie')
	AddTextEntry('0xC6593702', 'Rally Intercooler')
	AddTextEntry('0xC9908082', 'Jack of Clubs')
	AddTextEntry('0xCA085099', 'MORE INFO')
	AddTextEntry('0xCA8DB686', 'Triple Intake Bugcatcher')
	AddTextEntry('0xCA6011D9', 'We know what you\'re thinking. Another mid-seventies brick. But think about it for a moment. A brick is only slow if you don\'t throw it right. And does a hollowed-out, turbo-charged brick really sound like it\'s that difficult to throw? That\'s the spirit. Batter up.')
	AddTextEntry('0xCAA43E7E', 'POP')
	AddTextEntry('0xCB52A091', 'Blue The Diamond Hoodie')
	AddTextEntry('0xCB82EED0', 'Triple Radial Boxed Exhausts')
	AddTextEntry('0xCB103B6F', 'Classic w/ Secondary Vents')
	AddTextEntry('0xCB700C6D', 'Rusty Hood')
	AddTextEntry('0xCB7012B4', 'Silver Crowex Rond')
	AddTextEntry('0xCB642637', 'Nebula Turbo')
	AddTextEntry('0xCBA4C99E', 'Yellow FB Slipper Loafers')
	AddTextEntry('0xCBC440BE', 'LATIN')
	AddTextEntry('0xCBE36163', 'Blue FB Slipper Loafers')
	AddTextEntry('0xCC063C64', 'Red Ancient Large Shirt')
	AddTextEntry('0xCC083AE6', 'Purple Painted Knee Shorts')
	AddTextEntry('0xCC0849F0', 'Fukaru')
	AddTextEntry('0xCC5ACF96', 'Race Hood')
	AddTextEntry('0xCC544BFC', 'Bolted Fenders')
	AddTextEntry('0xCC4094F2', 'Black Blagueurs Waves Sweater')
	AddTextEntry('0xCC495036', 'Red SC Broker Bomber')
	AddTextEntry('0xCCBD3738', 'Bespoke Grille')
	AddTextEntry('0xCCC8489C', 'Green Sunset Large Shirt')
	AddTextEntry('0xCCCDBCD1', 'Single Vent Secondary')
	AddTextEntry('0xCCD48904', 'Painted Race Splitter')
	AddTextEntry('0xCD2D9B70', 'Grinder Grille')
	AddTextEntry('0xCD4E838E', 'eCola')
	AddTextEntry('0xCD7DAC6C', 'Red Rose Cocktail Dress')
	AddTextEntry('0xCD726F19', 'Organic Perseus Puffer')
	AddTextEntry('0xCD558175', 'PURCHASE SUCCESSFUL!')
	AddTextEntry('0xCDBB619D', 'Teal SC Broker Bomber')
	AddTextEntry('0xCDBBC960', 'Secondary Bumper & Splitter')
	AddTextEntry('0xCDC5DEA4', 'Red Joker')
	AddTextEntry('0xCDF73679', 'Mid Level Spoiler Wing')
	AddTextEntry('0xCE0A78EB', 'White Double Stripe')
	AddTextEntry('0xCE0BF879', 'Chrome Classic Grille')
	AddTextEntry('0xCE0CAF93', 'White Baroque Parka')
	AddTextEntry('0xCE5EBA47', 'Carbon Big Wing')
	AddTextEntry('0xCE797DBD', 'Cage & Drag Seats')
	AddTextEntry('0xCEB275B8', 'Race Exhaust')
	AddTextEntry('0xCEC4BAB9', 'Teal SC Broker Wide Pants')
	AddTextEntry('0xCED3DA59', 'Carbon GT Skirt')
	AddTextEntry('0xCEE21D9B', 'It\'s not just a palace. It\'s your palace. If you want a private Spa, you can have it. Media Room? Consider it done. Your own Bar and Party Hub, Private Dealer and Office? Just say the word: Diamond.')
	AddTextEntry('0xCEF7EA50', 'FEE:')
	AddTextEntry('0xCEF64CF3', 'Monkey Business Tee')
	AddTextEntry('0xCF1EB344', 'Primary Painted Tuner')
	AddTextEntry('0xCF86FC40', 'King of Clubs')
	AddTextEntry('0xCF871D4A', 'Grapes Mask')
	AddTextEntry('0xCF357442', 'Gray Yeti Cap')
	AddTextEntry('0xCFCE48B9', 'Wheelie Bar & Chute')
	AddTextEntry('0xCFFAF0ED', 'Spotted Leather Fur')
	AddTextEntry('0xCFFC8B89', 'Silver Fame or Shame Mics')
	AddTextEntry('0xD014EB36', 'Secondary Street Spoiler')
	AddTextEntry('0xD01821F7', 'Floral Leather Fur')
	AddTextEntry('0xD021B107', 'Secondary Vented Hood')
	AddTextEntry('0xD04E49AF', 'Dice High Roller Dress')
	AddTextEntry('0xD065C754', 'Orange The Diamond Cap')
	AddTextEntry('0xD0B65B90', 'Navy Posies Fitted')
	AddTextEntry('0xD0CC5517', 'The Impotent Rage')
	AddTextEntry('0xD1DF13AA', 'Carbon Slatted Grille')
	AddTextEntry('0xD1EE7D5C', 'Teal Broker Puffer')
	AddTextEntry('0xD1F8429A', 'Street Crimes Hoods Tee')
	AddTextEntry('0xD2AB8DC5', 'White Fleur Cocktail Dress')
	AddTextEntry('0xD2DA5944', 'Flywheels Garage')
	AddTextEntry('0xD3A0B2D9', 'Carbon Roof')
	AddTextEntry('0xD3CE8BB7', 'Gold Fame or Shame Mics')
	AddTextEntry('0xD3DD6F4F', 'Redwood Cigarettes')
	AddTextEntry('0xD4B3E7CE', 'Magnum Rear')
	AddTextEntry('0xD4C77D87', 'Secondary Color Roof')
	AddTextEntry('0xD4FEC967', 'Orange SN Bigness Hoodie')
	AddTextEntry('0xD5B6C750', 'Prim. w/ Colored Seats')
	AddTextEntry('0xD5DB2B88', 'Blue Sci-Fi Wide Pants')
	AddTextEntry('0xD5E37C7C', 'Gold Kronos Quad')
	AddTextEntry('0xD6AF1A80', 'Broker Detail Sweater')
	AddTextEntry('0xD6B3FEE7', 'Ash Pocket Jacket')
	AddTextEntry('0xD6B7A352', 'Side Mitered Exhausts')
	AddTextEntry('0xD6B52FF7', 'Rose & Aces')
	AddTextEntry('0xD6EAE5CF', 'BAR AND PARTY HUB')
	AddTextEntry('0xD6F6BD9F', 'Primary Low Mount Spoiler')
	AddTextEntry('0xD6F680DC', 'Vortex Generators')
	AddTextEntry('0xD6FE1B0A', 'Swirl High Roller Jacket')
	AddTextEntry('0xD7A6CC25', 'Green Sci-Fi Wide Pants')
	AddTextEntry('0xD7A445A3', 'SINGLE EVENT')
	AddTextEntry('0xD7A870A0', 'White Pattern Retro Sneakers')
	AddTextEntry('0xD7C4EED9', 'Street Crimes Color Gangs Tee')
	AddTextEntry('0xD7D7A3E9', 'GT Wing')
	AddTextEntry('0xD7DC310C', 'Green Bigness Waterproof')
	AddTextEntry('0xD7F58516', 'Bravado Billboard')
	AddTextEntry('0xD8A49D05', 'Dual Filter Blower')
	AddTextEntry('0xD8A20542', 'Chrome Exhausts')
	AddTextEntry('0xD8AC1D9D', 'Strawberry Mask')
	AddTextEntry('0xD8B9618A', 'Pink Urban Deep Shades')
	AddTextEntry('0xD9A2ACE1', 'Black Bigness Jersey')
	AddTextEntry('0xD9D8FCDB', 'Secondary Race Bumper')
	AddTextEntry('0xD9F456A2', 'Gray Yeti LS 19 Hoodie')
	AddTextEntry('0xD11D1BE6', 'MEMBERSHIP')
	AddTextEntry('0xD12AEAF7', 'Stock Carbon Fenders')
	AddTextEntry('0xD16E3C08', 'Secondary Bull Bar')
	AddTextEntry('0xD18D49D7', 'EVENT IN PROGRESS')
	AddTextEntry('0xD20C86B8', 'Low Level Spoiler')
	AddTextEntry('0xD23DA6E1', 'The Impotent Rage')
	AddTextEntry('0xD35D4145', 'Drift Wing')
	AddTextEntry('0xD37C942F', 'Green High Roller Jacket')
	AddTextEntry('0xD43F1FD3', 'Redwood Classic')
	AddTextEntry('0xD53DFC22', 'Twin Scooped Hood')
	AddTextEntry('0xD54E7A9F', 'Side & Fender Mirrors')
	AddTextEntry('0xD57A31B0', 'If life is a game, this is the jackpot. Here, your dreams are reality, and your reality is a dream. Here, every whim can be satisfied, every fantasy fulfilled. Here, there are no restrictions, no limitations, no windows, no clocks, and no clearly labelled exits. Welcome to The Diamond standard.')
	AddTextEntry('0xD58AB727', 'Twin Titanium Exhaust')
	AddTextEntry('0xD60A606B', 'Two Tone Augury')
	AddTextEntry('0xD65E6010', 'Flared Fenders')
	AddTextEntry('0xD66ED81C', 'Smooth High Roller Waistcoat')
	AddTextEntry('0xD67E73DE', 'Cowl Hood')
	AddTextEntry('0xD75D766D', 'Yellow Vines Parka')
	AddTextEntry('0xD82C55A7', 'Secondary Stripe')
	AddTextEntry('0xD86A0247', 'Krieger')
	AddTextEntry('0xD87B4D85', 'Red Broker Wide Pants')
	AddTextEntry('0xD93E645C', 'Shiny Wasabi Kitty')
	AddTextEntry('0xD98F5619', 'Angular Exits')
	AddTextEntry('0xD143DC66', 'Metal Cage')
	AddTextEntry('0xD155B72C', 'Racing')
	AddTextEntry('0xD188BDFC', 'Digital Sprunk')
	AddTextEntry('0xD248F3A0', 'Carbon Lip Skirts')
	AddTextEntry('0xD376BBF7', 'Bolted Dovetail Spoiler')
	AddTextEntry('0xD564AB08', 'Gray The Diamond Hoodie')
	AddTextEntry('0xD602C5C0', 'Double Vented')
	AddTextEntry('0xD695C664', 'A private table for blackjack and Three Card Poker with the best view and the most deferential croupier in town.')
	AddTextEntry('0xD757D97D', 'Zorrusso')
	AddTextEntry('0xD793F74B', 'White SC Broker Silk Robe')
	AddTextEntry('0xD965DA52', 'Herringbone Aviators')
	AddTextEntry('0xD1720EB2', 'Cyan Paint Cocktail Dress')
	AddTextEntry('0xD1862FE9', 'Redwood Racing')
	AddTextEntry('0xD3953A8C', 'Peach Fade SN Parka')
	AddTextEntry('0xD4912D5F', 'The 70s Called')
	AddTextEntry('0xD5963F73', 'Street Vented Bumper')
	AddTextEntry('0xD6905C28', 'Craps Large Shirt')
	AddTextEntry('0xD7244EB9', 'King of Hearts')
	AddTextEntry('0xD7538FD5', 'Black Crowex Époque')
	AddTextEntry('0xD7854A7F', 'Queens High Roller Jacket')
	AddTextEntry('0xD27225CB', 'Chrome Oval Tip')
	AddTextEntry('0xD75364C7', 'Bull Bar III')
	AddTextEntry('0xD82401C7', 'Gray Pocket Jacket')
	AddTextEntry('0xD477485C', 'SELECT HORSE')
	AddTextEntry('0xD545343E', 'Classic Spoiler')
	AddTextEntry('0xD724996F', 'Red The Diamond Resort Tee')
	AddTextEntry('0xD3469033', 'Exposed Chrome Grille')
	AddTextEntry('0xD7569700', 'Teal SC Broker Cap')
	AddTextEntry('0xD8057343', 'CLOSE')
	AddTextEntry('0xD8545213', 'Oval Intake / No Hood')
	AddTextEntry('0xD9072169', 'Carbon Performance Splitter')
	AddTextEntry('0xDA3950AC', 'Blue Retro Sneakers')
	AddTextEntry('0xDA7011B2', 'Narc Racing')
	AddTextEntry('0xDA855032', 'Sec. Race Wing W/ Trunk Lip')
	AddTextEntry('0xDAD25763', 'Large Filter Blower')
	AddTextEntry('0xDAEEB82C', 'Mauve Bigness Waterproof')
	AddTextEntry('0xDAF46FE7', 'Magnum')
	AddTextEntry('0xDAF528D2', 'Bigness Leopard Tee')
	AddTextEntry('0xDB5E7D7D', 'Roulette Enduring Watch')
	AddTextEntry('0xDB72AC72', 'Because Drift Car')
	AddTextEntry('0xDB807A19', 'Green Joker')
	AddTextEntry('0xDB4993C3', 'Invade and Persuade Green Tee')
	AddTextEntry('0xDBC05B09', 'Primary Skirt')
	AddTextEntry('0xDBC448F9', 'White Rose Cocktail Dress')
	AddTextEntry('0xDBD6CBF4', 'Street Carbon Bumper')
	AddTextEntry('0xDBD8B966', 'Blood Money')
	AddTextEntry('0xDC0F13C2', 'Duster')
	AddTextEntry('0xDC1F8C39', 'Upward Angled Exhausts')
	AddTextEntry('0xDC51BF5B', 'Carbon Roof Spoiler')
	AddTextEntry('0xDC61FD50', 'Large Filter Blower')
	AddTextEntry('0xDCB8E878', 'Blue Team Tracey Tee')
	AddTextEntry('0xDCE5112A', 'Mk1 Secondary Painted V8')
	AddTextEntry('0xDCFD83F9', 'Royalty Crowex Rond')
	AddTextEntry('0xDD9C44A8', 'Carbon Splitter')
	AddTextEntry('0xDD9CEA45', 'Red Chips Large Shirt')
	AddTextEntry('0xDD55CE0D', 'Blue SN Parka')
	AddTextEntry('0xDD72FF6A', 'White Rim Tint Aviators')
	AddTextEntry('0xDD510E4C', 'Spade Kronos Pulse')
	AddTextEntry('0xDD95327F', 'Nokota')
	AddTextEntry('0xDDC2D99B', 'Black Chips Earrings')
	AddTextEntry('0xDDE80AF4', 'Dot Fade Aviators')
	AddTextEntry('0xDDE99F90', 'Roof Wedges')
	AddTextEntry('0xDDEE991F', 'Oval Intake Bugcatcher')
	AddTextEntry('0xDE06E543', 'NATURAL')
	AddTextEntry('0xDE1A8510', 'Dual Long Rounded Exhausts')
	AddTextEntry('0xDE4FEE73', 'Sport Stripes')
	AddTextEntry('0xDE7D771E', 'Mocha Posies Fitted')
	AddTextEntry('0xDE7F9BDE', 'Dual Twin Exhausts')
	AddTextEntry('0xDE319D25', 'Cage & Carbon Seats')
	AddTextEntry('0xDE865059', 'Black Stripes')
	AddTextEntry('0xDEDB63E7', 'Tartan High Roller Pants')
	AddTextEntry('0xDEF83E67', 'Blue P Wide Pants')
	AddTextEntry('0xDF0239D8', 'Gold Crowex Rond')
	AddTextEntry('0xDF7CC326', 'Mission III Tee')
	AddTextEntry('0xDF7EEA77', 'Cherenkov Strawberry')
	AddTextEntry('0xDF17CAC6', 'Secondary Arches')
	AddTextEntry('0xDF443F9D', 'Shark Grille')
	AddTextEntry('0xDF480F8B', 'Gray Spotted Leather Fur')
	AddTextEntry('0xDFBC984B', 'Pink Pattern Loose Bow Tie')
	AddTextEntry('0xDFCD97E7', 'Mk2 Painted V8')
	AddTextEntry('0xE006AD6E', 'Jack of Hearts')
	AddTextEntry('0xE01CEF71', 'Mono Deep Shades')
	AddTextEntry('0xE043C16E', 'Titanium Tips')
	AddTextEntry('0xE05191BB', 'Primary Aggressive Spoiler')
	AddTextEntry('0xE0652938', 'Cyan E Cocktail Dress')
	AddTextEntry('0xE06A4695', 'No Bumper & Race Intercooler')
	AddTextEntry('0xE0844845', 'White Fame or Shame Robe')
	AddTextEntry('0xE0954A64', 'Adorned Hoodie')
	AddTextEntry('0xE09A0CB2', 'Gray Yeti Puffer')
	AddTextEntry('0xE0A5AB9E', 'Patterned Blagueurs Large Shirt')
	AddTextEntry('0xE0A191F8', 'Silver Kronos Quad')
	AddTextEntry('0xE0B0A040', 'Tin Can Exhausts')
	AddTextEntry('0xE0BA8933', 'Green Camo Blagueurs Parka')
	AddTextEntry('0xE0EA9485', 'Bull Bars')
	AddTextEntry('0xE0FA4BA8', 'Carbon Top Classic Spoiler')
	AddTextEntry('0xE1A2F85C', 'Red Baroque Knee Shorts')
	AddTextEntry('0xE2A73675', 'Gold Enduring Watch')
	AddTextEntry('0xE2C3C549', 'Extended Splitter')
	AddTextEntry('0xE2D39CDE', 'Red Flying Bravo Cap')
	AddTextEntry('0xE2DFB4A1', 'Purple Floral High Roller Dress')
	AddTextEntry('0xE2E3199C', 'Silver Fifty Kronos Pulse')
	AddTextEntry('0xE3CE695B', 'Carbon Smoothed Hood')
	AddTextEntry('0xE4A9E9C4', 'King of Clubs')
	AddTextEntry('0xE4B4C305', 'White Bigness Jersey')
	AddTextEntry('0xE4C5B4B1', 'Black The Diamond Resort Tee')
	AddTextEntry('0xE4C49C8A', 'Carbon Hexa Vented Hood')
	AddTextEntry('0xE4D04DDF', 'Black Deep Shades')
	AddTextEntry('0xE4EAD2EB', 'White Vapid Double Stripe')
	AddTextEntry('0xE5A9B8F7', 'Red The Diamond Cap')
	AddTextEntry('0xE5A542A3', 'Twin White Stripes')
	AddTextEntry('0xE5A5339D', 'Black SC Broker Cap')
	AddTextEntry('0xE5D57AB2', 'Black Ancient Large Shirt')
	AddTextEntry('0xE5FB4EAA', 'Licquorice Waterproof')
	AddTextEntry('0xE6C08EAB', 'England. 1956. In just a few years\' time, Weeny are going to produce the Issi, and the automotive equivalent of a quadruple shot low fat half caff flat white is going to change the world forever. But for now, they\'re still the world\'s most respected manufacturer of middle-of-the-road, middle-class, middle-income, about-to-get-fired-from-middle-management cars. The Dynasty is their magnum opus. And in 1957, they\'re going to sell the design, and the subcontinent is never going to be the same again...')
	AddTextEntry('0xE6C7051D', 'White Bigness Bomber')
	AddTextEntry('0xE6FECDCF', 'Green Sci-Fi Wide Pants')
	AddTextEntry('0xE7BE89A0', 'Black Opulent Fitted')
	AddTextEntry('0xE7BF4FBD', 'Red The Diamond Hoodie')
	AddTextEntry('0xE7E0164A', 'Bulkhead Hood')
	AddTextEntry('0xE7E29338', 'Red SC Broker Cap')
	AddTextEntry('0xE7EF6E88', 'Street Crimes Bikers Tee')
	AddTextEntry('0xE8A18805', 'Black E Fitted')
	AddTextEntry('0xE8AF8F3B', 'Teal Color Sweater')
	AddTextEntry('0xE8B478EF', 'Purple Vine Aviators')
	AddTextEntry('0xE8BCCD4D', 'Black Crowex Rond')
	AddTextEntry('0xE8C7BEB1', 'SC Broker Sweater')
	AddTextEntry('0xE8C79870', 'Vented Hood')
	AddTextEntry('0xE9A5B3EB', 'White Pattern Retro Sneakers')
	AddTextEntry('0xE9BDEF5E', 'Prim. Padded w/ Colored Seats')
	AddTextEntry('0xE12FB39C', 'Meshed Visor')
	AddTextEntry('0xE13F5CD1', 'Secondary Roll Bars')
	AddTextEntry('0xE17FBF70', 'Squash Squares Sweater')
	AddTextEntry('0xE26AB065', 'Gold Fame or Shame Mics')
	AddTextEntry('0xE33C8D2B', 'Orange Camo Blagueurs Parka')
	AddTextEntry('0xE37CFA89', 'Blacktop Burner')
	AddTextEntry('0xE39A4ED8', 'Vented Roof')
	AddTextEntry('0xE47C416D', 'Purple Baroque Parka')
	AddTextEntry('0xE55D0F9C', 'Blue Color Bomber')
	AddTextEntry('0xE58D2C48', 'Gold Crowex Époque')
	AddTextEntry('0xE71EA7BC', 'Yellow FB Puffer')
	AddTextEntry('0xE72B3F98', 'Expansive Exhaust')
	AddTextEntry('0xE74DBBD1', 'Knit High Roller Jacket')
	AddTextEntry('0xE77E00DB', 'Redwood Cigarettes')
	AddTextEntry('0xE85D1F9F', 'Chrome Angled Headers')
	AddTextEntry('0xE90C9F8E', 'Carbon Race Splitter')
	AddTextEntry('0xE94DFBF4', 'Slate Pocket Jacket')
	AddTextEntry('0xE98A6D9F', 'Tuner Wing')
	AddTextEntry('0xE98B4F87', 'Squash Comic Sweater')
	AddTextEntry('0xE99AFB28', 'Twin White Stripes')
	AddTextEntry('0xE137F04E', 'EXPERIENCE EXCELLENCE')
	AddTextEntry('0xE198BE83', 'WAYPOINT SET')
	AddTextEntry('0xE330ECEA', 'Blue LS Diamond Cap')
	AddTextEntry('0xE372AD4B', 'Single Filter Blower')
	AddTextEntry('0xE411EF29', 'The open-top, two-seater Locust pedigree goes all the way back to \'69, and this is what you get after forty years of track testing: no roof, no windscreen, no windows, no compromises and no interest in your personal safety. If you ever wondered what it\'s like to drive around in a logical conclusion, this is your chance to find out.')
	AddTextEntry('0xE573FD38', 'Carbon Roof')
	AddTextEntry('0xE577F55E', 'Secondary Custom Skirt')
	AddTextEntry('0xE587E7E7', 'Gray Lazerforce Wide Pants')
	AddTextEntry('0xE668E846', 'Cash High Roller Jacket')
	AddTextEntry('0xE680D132', 'Invade and Persuade Invader Tee')
	AddTextEntry('0xE742F13F', 'Yeti Heat Hoodie')
	AddTextEntry('0xE761FD73', 'FlatLine')
	AddTextEntry('0xE774DF46', 'Carbon Roof')
	AddTextEntry('0xE817E391', 'Black Baroque Parka')
	AddTextEntry('0xE836FABD', 'Chrome Grill')
	AddTextEntry('0xE857E9E8', 'Sometimes you need to take care of business, but there\'s no reason you should have to leave the lap of luxury to do it. All of our Offices come with a gun locker and a hidden safe as standard.')
	AddTextEntry('0xE894F678', 'Primary Stripe')
	AddTextEntry('0xE953BFB5', 'Sand High Roller Jacket')
	AddTextEntry('0xE3417E30', 'Vented Hood w/ Vents')
	AddTextEntry('0xE4408EC7', 'Blue Sci-Fi Large Shirt')
	AddTextEntry('0xE4725B3E', 'Black Painted Knee Shorts')
	AddTextEntry('0xE7186D9A', 'Purple SN Bigness Hoodie')
	AddTextEntry('0xE8213BFE', 'Primary Vented Hood')
	AddTextEntry('0xE8799E5C', 'Carbon Sports Splitter')
	AddTextEntry('0xE9255CA8', 'Squash 19 Hoodie')
	AddTextEntry('0xE9438A4C', 'Vented Side Panel')
	AddTextEntry('0xE23903C1', 'Street Crimes Red Gangs Tee')
	AddTextEntry('0xE25346F5', 'Green Bigness Waterproof')
	AddTextEntry('0xE27930C0', 'Pink SN Paint Cocktail Dress')
	AddTextEntry('0xE57615FC', 'Carbon GT Spoiler')
	AddTextEntry('0xE58434AE', 'Grated Grille')
	AddTextEntry('0xE165500B', 'Mission IV Tee')
	AddTextEntry('0xE239867F', 'The Diamond is everyone\'s playground. But only a select few can call it home. Invest in a Diamond Membership today and you\'ll be a lifelong partner in our project to meaningfully raise the standard of living for the one percent.~n~Please note that a membership does not allow you to play Casino games.')
	AddTextEntry('0xE324480F', 'Gray Spotted Leather Fur')
	AddTextEntry('0xE550775B', 'Paragon R')
	AddTextEntry('0xE672834A', 'Dummy label.')
	AddTextEntry('0xE755979F', 'Secondary Grille')
	AddTextEntry('0xE1071756', 'Carbon Camber Diffuser')
	AddTextEntry('0xE1963786', 'Gray Camo Waterproof')
	AddTextEntry('0xE1985793', 'Players can only bet on one horse per race. Bets are placed for the horse to win.')
	AddTextEntry('0xE5728109', 'Lifted Ram Bar')
	AddTextEntry('0xE6019342', 'Navy Loose Bow Tie')
	AddTextEntry('0xE7031029', 'Carbon Roadster Grille')
	AddTextEntry('0xE7842386', 'Blue LS Diamond Cap')
	AddTextEntry('0xE8962011', 'Ceramic Street Headers')
	AddTextEntry('0xE9460197', 'Yellow Chips Large Shirt')
	AddTextEntry('0xEA6A047F', 'Hellion')
	AddTextEntry('0xEA6A684E', 'White SC Broker Parka')
	AddTextEntry('0xEA7C050F', 'Green Urban Deep Shades')
	AddTextEntry('0xEA8E54F2', 'Pink Vinewood Wide Pants')
	AddTextEntry('0xEA575CFA', 'Choose from three expertly blended palettes, each designed by a team of aestheticians and psychiatrists to perfectly reflect the inner lives of our clientele.')
	AddTextEntry('0xEA835BBE', 'Roof Spoiler')
	AddTextEntry('0xEA330325', 'Bumper Delete')
	AddTextEntry('0xEB0DD02A', 'White Broker Ornate Bomber')
	AddTextEntry('0xEB8BAAC1', 'Silver Roulette Kronos Pulse')
	AddTextEntry('0xEB20AB6C', 'Dual White Stripes')
	AddTextEntry('0xEB33F9F0', 'Carbon GT Skirt')
	AddTextEntry('0xEB38C5CC', 'Painted Performance Splitter')
	AddTextEntry('0xEB61D950', 'Roll the Dice')
	AddTextEntry('0xEB95E09B', 'Primary Splitter')
	AddTextEntry('0xEB152D3C', 'Intercooler w/ Carbon Vents')
	AddTextEntry('0xEB637D90', 'There\'s no denying it. Something magical happened in the 80\'s. It\'s not just that their hair was more buoyant, their choruses catchier, their spandex tighter and their glutes perkier. It\'s that now they\'re all in their sixties, and their hair is still buoyant, their choruses are still catchy, their spandex is still tight, and their glutes are still perky. And whatever they\'ve been taking, the Zion Classic has been taking twice the dose.')
	AddTextEntry('0xEB662EAB', 'Performance Grille')
	AddTextEntry('0xEB830C24', 'Racer MK II')
	AddTextEntry('0xEB297382', 'Black Broker Wide Pants')
	AddTextEntry('0xEB314406', 'Blue LS Diamond Cap')
	AddTextEntry('0xEBA07193', 'Black Bed Bar Rack')
	AddTextEntry('0xEC5E397E', 'Cage & Sports Seats')
	AddTextEntry('0xEC38AB60', 'Carbon Vortex Generators')
	AddTextEntry('0xEC331F6E', 'Silver Enduring Watch')
	AddTextEntry('0xEC557BA5', 'Carbon Angular Exits')
	AddTextEntry('0xEC3023DE', 'Colors Yeti Puffer')
	AddTextEntry('0xEC64181D', 'Primary Color Skirt')
	AddTextEntry('0xECA6B6A3', 'S80RR')
	AddTextEntry('0xECBFEA43', 'Carbon Vented Hood')
	AddTextEntry('0xECF2EB56', 'Black Rose Cocktail Dress')
	AddTextEntry('0xED0CB74B', 'King of Spades')
	AddTextEntry('0xED0E374C', 'White Street Crimes Icons Tee')
	AddTextEntry('0xED1A2942', 'Secondary Carbon Lip Skirts')
	AddTextEntry('0xED5C2199', 'Carbon Vented Hood')
	AddTextEntry('0xED6DEE90', 'Camo High Roller Jacket')
	AddTextEntry('0xED8E7607', 'Works Racer')
	AddTextEntry('0xED17AB2A', 'Slate Perseus Leather Fur')
	AddTextEntry('0xED22F803', 'Painted Lip')
	AddTextEntry('0xED45A9E1', 'Open Grille')
	AddTextEntry('0xED56DB24', 'Blue Perseus Wide Pants')
	AddTextEntry('0xED79FFE8', 'Oodles of Doodles')
	AddTextEntry('0xED863358', 'Mk1 Painted V8')
	AddTextEntry('0xEDAA5CA8', 'Leopard Bigness Waterproof')
	AddTextEntry('0xEDABB2B7', 'Mk2 Secondary Painted V8')
	AddTextEntry('0xEDDE8AF4', 'Black Fame or Shame Shades')
	AddTextEntry('0xEDE62D4B', 'Slate Pocket Jacket')
	AddTextEntry('0xEE1F5DF3', 'Show Your Hand')
	AddTextEntry('0xEE5E104B', 'Old School Gasser')
	AddTextEntry('0xEE70B5B3', 'Blue Pattern Loose Bow Tie')
	AddTextEntry('0xEEB4E108', 'Red FB Waterproof')
	AddTextEntry('0xEED76466', 'Carbon Roof Scoop')
	AddTextEntry('0xEEF5D378', 'Carbon Hood')
	AddTextEntry('0xEF1CF968', 'Royal Tribute')
	AddTextEntry('0xEF1F87A7', 'Chocolate Pocket Jacket')
	AddTextEntry('0xEF10B21B', 'Carbon Big Bore Exhausts')
	AddTextEntry('0xEF312F59', 'Contrast Camo Leather Fur')
	AddTextEntry('0xEF457AC4', 'Violet Retro Sneakers')
	AddTextEntry('0xEF7599F5', 'Blade Extended')
	AddTextEntry('0xEF54474F', 'Painted Trim')
	AddTextEntry('0xEF80503D', 'Vintage Carso')
	AddTextEntry('0xEF850361', 'Black Ancient Large Shirt')
	AddTextEntry('0xEFAEB21D', 'Roof Rack')
	AddTextEntry('0xEFB9D6C8', 'AirCav')
	AddTextEntry('0xEFB37AA0', 'SN Hue Sweater')
	AddTextEntry('0xEFB227B2', 'Tackles Out!')
	AddTextEntry('0xEFC10780', 'White High Roller Dress')
	AddTextEntry('0xEFEDF43E', 'There are 100 horses. Each individual horse has fixed odds between Evens (1 to 1) and 30 to 1. The odds for each horse are always the same and never change between races. Horses with lower odds have a higher chance of winning compared to those with higher odds.')
	AddTextEntry('0xEFF2F42C', 'Street Bumper')
	AddTextEntry('0xEFFAACDE', 'Primary Competition Kit')
	AddTextEntry('0xEFFF28E2', 'Carbon Race Diffuser')
	AddTextEntry('0xF0153BCE', 'Duster Sports')
	AddTextEntry('0xF01BD2B7', 'THE CASINO')
	AddTextEntry('0xF020646D', 'Invade and Persuade Boxart Tee')
	AddTextEntry('0xF0206C52', 'Titanium Split Boxed Exhaust')
	AddTextEntry('0xF0337570', 'Secondary Super Spoiler')
	AddTextEntry('0xF0352F6C', 'Carbon Skirts')
	AddTextEntry('0xF081806C', 'Blue SN Bigness Hoodie')
	AddTextEntry('0xF0851749', 'Mixed Metals Ceaseless')
	AddTextEntry('0xF0973E70', 'Big Daddy Turbo')
	AddTextEntry('0xF0B3FEA7', 'Diamonds Earrings')
	AddTextEntry('0xF1AE5408', 'Monkey Business Tee')
	AddTextEntry('0xF1B5D807', 'Titanium Four Pointed Exhausts')
	AddTextEntry('0xF1B7E5BE', 'Apricot Bigness Waterproof')
	AddTextEntry('0xF1F3B83B', 'Exposed Triple Intake Kit')
	AddTextEntry('0xF1FDE688', 'The Gambler\'s Life')
	AddTextEntry('0xF1FF4E62', 'THE DIAMOND: VINEWOOD\'S<br>CROWN JEWEL')
	AddTextEntry('0xF2B9EF27', 'Race Spoiler')
	AddTextEntry('0xF2E9DFAE', 'Impotent Rage Eye Mask')
	AddTextEntry('0xF2E71F6D', 'Carbon Aggressive Spoiler')
	AddTextEntry('0xF2F95740', 'Painted Bulb Exhaust')
	AddTextEntry('0xF2FA5057', 'Primary Street Spoiler')
	AddTextEntry('0xF3A7B25F', 'Street Spoiler')
	AddTextEntry('0xF3BC8A32', 'Colors Yeti LS 19 Hoodie')
	AddTextEntry('0xF3BFE9F2', 'Secondary Street Skirt')
	AddTextEntry('0xF3CAEA49', 'Blue Bigness Waterproof')
	AddTextEntry('0xF3E02E06', 'Pink Painted Large Shirt')
	AddTextEntry('0xF3EE5903', 'Silver Enduring Watch')
	AddTextEntry('0xF3FFF8D3', 'Secondary Race Hood')
	AddTextEntry('0xF4AE2A9F', 'Orange Fade Retro Sneakers')
	AddTextEntry('0xF4B999F6', 'White Broker Cap')
	AddTextEntry('0xF4CF135E', 'Stripped Carbon Hood')
	AddTextEntry('0xF4D211A2', 'Gutter & Blood')
	AddTextEntry('0xF4F90060', 'Sports Cage')
	AddTextEntry('0xF5A8FC77', 'Globe Oil Sunstrip')
	AddTextEntry('0xF5E9A376', 'Teal Broker Coin Bomber')
	AddTextEntry('0xF5E11D08', 'SN Teal Compass Tee')
	AddTextEntry('0xF6ABC8FB', 'Wing GT I')
	AddTextEntry('0xF6B14478', 'Intercooler w/ Primary Vents')
	AddTextEntry('0xF6CBEA08', 'Black LC Diamond Sweater')
	AddTextEntry('0xF6EA7CF4', 'Mixed Metals Ceaseless')
	AddTextEntry('0xF6F63486', 'Snorkel Hood')
	AddTextEntry('0xF6FA6F06', 'Raid Kit')
	AddTextEntry('0xF6FC90F3', 'Split Pipes')
	AddTextEntry('0xF7CC9B12', 'Sprunk X-treme')
	AddTextEntry('0xF7D72D8A', 'SN Hue Sweater')
	AddTextEntry('0xF8AB1903', 'Blue Pulga Sweater')
	AddTextEntry('0xF8AE8C13', 'Underneath the hipster chic, you always suspected the Issi had a bad case of small car syndrome. Well, now the flat whites and ironic power pop are out, and the roll cage, carbon fiber interior and turbo charged four-cylinder are in. Just don\'t mention its height.')
	AddTextEntry('0xF8BCC88B', 'Intercooler')
	AddTextEntry('0xF8C675BD', 'Invade and Persuade Suck Tee')
	AddTextEntry('0xF8CD4A1A', 'Race Wing')
	AddTextEntry('0xF9B0C70B', 'Green Fame or Shame Kronos')
	AddTextEntry('0xF9F15768', 'Secondary Street Skirt')
	AddTextEntry('0xF9FB3A1C', 'Red Floral Bomber')
	AddTextEntry('0xF11DE38C', 'If you\'re going to crash, crash in style.')
	AddTextEntry('0xF13BDC20', 'Secondary Tipped Diffuser')
	AddTextEntry('0xF20E3B53', 'Green Flying Bravo Cap')
	AddTextEntry('0xF24D88EE', 'Red Chips Large Shirt')
	AddTextEntry('0xF27FA44E', 'Invade and Persuade Barrels Tee')
	AddTextEntry('0xF35C37D0', 'Secondary Aggressive Spoiler')
	AddTextEntry('0xF38C4245', 'Jugular')
	AddTextEntry('0xF40CEA0D', 'Carbon Stripped Hood')
	AddTextEntry('0xF40E9609', 'Secondary Front Bumper')
	AddTextEntry('0xF44D5456', 'Smooth Hood')
	AddTextEntry('0xF45E1D3A', 'Track Day')
	AddTextEntry('0xF47EDA3F', 'Bolstered Exhaust')
	AddTextEntry('0xF49C0EC2', 'Primary Painted Tuner')
	AddTextEntry('0xF49DBD11', 'Black Kronos Pulse')
	AddTextEntry('0xF53AEDEC', 'Roof Rack')
	AddTextEntry('0xF56BA4FA', 'Gray Opulent Fitted')
	AddTextEntry('0xF62EB2E7', 'Carbon Deep Inset Hood')
	AddTextEntry('0xF70E9887', 'Competition Skirt')
	AddTextEntry('0xF72B7B97', 'Mission III Tee')
	AddTextEntry('0xF72D5BBB', 'Jack of Spades')
	AddTextEntry('0xF81CCB32', 'Forest Camo Blagueurs Parka')
	AddTextEntry('0xF86A61FB', 'Primary Rear Bumper')
	AddTextEntry('0xF89B6AB8', 'Suits Kronos Quad')
	AddTextEntry('0xF90DEDCA', 'Custom Diffuser')
	AddTextEntry('0xF91AC9DE', 'Lilac Blagueurs Parka')
	AddTextEntry('0xF93BB97F', 'Royal Enduring Watch')
	AddTextEntry('0xF94FF271', 'Gray Lazerforce Wide Pants')
	AddTextEntry('0xF96A3647', 'Purple SC Broker Cap')
	AddTextEntry('0xF98BFD03', 'Orange The Diamond Hoodie')
	AddTextEntry('0xF99DDD69', 'Secondary Sports Spoiler')
	AddTextEntry('0xF99DE8C8', 'Exposed Turbo Hood')
	AddTextEntry('0xF99FE481', 'Big Bore Exhaust')
	AddTextEntry('0xF161EA67', 'Carbon Roof')
	AddTextEntry('0xF290F9A2', 'Open')
	AddTextEntry('0xF345AB6D', 'Pink Rage Bomber')
	AddTextEntry('0xF501A192', 'Black Broker Coin Bomber')
	AddTextEntry('0xF596CE5A', 'Red Dice Earrings')
	AddTextEntry('0xF598BD12', 'Carbon Stripped Hood')
	AddTextEntry('0xF707B49D', 'Triple Intake Bugcatcher')
	AddTextEntry('0xF783E660', 'Twin Black Stripes')
	AddTextEntry('0xF790CC51', 'Invade and Persuade Barrels Tee')
	AddTextEntry('0xF5280C0E', 'Dual Filter Blower')
	AddTextEntry('0xF5420FD2', 'Carbon Sports')
	AddTextEntry('0xF6028A0D', '2ND')
	AddTextEntry('0xF7612A29', 'Orange Patterned Fitted')
	AddTextEntry('0xF9058CF5', 'Fancy A Cuppa?')
	AddTextEntry('0xF9804C7F', 'Black Güffy Spray Puffer')
	AddTextEntry('0xF10004D5', 'Snake Knee Shorts')
	AddTextEntry('0xF21342D6', 'EXPERIENCE AFFLUENCE')
	AddTextEntry('0xF30367CD', 'Spotted Leather Fur')
	AddTextEntry('0xF67342BD', 'Colors Yeti Cap')
	AddTextEntry('0xF73756DC', 'Mauve Fleur Cocktail Dress')
	AddTextEntry('0xF78670C1', 'Cash Mouth')
	AddTextEntry('0xF1855741', 'Smart High Roller Shirt')
	AddTextEntry('0xF2711300', 'Red You\'re Awful Tee')
	AddTextEntry('0xF3869614', 'Blue Ancient Large Shirt')
	AddTextEntry('0xF4115704', 'Crimson High Roller Dress')
	AddTextEntry('0xF4841226', 'Suits High Roller Dress')
	AddTextEntry('0xF5887426', 'Black Double Stripe')
	AddTextEntry('0xF8060121', 'Hardstand Sunstrip')
	AddTextEntry('0xF8097051', 'Black The Diamond Hoodie')
	AddTextEntry('0xFA00EE10', 'Purple SC Broker Bomber')
	AddTextEntry('0xFA8C55DA', 'Cage & Performance Seats')
	AddTextEntry('0xFA31A36E', 'Dice Large Shirt')
	AddTextEntry('0xFA86A524', 'Splinter Deep Shades')
	AddTextEntry('0xFA87F0E3', 'Spade Crowex Rond')
	AddTextEntry('0xFA728FBD', 'Silver SASS Bracelet')
	AddTextEntry('0xFA764A34', 'Carbon Street Diffuser')
	AddTextEntry('0xFA128775', 'Redwood')
	AddTextEntry('0xFAB2471B', 'Extended Carbon Skirts')
	AddTextEntry('0xFABAC670', 'Mocha Perseus Leather Fur')
	AddTextEntry('0xFAEA4E09', 'Painted US Flag')
	AddTextEntry('0xFB2F6ED3', 'White Baroque Parka')
	AddTextEntry('0xFB3E571C', 'Gray Pattern Retro Sneakers')
	AddTextEntry('0xFB4EC81C', 'Black Pocket Jacket')
	AddTextEntry('0xFB5B2D78', 'Geo Flying Bravo Fitted')
	AddTextEntry('0xFB53F55D', 'Black SC Broker Wide Pants')
	AddTextEntry('0xFB67F0C2', 'Impotent Rage')
	AddTextEntry('0xFB71F837', 'Mauve Bigness Waterproof')
	AddTextEntry('0xFB73C21C', 'Carbon Rally Spec Hood')
	AddTextEntry('0xFB982A12', 'The Diamond: Vinewood\'s Crown Jewel')
	AddTextEntry('0xFB8207C7', 'Primary Race Hood')
	AddTextEntry('0xFBA1A67A', 'Red Fame or Shame Shades')
	AddTextEntry('0xFBA68062', 'Red Painted Scratches')
	AddTextEntry('0xFBB85C3A', 'Sprunk')
	AddTextEntry('0xFBD7129E', 'EXPERIENCE IMPRUDENCE')
	AddTextEntry('0xFBFCDB90', 'Racing Roof Kit')
	AddTextEntry('0xFBFEC6E2', 'Basic Side Pipes')
	AddTextEntry('0xFC013F96', 'Jakey\'s Lager')
	AddTextEntry('0xFC088D1E', 'Ducktail Spoiler')
	AddTextEntry('0xFC1F5110', 'Yellow Pattern Loose Bow Tie')
	AddTextEntry('0xFC4FCA41', 'Vented Hood w/ Vents')
	AddTextEntry('0xFC6FC102', 'Gold SC Silk Robe')
	AddTextEntry('0xFC9A20BA', 'Walnut Aviators')
	AddTextEntry('0xFC11F1CC', 'Primary Tipped Diffuser')
	AddTextEntry('0xFC27A041', 'Obey Coverage')
	AddTextEntry('0xFC162FF1', 'Carbon Side Panel')
	AddTextEntry('0xFC455D8C', 'Le Chien Jersey')
	AddTextEntry('0xFC58099D', 'Fin Remove')
	AddTextEntry('0xFCA34689', 'Drift Spoiler')
	AddTextEntry('0xFCBE22E4', 'White Pocket Jacket')
	AddTextEntry('0xFCC08DF3', 'Minimum: 100 Chips<br>Maximum: 10,000 Chips')
	AddTextEntry('0xFCC3E72B', 'Orange The Diamond Cap')
	AddTextEntry('0xFCD96A72', 'The Diamond Casino & Resort: Vinewood\'s Crown Jewel')
	AddTextEntry('0xFCD4797E', 'Black Vinewood Wide Pants')
	AddTextEntry('0xFCDCC207', 'The Lost MC')
	AddTextEntry('0xFCDE27E7', 'Brown Prairie Large Shirt')
	AddTextEntry('0xFCEEB4E7', 'Bullet Extended')
	AddTextEntry('0xFCF2DED7', 'Globe Oil')
	AddTextEntry('0xFD050E60', 'Race Bumper')
	AddTextEntry('0xFD5B62C2', 'Black Güffy Spray Puffer')
	AddTextEntry('0xFD16B514', 'Primary Bolted Fenders')
	AddTextEntry('0xFD36AF8B', 'Cool Air')
	AddTextEntry('0xFD83CBBC', 'Black Kronos Quad')
	AddTextEntry('0xFD9295AA', 'Secondary Splitter')
	AddTextEntry('0xFD351018', 'Logger Beer Alt')
	AddTextEntry('0xFDC2A9B4', 'Blue Prairie Large Shirt')
	AddTextEntry('0xFDC71CF8', 'Triple Intake / No Hood')
	AddTextEntry('0xFE2F1ED0', 'Roadster')
	AddTextEntry('0xFE2F42A4', 'Pink Floral Large Shirt')
	AddTextEntry('0xFE3E066B', 'Black The Diamond Hoodie')
	AddTextEntry('0xFE57D01E', 'Secondary Vortex Generators')
	AddTextEntry('0xFE606F18', 'EXPERIENCE INDULGENCE')
	AddTextEntry('0xFE394556', 'Carbon Street Diffuser')
	AddTextEntry('0xFEDADD8A', 'Black D Casino Tee')
	AddTextEntry('0xFF25C52C', 'Street Hood')
	AddTextEntry('0xFF9028E0', 'Primary Hood w/ Carbon Vent')
	AddTextEntry('0xFF9470CF', 'White High Roller Waistcoat')
	AddTextEntry('0xFFAF0124', 'Mocha Perseus Leather Fur')
	AddTextEntry('0xFFB3EB35', 'Mauve Paint Cocktail Dress')
	AddTextEntry('0xFFBE3C2D', 'Painted Skirt')
	AddTextEntry('0xFFCCD089', 'This is it. Wrap it up, folks. Thanks to Enus, humanity\'s quest to design the perfect grand tourer is finally over. It took generations of privately educated stiff upper lips, all prepared to dig deep into bottomless wells of lazy entitlement - but credit where it\'s due. The Brits cracked the code. This is the kind of self-assurance that can\'t be earned. It can only be bought.')
	AddTextEntry('0xFFD30199', 'Vented Hood')
	AddTextEntry('0xFFDBB96E', 'Primary Race Spoiler')
	AddTextEntry('0xFFF367FA', 'Carbon Annis Grille')
	AddTextEntry('PR_TAKBACK', 'Titanium Infinity Exhaust')
end)