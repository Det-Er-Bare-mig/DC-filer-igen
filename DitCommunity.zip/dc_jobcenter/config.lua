Config = {}

Config.OpenMenu = 51 -- Key: E
Config.Locations = {
    {name = "Jobcenter", colour=17, id=351, x = 237.9271697998, y = -412.01062011719, z = 47.947887420654}
}
Config.Language = {
    SelectedJob = "Du har valgt",
}
