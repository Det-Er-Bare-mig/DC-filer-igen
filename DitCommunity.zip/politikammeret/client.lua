-- Settings
local politimenuen = true -- SKAL MAN KUNNE BRUGE MENUEN (NORMALT: TRUE)

local Politis = {
  {name="Politi - Våbenkammer", id=0, x=461.59725952148, y=-981.20782470703, z=30.689603805542},
  {name="Politi - Våbenkammer", id=0, x=1843.1583251953, y=3700.1313476563, z=1.537992477417}, -- SANDY SHORES
  {name="Politi - Våbenkammer", id=0, x=1727.5931396484, y=2506.9790039063, z=-78.032608032227}, -- PALETO BAY
  {name="Politi - Våbenkammer", id=0, x=-2133.6674804688, y=3252.9428710938, z=32.810298919678}, -- TRÆNINGSBANEN
  {name="PET - Våbenkammer", id=0, x=884.90234375, y=-3200.0666503906, z=-98.196304321289}
}


-- NUI Variables
local atPoliti = false
local politiOpen = false

-- Open Gui and Focus NUI
function openGui()
  SetNuiFocus(true, true)
  SendNUIMessage({openPoliti = true})
end

-- Close Gui and disable NUI
function closeGui()
  SetNuiFocus(false)
  ClearPedTasks(GetPlayerPed(-1)) 
  SendNUIMessage({openPoliti = false})
  politiOpen = false
end

function DrawTxt(text,font,centre,x,y,scale,r,g,b,a)
  SetTextFont(6)
  SetTextProportional(0)
  SetTextScale(scale/1, scale/1)
  SetTextColour(r, g, b, a)
  SetTextDropShadow(0, 0, 0, 0,255)
  SetTextEdge(1, 0, 0, 0, 255)
  SetTextDropShadow()
  SetTextOutline()
  SetTextCentre(centre)
  SetTextEntry("STRING")
  AddTextComponentString(text)
  DrawText(x , y)
end

  Citizen.CreateThread(function()
    while true do
		Citizen.Wait(0)
		if not (GetEntityHealth(GetPlayerPed(-1)) == 100) then
			if politimenuen then
				if(IsNearPoliti()) then
					if not politiOpen == true then
	      				DrawTxt("Tryk ~b~[E]~w~ for at åbne våbenkammeret",0,1,0.5,0.958,0.6,255,255,255,255)
	      				if IsControlJustPressed(1, 51)  then -- IF INPUT_PICKUP Is pressed
	          				if (IsInVehicle()) then
	            				TriggerEvent('chatMessage', "", {255, 0, 0}, "^1Du kan ikke bruge Våbenkammeret, i et køretøj!");
	            			else
	            				TriggerServerEvent('politikammeret:AskPermission')
	            			end
	            		end
         		 	end
      			end
			end
		end
	end
end)


RegisterNetEvent("politikammeret:Yes")
AddEventHandler("politikammeret:Yes", function()
     openGui()
     politiOpen = true
   end)


-- Disable controls while GUI open
Citizen.CreateThread(function()
  while true do
    if politiOpen then
      local ply = GetPlayerPed(-1)
      local active = true
      DisableControlAction(0, 1, active) -- LookLeftRight
      DisableControlAction(0, 2, active) -- LookUpDown
      DisableControlAction(0, 24, active) -- Attack
      DisablePlayerFiring(ply, true) -- Disable weapon firing
      DisableControlAction(0, 142, active) -- MeleeAttackAlternate
      DisableControlAction(0, 106, active) -- VehicleMouseControlOverride
    end
    Citizen.Wait(0)
  end
end)

-- NUI Callback Methods
RegisterNUICallback('close', function(data, cb)
  closeGui()
  cb('ok')
end)

RegisterNUICallback('balance', function(data, cb)
  SendNUIMessage({openSection = "balance"})
  cb('ok')
end)

RegisterNUICallback('withdraw', function(data, cb)
  SendNUIMessage({openSection = "withdraw"})
  cb('ok')
end)

RegisterNUICallback('quickCash', function(data, cb)
  policearmor()
  cb('ok')
end)

RegisterNUICallback('withdrawSubmit', function(data, cb)
  policearmor()
  cb('ok')
end)


RegisterNUICallback('WeaponRemove', function(data, cb)
  weaponremove()
  cb('ok')
end)

RegisterNUICallback('Weapon13', function(data, cb)
  basicweapons()
  cb('ok')
end)

RegisterNUICallback('Weapon14', function(data, cb)
  WeaponGive("weapon_vintagepistol","Hastighedsmåler")
  cb('ok')
end)

RegisterNUICallback('Weapon1', function(data, cb)
   WeaponGive("weapon_combatpistol","tjenestepistol")
  cb('ok')
end)

--[[RegisterNUICallback('Weapon2', function(data, cb)
  WeaponGive("weapon_snspistol","SNS Pistol")
  cb('ok')
end)]]

RegisterNUICallback('Weapon3', function(data, cb)
  WeaponGive("weapon_stungun","Tazer")
  cb('ok')
end)

RegisterNUICallback('Weapon4', function(data, cb)
  WeaponGive("weapon_nightstick","Stav")
  cb('ok')
end)

RegisterNUICallback('Weapon5', function(data, cb)
  WeaponGive("weapon_flashlight","Lommelygte")
  cb('ok')
end)

RegisterNUICallback('Weapon6', function(data, cb)
  WeaponGive("weapon_SMG","SMG")
  cb('ok')
end)

RegisterNUICallback('Weapon7', function(data, cb)
  WeaponGive("weapon_carbinerifle","Carbine Riffel")
  cb('ok')
end)

RegisterNUICallback('Weapon8', function(data, cb)
  WeaponGive("weapon_sniperrifle","Sniper Riffel")
  cb('ok')
end)

RegisterNUICallback('Weapon9', function(data, cb)
  WeaponGive("weapon_pumpshotgun","Shotgun")
  cb('ok')
end)

RegisterNUICallback('Weapon10', function(data, cb)
  WeaponGive("weapon_parachute","Faldskærm")
  cb('ok')
end)

RegisterNUICallback('Weapon11', function(data, cb)
  granate("weapon_flare","Flares")
  cb('ok')
end)

RegisterNUICallback('Weapon12', function(data, cb)
  granate("weapon_smokegrenade","Tåre Gas")
  cb('ok')
end)

-- Check if player is in a vehicle
function IsInVehicle()
  local ply = GetPlayerPed(-1)
  if IsPedSittingInAnyVehicle(ply) then
    return true
  else
    return false
  end
end

function IsNearPoliti()
  local ply = GetPlayerPed(-1)
  local plyCoords = GetEntityCoords(ply, 0)
  for _, item in pairs(Politis) do
    local distance = GetDistanceBetweenCoords(item.x, item.y, item.z,  plyCoords["x"], plyCoords["y"], plyCoords["z"], true)
    if(distance <= 3) then
      return true
    end
  end
end

function giveWeapon(weaponHash)
    GiveWeaponToPed(GetPlayerPed(-1), GetHashKey(weaponHash), 999, false)
end

function weaponComponent(weaponHash, component)
    if HasPedGotWeapon(PlayerPedId(), GetHashKey(weaponHash), false) then
        GiveWeaponComponentToPed(PlayerPedId(), GetHashKey(weaponHash), GetHashKey(component))
     end
end


function weaponremove()
  if(IsNearPoliti()) == true then
    if (IsInVehicle()) then
      TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Du kan ikke bruge kammeret i et køretøj!");
    else
      ped = PlayerPedId()
      TriggerEvent("pNotify:SendNotification",{text = "Du har lagt alle dine våben og din skudsikker vest i våbenkammeret",type = "error",timeout = (2000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
      PlaySoundFrontend(-1, "Beep_Red", "DLC_HEIST_HACKING_SNAKE_SOUNDS", true)
      RemoveAllPedWeapons(ped, true)
      local myPed = GetPlayerPed(-1)
      local fullArmour = 0
      SetPedArmour(myPed, fullArmour)
    end
  else
    TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Dette er ikke et våbenkammer");
  end
end


function granate(weapon,weaponnotifyname)
  if(IsNearPoliti()) == true then
    if (IsInVehicle()) then
      TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Du kan ikke bruge kammeret i et køretøj!");
    else
      TriggerEvent("pNotify:SendNotification",{text = "Du har taget "..weaponnotifyname.." ud af våbenkammeret",type = "error",timeout = (2000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey(weapon), 20, false)
      PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
  else
    TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Dette er ikke et våbenkammer");
  end
end

-- Process withdraw if conditions met
function basicweapons()
  if(IsNearPoliti()) == true then
    if (IsInVehicle()) then
      TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Du kan ikke bruge kammeret i et køretøj!");
    else
      TriggerEvent("pNotify:SendNotification",{text = "Du har dine basic ting ud af våbenkammeret",type = "error",timeout = (2000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_combatpistol"), 100, false)
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_stungun"), 1, false)
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_nightstick"), 1, false)
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_flashlight"), 1, false)
      --GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_snspistol"), 100, false)
      GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("weapon_vintagepistol"), 999, false)
      PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
  else
    TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Dette er ikke et våbenkammer");
  end
end



function policearmor()
  if(IsNearPoliti()) == true then
    if (IsInVehicle()) then
      TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Du kan ikke bruge kammeret i et køretøj!");
    else
      TriggerEvent("pNotify:SendNotification",{text = "Du har taget en skudsikker vest på",type = "error",timeout = (2000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
      PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
      local myPed = GetPlayerPed(-1)
      local fullArmour = 100
      SetPedArmour(myPed, fullArmour)
    end
  else
    TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Dette er ikke et våbenkammer");
  end
end




-- Process withdraw if conditions met
function WeaponGive(weapon,weaponnotifyname)
  if(IsNearPoliti()) == true then
    if (IsInVehicle()) then
      TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Du kan ikke bruge kammeret i et køretøj!");
    else
      TriggerEvent("pNotify:SendNotification",{text = "Du har taget din "..weaponnotifyname.." ud af våbenkammeret",type = "error",timeout = (2000),layout = "bottomCenter",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
      giveWeapon(weapon)
      PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
  else
    TriggerEvent('chatMessage', "", {0, 255, 0}, "^1Dette er ikke et våbenkammer");
  end
end